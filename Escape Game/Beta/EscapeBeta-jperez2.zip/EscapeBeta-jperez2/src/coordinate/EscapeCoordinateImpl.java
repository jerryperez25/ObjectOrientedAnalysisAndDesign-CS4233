package coordinate;

import coordinate.EscapeCoordinateImpl.CompassRose;

public interface EscapeCoordinateImpl extends Coordinate 
{
	public int getX();
	public int getY();
	public int hashCode();
	public boolean equals(Object o);
	//public boolean isLinear(Coordinate to);
	public EscapeCoordinateImpl[] getNeighbors();
	public EscapeCoordinateImpl getNeighborAt(CompassRose direction);
	static enum CompassRose {NORTH, EAST, SOUTH, WEST, NORTHEAST, NORTHWEST, SOUTHEAST, SOUTHWEST, NONE};
	public CompassRose getDirectionTo(EscapeCoordinateImpl target);
	public boolean isLinearTo(EscapeCoordinateImpl target);
	public boolean isOrthagonalTo(EscapeCoordinateImpl target);
	public boolean isDiagonalTo(EscapeCoordinateImpl target);
	public boolean isOmniTo(EscapeCoordinateImpl target);
}
