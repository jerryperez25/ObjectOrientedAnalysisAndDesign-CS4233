package coordinate;

import coordinate.Coordinate.CoordinateType;
import escape.exception.EscapeException;

public class CoordinateFactory 
{
	public CoordinateFactory()
	{
		//do nothing
	}
	
	/**
	 * This function allows us to make whichever type of coordinate that
	 * we desire when the time comes. At the moment, we only have functionality for 
	 * SQUARE but more functionality will be coming soon.
	 * @param whichOne
	 * @param x
	 * @param y
	 * @return a Type of Coordinate
	 */
	public static EscapeCoordinateImpl makeCoordinate(CoordinateType whichOne, int x, int y)
	{
		
		switch(whichOne)
		{
		case SQUARE:
			{
				return new SquareCoordinate(x,y);
			}
		case TRIANGLE:
			{
				return new TriangleCoord(x,y);
			}
		default:
			//we want to return null if the type of coordinate is not square
			return null;
		}
	}
}
