package coordinate;

import java.util.Objects;

import coordinate.EscapeCoordinateImpl.CompassRose;
import escape.exception.EscapeException;

public class SquareCoordinate<C extends Coordinate> implements EscapeCoordinateImpl
{
	private int x;
	private int y;
	
	public SquareCoordinate(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
	public int getX()
	{
		return this.x;
	}
	public int getY()
	{
		return this.y;
	}
	public int setX(int x)
	{
		return this.x = x;
	}
	public int setY(int y)
	{
		return this.y = y;
	}
	/**
	 * This function uses a coordinate to determine the distance to the
	 * location given to it as the argument.
	 * @param Coordinate
	 */
	public int DistanceTo(Coordinate c) 
	{
		//if a different type then 
		Throwable newThrow = new Throwable("Invalid Coordinate Type");
		
		if (!(c instanceof SquareCoordinate))
		{
			throw new EscapeException("Coordinate is not appropriate type", newThrow);
		}
		
		SquareCoordinate caster = (SquareCoordinate) c;
		int dist = 0;
		int xDist = Math.abs(caster.getX() - this.getX());
		int yDist = Math.abs(caster.getY() - this.getY());
		
		while(xDist != 0 && yDist != 0)
		{
			dist++;
			xDist--;
			yDist--;
		}
		
		dist = dist + xDist;
		dist = dist + yDist;
		return dist;
	}

	
	/**
	 * This function facilitates hashing in maps.
	 */
	@Override
	public int hashCode()
	{
		return Objects.hash(x,y);
	}
	/**
	 * this function is overridden and checks to make sure the give object
	 * matches the instance that we would like to check
	 */
	@Override
	public boolean equals(Object o)
	{
		if ((o instanceof SquareCoordinate))
		{
			SquareCoordinate newOne = (SquareCoordinate) o;
			return newOne.x == this.x && newOne.y == this.y;
		}
		return false;
		
	}
	
	/**
	 * This function gets all of the neighbors of the coordinate that calls it 
	 * @return an array of neighbors 
	 */
	public EscapeCoordinateImpl[] getNeighbors()
	{
		EscapeCoordinateImpl neighborArray[] = {new SquareCoordinate(this.x-1, this.y-1), 
				new SquareCoordinate(this.x-1, this.y),
				new SquareCoordinate(this.x-1, this.y+1),
				new SquareCoordinate(this.x, this.y-1),
				new SquareCoordinate(this.x, this.y+1),
				new SquareCoordinate(this.x+1, this.y-1),
				new SquareCoordinate(this.x+1, this.y),
				new SquareCoordinate(this.x+1, this.y+1)}; 
		return neighborArray;
	}
	/**
	 * This function uses a coordinate that calls it and a target and determines
	 * where the target is in relation to the source.
	 * @param target
	 * @return CompassRose direction
	 */
	public CompassRose getDirectionTo(EscapeCoordinateImpl target)
	{
		int deltaX = Math.abs(this.getX() - target.getX());
		int deltaY = Math.abs(this.getY() - target.getY());
		
		if(this.getY() == target.getY() && this.getX() < target.getX())
		{
			return CompassRose.NORTH;
		}
		if(this.getY() == target.getY() && this.getX() > target.getX())
		{
			return CompassRose.SOUTH;
		}
		if(this.getY() < target.getY() && this.getX() == target.getX())
		{
			return CompassRose.EAST;
		}
		if(this.getY() > target.getY() && this.getX() == target.getX())
		{
			return CompassRose.WEST;
		}
		if(deltaX == deltaY && this.getX() < target.getX() && this.getY() < target.getY())
		{
			return CompassRose.NORTHEAST;
		}
		if(deltaX == deltaY && this.getX() < target.getX() && this.getY() > target.getY())
		{
			return CompassRose.NORTHWEST;
		}
		if(deltaX == deltaY && this.getX() > target.getX() && this.getY() < target.getY())
		{
			return CompassRose.SOUTHEAST;
		}
		if(deltaX == deltaY && this.getX() > target.getX() && this.getY() > target.getY())
		{
			return CompassRose.SOUTHWEST;
		}
		else
		{
			return CompassRose.NONE;
		}
	}
	
	/**
	 * This function uses the coordinate that calls it and a target
	 * and determines if the target is linear to the source.
	 * @param target
	 * @return false if not linear and true if it is linear
	 */
	public boolean isLinearTo(EscapeCoordinateImpl target)
	{
		if(this.getDirectionTo(target) == CompassRose.NONE)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	
	/**
	 * This function uses the coordinate that calls it and a target
	 * and determines if the target is orthogonal to the source.
	 * @param target
	 * @return true if orthogonal and false if else
	 */
	public boolean isOrthagonalTo(EscapeCoordinateImpl target)
	{
		if(this.getDirectionTo(target) == CompassRose.NORTH || 
				this.getDirectionTo(target) == CompassRose.SOUTH ||
						this.getDirectionTo(target) == CompassRose.EAST 
						|| this.getDirectionTo(target) == CompassRose.WEST)
		{
			return true;
		}
		return false; 
	}
	/**
	 * This function uses the coordinate that calls it and a target
	 * and determines if the target is diagonal to the source.
	 * @param target
	 * @return true if diagonal and false if else
	 */
	public boolean isDiagonalTo(EscapeCoordinateImpl target)
	{
		if(this.getDirectionTo(target) == CompassRose.NORTHEAST||
				this.getDirectionTo(target) == CompassRose.NORTHWEST ||
				this.getDirectionTo(target) == CompassRose.SOUTHEAST ||
				this.getDirectionTo(target) == CompassRose.SOUTHWEST)
		{
			return true;
		} 
		return false; 
	}
	/**
	 * This function uses the coordinate that calls it and a target
	 * and determines if the target is omni to the source.
	 * @param target
	 * @return boolean if it is omni and false if not
	 */
	public boolean isOmniTo(EscapeCoordinateImpl target)
	{
		if(this.getDirectionTo(target) != CompassRose.NONE)
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	/**
	 * This function is called upon by a coordinate and takes in a direction
	 * to see what neighbors are at that direction.
	 * @param direction
	 * @return coordinate
	 */
	@Override
	public EscapeCoordinateImpl getNeighborAt(CompassRose direction) 
	{
		if(direction == CompassRose.NORTH)
		{
			return new SquareCoordinate(this.getX()+1, this.getY());
		}
		if(direction == CompassRose.SOUTH)
		{
			return new SquareCoordinate(this.getX()-1, this.getY());
		}
		if(direction == CompassRose.EAST)
		{
			return new SquareCoordinate(this.getX(), this.getY()+1);
		}
		if(direction == CompassRose.WEST)
		{
			return new SquareCoordinate(this.getX(), this.getY()-1);
		}
		if(direction == CompassRose.NORTHEAST)
		{
			return new SquareCoordinate(this.getX()+1, this.getY()+1);
		}
		if(direction == CompassRose.NORTHWEST)
		{
			return new SquareCoordinate(this.getX()+1, this.getY()-1);
		}
		if(direction == CompassRose.SOUTHEAST)
		{
			return new SquareCoordinate(this.getX()-1, this.getY()+1);
		}
		else if(direction == CompassRose.SOUTHWEST)
		{
			return new SquareCoordinate(this.getX()-1, this.getY()-1);
		}
		return null;
	}
	
}
