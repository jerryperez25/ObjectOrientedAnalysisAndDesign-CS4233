package manager;

import board.EscapeBoard;
import board.LocationType;
import board.SquareBoard;
import coordinate.Coordinate;

import coordinate.Coordinate.CoordinateType;
import coordinate.CoordinateFactory;
import coordinate.EscapeCoordinateImpl;
import escape.exception.EscapeException;
import escape.util.LocationInitializer;
import piece.EscapePiece;
import piece.EscapePieceImpl;
import piece.PieceTypeDescriptor;
import piece.Player;
import piece.EscapePiece.PieceName;
import rule.RuleDescriptor;

public class EscapeGameManagerImpl <C> implements EscapeGameManager<EscapeCoordinateImpl>
{
	private EscapeBoard board;
	private CoordinateType coordinateType;
	private CoordinateFactory factory;
	
	
	public EscapeGameManagerImpl(CoordinateType coordinateType)
	{
		this.coordinateType = coordinateType;
		this.factory = new CoordinateFactory();
	
	}
	
	/**
	 * this function populates the board with the information necessary
	 * @param board of type SquareBoard
	 */
	public void setBoard(EscapeBoard board) //We need to find a way to make this generic
	{
		this.board = board;
	}
	/**
	 * this function returns the board that we are using
	 * @return SquareBoard
	 */
	public EscapeBoard getBoard() //We need to find a way to make this generic
	{
		return this.board;
	}
	/**
	 * this function returns the coordinate factory
	 * @return Coordinate that is created by the coordinate factory
	 */
	public CoordinateFactory getFactory()
	{
		return this.factory;
	}

	/**
	 * This function puts the specified piece at the specified location.
	 * This will be helpful for all boards.
	 * @param piece
	 * @param coord
	 */
	
	@Override
	public EscapePiece getPieceAt(EscapeCoordinateImpl coordinate) 
	{
		
		return board.getPieceAt(coordinate);
	}

	/**
	 * Returns a coordinate of the appropriate type. If the coordinate cannot be
	 * created, then null is returned and the status message is set appropriately.
	 * @param x the x component
	 * @param y the y component
	 * @return the coordinate or null if the coordinate cannot be implemented
	 */
	
	@Override
	public EscapeCoordinateImpl makeCoordinate(int x, int y) 
	{
		return factory.makeCoordinate(coordinateType, x, y);
		
	}
	/**
	 * Make the move in the current game.
	 * @param from starting location
	 * @param to ending location
	 * @return true if the move was legal, false otherwise
	 */
	@Override
	public boolean move(EscapeCoordinateImpl from, EscapeCoordinateImpl to) 
	{
		return this.board.move(from, to);
	}

	
	


}
