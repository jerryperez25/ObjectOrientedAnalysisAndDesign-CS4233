package board;

import java.util.HashMap;
import java.util.Map;

import coordinate.EscapeCoordinateImpl;
import coordinate.TriangleCoord;
import escape.exception.EscapeException;
import pathFinding.PathFindingImpl;
import piece.EscapePiece;
import piece.EscapePieceImpl;
import piece.Player;
import piece.EscapePiece.MovementPattern;
import piece.EscapePiece.PieceAttributeID;

public class TriangleBoard implements EscapeBoard<EscapeCoordinateImpl> 
{
	private int xMax;
	private int yMax;
	public Map<EscapeCoordinateImpl, LocationType> coordLoc;
	public Map<EscapeCoordinateImpl, EscapePiece> coordPiece;
	private boolean player1Turn = true;
	private boolean infiniteBoard = false;
	private int player1Count = 0;
	private int player2Count = 0;
	
	public TriangleBoard(int xMax, int yMax)
	{
		this.xMax = xMax;
		this.yMax = yMax;
		coordLoc = new HashMap<>();
		coordPiece = new HashMap<>();
		
	}
	//This constructor is used for infinite boards
	public TriangleBoard()
	{
		this.infiniteBoard = true;
		coordLoc = new HashMap<>();
		coordPiece = new HashMap<>();
	}

	@Override
	public int getXMax() 
	{
		return this.xMax;
	}

	@Override
	public int getYMax() 
	{
		return this.yMax;
	}
	/**
	 * This method is meant to set the player1 piece 
	 * count from the game builder
	 * @param player count obtained from builder
	 */
	public void setPlayer1Count(int count)
	{
		this.player1Count = count;
	}
	/**
	 * This method is meant to set the player2 piece 
	 * count from the game builder
	 * @param player count obtained from builder
	 */
	public void setPlayer2Count(int count)
	{
		this.player2Count = count;
	}
	/**
	 * This function returns the state of trinangle board
	 * and whether or not it is infinite
	 * @return the state of board (infinite or not)
	 */
	public boolean isItInfinite()
	{
		return this.infiniteBoard;
	}

	/**
	 * This function takes in a desired coordinate set and returns the location
	 * type that is associated with it.
	 * @param coordinate
	 * @return LocationType
	 */
	@Override
	public LocationType getLocationType(EscapeCoordinateImpl coordinate) 
	{
		return this.coordLoc.get(coordinate);
	}

	/**
	 * This function sets the specified coordinate to a specified type.
	 * @param coordinate
	 * @param Locationtype
	 */
	@Override
	public void setLocationType(EscapeCoordinateImpl coordinate, LocationType type) 
	{
		this.coordLoc.put(coordinate, type);
	}

	/**
	 * This function gets the associated piece with the location that we are
	 * passing in. It is important to note that we can only get pieces for valid
	 * coordinates. Despite the fact that a manager can make whatever coordinate. 
	 * @param coordinate
	 * @return EscapePiece
	 */
	@Override
	public EscapePiece getPieceAt(EscapeCoordinateImpl coordinate) 
	{
		if(infiniteBoard == true)
		{
			//if this is an infinite board then we get the piece wherever it is placed
			return coordPiece.get(coordinate);
		}
		//we check if coordinates x and y is less than 1 because that is the first coordinate in the squareGame
		if (coordinate == null || coordinate.getX() > this.getXMax()|| coordinate.getY() > this.getYMax() || coordinate.getX() < 1 || coordinate.getY() < 1)
		{
			return null;
		}
		return coordPiece.get(coordinate);
	}

	/**
	 * This function puts the specified piece at the specified location.
	 * This will be helpful for all boards.
	 * @param piece
	 * @param coord
	 */
	@Override
	public void putPieceAt(EscapePiece piece, EscapeCoordinateImpl coord) 
	{
		this.coordPiece.put(coord, piece);
	}

	/**
	 * Make the move in the current game.
	 * @param from starting location
	 * @param to ending location
	 * @return true if the move was legal, false otherwise
	 */
	@Override
	public boolean move(EscapeCoordinateImpl from, EscapeCoordinateImpl to) 
	{	
		
		EscapePiece whichPiece = this.getPieceAt(from);
		EscapePieceImpl casterPiece = (EscapePieceImpl) whichPiece;
		PathFindingImpl newPath = new PathFindingImpl(this);
		
		//System.out.println("Player 1 has: " + this.player1Count + " pieces.");
		//System.out.println("Player 2 has: " + this.player2Count + " pieces.");
		
		if(preReqFalseConditions(to, from, whichPiece))
		{
			return false;
		}
		
		if(casterPiece.hasAttribute(PieceAttributeID.FLY) && 
				casterPiece.getMovementPattern() == MovementPattern.OMNI
				&& from.DistanceTo(to) <= casterPiece.getVal())
		{
			exitLocOppoPlayerMove(this.getLocationType(to), whichPiece, to, from);
			return true;
		}
		if(pathFindingMoves(casterPiece, to, from))
		{
			
			if(isThereAPath(newPath, casterPiece, from, to))
			{
				return true; //if there is, return true
			}
			
			return false; //if not then return false
		}
		throw new EscapeException("you arent getting to any of the if statements");
	}
	
	/**
	 * This method runs the path finding algorithm if a piece has certain attributes.
	 * If the return isn't null then we know that the move is possible and we should
	 * place our piece at the correct location. This is also where the players counts
	 * will be decremented.  
	 * @param p PathFindingImpl to call the finding algorithm with
	 * @param piece
	 * @param from
	 * @param to
	 * @return
	 */
	public boolean isThereAPath(PathFindingImpl p, EscapePieceImpl piece, EscapeCoordinateImpl from, EscapeCoordinateImpl to)
	{
		if(p.findPath(piece, from, to) != null )
		{
			if(this.getLocationType(to) == LocationType.EXIT)
			{
				this.coordPiece.remove(from);
				player1Turn = !player1Turn;
				return true;
			}
			this.putPieceAt(piece, to);
			this.putPieceAt(null, from); //removes the piece from 
			player1Turn = !player1Turn;
			return true;
		}
		else
		{
			return false;
		}
	}
	/**
	 * This method is to delegate the false conditions from the main check. 
	 * It goes through and checks to see if there are certain false board conditions.
	 * @param to
	 * @param from
	 * @param whichPiece
	 * @return true if there is a false condition, false otherwise
	 */
	public boolean preReqFalseConditions(EscapeCoordinateImpl to, EscapeCoordinateImpl from, EscapePiece whichPiece)
	{
		if((from == null || to == null)
				||(this.coordPiece.get(from) == null)
				||((whichPiece.getPlayer() == Player.PLAYER1) != player1Turn)
				||(from.getX() == to.getX() && from.getY() == to.getY())
				||isItInfinite() == false && (from.getX() > this.xMax || from.getY() > this.yMax || to.getX() > this.xMax || to.getY() > this.yMax)
				||isItInfinite() == false && (from.getX() < 1 || from.getY() < 1 || to.getX() < 1 || to.getY() < 1)
				||((this.getPieceAt(to)!= null) && this.getPieceAt(to).getPlayer() == whichPiece.getPlayer())
				||(this.getLocationType(to) != null && this.getLocationType(to) == LocationType.BLOCK))
		{
			return true;
		}
		
		return false; // none of the false conditions are met
	}
	
	/**
	 * This method checks to see if the location is of type exit, and if it 
	 * is then we remove the piece and toggle the player. In addition,
	 * if the piece is not an exit, then we are to put the piece at the 
	 * target location.
	 * @param locationType
	 * @param whichPiece
	 * @param to
	 * @param from
	 */
	public void exitLocOppoPlayerMove(LocationType locationType, EscapePiece whichPiece, EscapeCoordinateImpl to, EscapeCoordinateImpl from)
	{
		if ((this.getLocationType(to)== LocationType.EXIT)) 
		{
			this.coordPiece.remove(from);
			player1Turn = !player1Turn;
		}
		//if we land on valid piece or opposing players piece
		this.putPieceAt(whichPiece, to);
		this.putPieceAt(null, from); //removes the piece from 
		player1Turn = !player1Turn;
	}
	/**
	 * This function operates very similar to the false conditions where we check 
	 * what attributes are valid to run the path finder on.
	 * @param casterPiece
	 * @param to
	 * @param from
	 * @return true if we want to run the path finder, and false otherwise.
	 */
	public boolean pathFindingMoves(EscapePieceImpl casterPiece, EscapeCoordinateImpl to, EscapeCoordinateImpl from)
	{
		if(casterPiece.hasAttribute(PieceAttributeID.DISTANCE) 
				&& casterPiece.getMovementPattern() == MovementPattern.OMNI
				|| casterPiece.hasAttribute(PieceAttributeID.JUMP))
		{
			return true;
		}
		return false;
	}
	
	/**
	 * This function checks to see if the triangle has the jump attribute 
	 * and if the distance is less than or equal to the distance of the attribute
	 * @param piece
	 * @param to
	 * @param from
	 * @return true if the triangle has jump and if the distance 
	 */
	public boolean triJump(EscapePieceImpl piece, EscapeCoordinateImpl to, EscapeCoordinateImpl from)
	{
		if(to.getClass() == TriangleCoord.class)
		{
			if(piece.hasAttribute(PieceAttributeID.JUMP))
			{
				if(from.DistanceTo(to)<=piece.getVal())
				{
					return true;
				}
			}
		}
		return false;
	}

}
