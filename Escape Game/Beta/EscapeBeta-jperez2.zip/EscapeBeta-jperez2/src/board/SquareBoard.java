package board;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.HashMap;
import java.util.LinkedList;
import java.util.List;
import java.util.Map;

import coordinate.EscapeCoordinateImpl;
import coordinate.SquareCoordinate;
import escape.exception.EscapeException;
import escape.util.LocationInitializer;
import pathFinding.PathFindingImpl;
import piece.EscapePiece;
import piece.EscapePieceImpl;
import piece.Player;
import piece.EscapePiece.MovementPattern;
import piece.EscapePiece.PieceAttributeID;
import piece.EscapePiece.PieceName;

public class SquareBoard implements EscapeBoard<EscapeCoordinateImpl>
{
	private int xMax;
	private int yMax;
	private int player1Count = 0;
	private int player2Count = 0;
	public Map<EscapeCoordinateImpl, LocationType> coordLoc;
	public Map<EscapeCoordinateImpl, EscapePiece> coordPiece;
	private boolean player1Turn = true;
	private boolean gameOver;
	
	public SquareBoard(int xMax, int yMax)
	{
		this.xMax = xMax;
		this.yMax = yMax;
		coordLoc = new HashMap<>();
		coordPiece = new HashMap<>();
		gameOver = false;
		
	}
	
	public int getXMax()
	{
		return this.xMax;
	}
	public int getYMax()
	{
		return this.yMax;
	}
	/**
	 * This method is meant to set the player1 piece 
	 * count from the game builder
	 * @param player count obtained from builder
	 */
	public void setPlayer1Count(int count)
	{
		this.player1Count = count;
	}
	/**
	 * This method is meant to set the player2 piece 
	 * count from the game builder
	 * @param player count obtained from builder
	 */
	public void setPlayer2Count(int count)
	{
		this.player2Count = count;
	}

	/**
	 * This function takes in a desired coordinate set and returns the location
	 * type that is associated with it.
	 * @param coordinate
	 * @return LocationType
	 */
	public LocationType getLocationType(EscapeCoordinateImpl coordinate)
	{
		 return this.coordLoc.get(coordinate);
	}
	
	/**
	 * This function sets the specified coordinate to a specified type.
	 * @param coordinate
	 * @param Locationtype
	 */
	public void setLocationType(EscapeCoordinateImpl coordinate, LocationType type)
	{
		this.coordLoc.put(coordinate, type);
	}
	 

	/**
	 * This function gets the associated piece with the location that we are
	 * passing in. It is important to note that we can only get pieces for valid
	 * coordinates. Despite the fact that a manager can make whatever coordinate. 
	 * @param coordinate
	 * @return EscapePiece
	 */
	@Override
	public EscapePiece getPieceAt(EscapeCoordinateImpl coordinate) 
	{
		//we check if coordinates x and y is less than 1 because that is the first coordinate in the squareGame
		if (coordinate == null || coordinate.getX() > this.getXMax()|| coordinate.getY() > this.getYMax() || coordinate.getX() < 1 || coordinate.getY() < 1)
		{
			return null;
		}
		
		return coordPiece.get(coordinate);
	}

	/**
	 * This function puts the specified piece at the specified location.
	 * This will be helpful for all boards.
	 * @param piece
	 * @param coord
	 */
	@Override
	public void putPieceAt(EscapePiece piece, EscapeCoordinateImpl coord) 
	{
		this.coordPiece.put(coord, piece);	
	}
	
	/**
	 * Make the move in the current game.
	 * @param from starting location
	 * @param to ending location
	 * @return true if the move was legal, false otherwise
	 */
	
	public boolean move(EscapeCoordinateImpl from, EscapeCoordinateImpl to)
	{
		//we have to handle the false statements first
		EscapePiece whichPiece = this.getPieceAt(from);
		EscapePieceImpl casterPiece = (EscapePieceImpl) whichPiece;
		PathFindingImpl newPath = new PathFindingImpl(this);
		
		//System.out.println("Player 1 has: " + this.player1Count + " pieces.");
		//System.out.println("Player 2 has: " + this.player2Count + " pieces.");
		
		//preReqFalseConditions checks for all of the false cases before we actually move
		if(preReqFalseConditions(to, from, whichPiece))
		{
			return false;
		}
		
		//FLY with OMNI - all this needs to check is exit and opposing player 
		if(casterPiece.hasAttribute(PieceAttributeID.FLY) && 
				casterPiece.getMovementPattern() == MovementPattern.OMNI
				&& from.DistanceTo(to) <= casterPiece.getVal())
		{
			//if we land on exit
			exitLocOppoPlayerMove(this.getLocationType(to), whichPiece, to, from);
			return true;
		}
		
		//pathFindingMoves determines the attributes that require pathfinding
		if(pathFindingMoves(casterPiece, to, from))
		{
			//if they require pathfinding then we check to see if there is a path
			if(isThereAPath(newPath, casterPiece, from, to))
			{
				return true; //if there is, return true
			}
			
			return false; //if not then return false
		}
		return false;
		
	}
	
	/**
	 * This method runs the path finding algorithm if a piece has certain attributes.
	 * If the return isn't null then we know that the move is possible and we should
	 * place our piece at the correct location. This is also where the players counts
	 * will be decremented.  
	 * @param p PathFindingImpl to call the finding algorithm with
	 * @param piece
	 * @param from
	 * @param to
	 * @return
	 */
	public boolean isThereAPath(PathFindingImpl p, EscapePieceImpl piece, EscapeCoordinateImpl from, EscapeCoordinateImpl to)
	{
		if(p.findPath(piece, from, to) != null)
		{
			if(this.getLocationType(to) == LocationType.EXIT)
			{
				this.coordPiece.remove(from);
				player1Turn = !player1Turn;
				return true;
			}
			this.putPieceAt(piece, to);
			this.putPieceAt(null, from); //removes the piece from
			player1Turn = !player1Turn;
			return true;
		}
		else
		{
			return false;
		}
	}
	/**
	 * This method is to delegate the false conditions from the main check. 
	 * It goes through and checks to see if there are certain false board conditions.
	 * @param to
	 * @param from
	 * @param whichPiece
	 * @return true if there is a false condition, false otherwise
	 */
	public boolean preReqFalseConditions(EscapeCoordinateImpl to, EscapeCoordinateImpl from, EscapePiece whichPiece)
	{
		if((from == null || to == null)
				||(this.coordPiece.get(from) == null)
				||((whichPiece.getPlayer() == Player.PLAYER1) != player1Turn)
				||(from.getX() == to.getX() && from.getY() == to.getY())
				||(from.getX() > this.xMax || from.getY() > this.yMax || to.getX() > this.xMax || to.getY() > this.yMax)
				||(from.getX() < 1 || from.getY() < 1 || to.getX() < 1 || to.getY() < 1)
				||((this.getPieceAt(to)!= null) && this.getPieceAt(to).getPlayer() == whichPiece.getPlayer())
				||(this.getLocationType(to) != null && this.getLocationType(to) == LocationType.BLOCK))
		{
			return true;
		}
		
		return false; // none of the false conditions are met
	}
	/**
	 * This method checks to see if the location is of type exit, and if it 
	 * is then we remove the piece and toggle the player. In addition,
	 * if the piece is not an exit, then we are to put the piece at the 
	 * target location.
	 * @param locationType
	 * @param whichPiece
	 * @param to
	 * @param from
	 */
	public void exitLocOppoPlayerMove(LocationType locationType, EscapePiece whichPiece, EscapeCoordinateImpl to, EscapeCoordinateImpl from)
	{
		if ((this.getLocationType(to)== LocationType.EXIT)) 
		{
			this.coordPiece.remove(from);
			player1Turn = !player1Turn;
		}
		//if we land on valid piece or opposing players piece
		this.putPieceAt(whichPiece, to);
		this.putPieceAt(null, from); //removes the piece from
		player1Turn = !player1Turn;
		
	}
	/**
	 * This function operates very similar to the false conditions where we check 
	 * what attributes are valid to run the path finder on.
	 * @param casterPiece
	 * @param to
	 * @param from
	 * @return true if we want to run the path finder, and false otherwise.
	 */
	public boolean pathFindingMoves(EscapePieceImpl casterPiece, EscapeCoordinateImpl to, EscapeCoordinateImpl from)
	{
		if(((//the first handles FLY with DIAG and ORTHO
				casterPiece.hasAttribute(PieceAttributeID.FLY) && 
				casterPiece.getMovementPattern() == MovementPattern.DIAGONAL)
				|| (casterPiece.hasAttribute(PieceAttributeID.FLY) && 
						casterPiece.getMovementPattern() == MovementPattern.ORTHOGONAL))
				|| //this is where we begin the second check
				//the second handles DISTANCE with OMNI, ORTHO, and DIAG 
				casterPiece.getMovementPattern() == MovementPattern.OMNI
				|| casterPiece.getMovementPattern() == MovementPattern.ORTHOGONAL
						|| casterPiece.getMovementPattern() == MovementPattern.DIAGONAL
				&& casterPiece.hasAttribute(PieceAttributeID.DISTANCE)
				|| casterPiece.hasAttribute(PieceAttributeID.JUMP))
		{
			return true;
		}
		return false;
	}
	/**
	 * This method checks to see if the player count is less than or equal
	 * to 0 and if it is then the game is over.
	 * @return true if the game is over and false otherwise 
	 */
	public boolean gameOverCheck()
	{
		if(player1Count <= 0 || player2Count <= 0)
		{
			gameOver = true;
		}
		if (gameOver)
		{
			return true;
		}
		return false;
	}

}
