package board;

import java.util.Map;

import coordinate.Coordinate;
import coordinate.EscapeCoordinateImpl;
import coordinate.SquareCoordinate;
import piece.EscapePiece;

public interface EscapeBoard<C extends Coordinate> 
{
	int getXMax();
	int getYMax();
	void setPlayer1Count(int count);
	void setPlayer2Count(int count);
	/**
	 * This function takes in a desired coordinate set and returns the location
	 * type that is associated with it.
	 * @param coordinate
	 * @return LocationType
	 */
	LocationType getLocationType(EscapeCoordinateImpl coordinate);
	/**
	 * This function sets the specified coordinate to a specified type.
	 * @param coordinate
	 * @param Locationtype
	 */
	void setLocationType(EscapeCoordinateImpl coordinate, LocationType type);
	/**
	 * this function gets the associated piece with the location that we are
	 * passing in. This will be helpful for all boards.
	 * @param coordinate
	 * @return EscapePiece
	 */
	EscapePiece getPieceAt(C coordinate);
	/**
	 * This function puts the specified piece at the specified location.
	 * This will be helpful for all boards.
	 * @param piece
	 * @param coord
	 */
	void putPieceAt(EscapePiece piece, EscapeCoordinateImpl coord);
	/**
	 * Make the move in the current game.
	 * @param from starting location
	 * @param to ending location
	 * @return true if the move was legal, false otherwise
	 */
	boolean move(EscapeCoordinateImpl from, EscapeCoordinateImpl to);
}
