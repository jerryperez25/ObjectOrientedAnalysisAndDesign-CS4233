package piece;

public class EscapePieceImpl implements EscapePiece 
{
	private PieceName name;
	private Player playerWho;
	private MovementPattern mp;
	private PieceAttribute[] pa;
	
	public EscapePieceImpl(Player playerWho, PieceName name, MovementPattern mp, PieceAttribute[] pa)
	{
		this.name = name;
		this.playerWho = playerWho;
		this.mp = mp;
		this.pa = pa;
	}
	/**
	 * @return the name
	 */
	public PieceName getName()
	{
		return this.name;
	}
	/**
	 * @return the player
	 */
	public Player getPlayer()
	{
		return this.playerWho;
	}
	public MovementPattern getMovementPattern()
	{
		return this.mp;
	}
	/**
	 * This function gets the value associated with FLY or DISTANCE
	 * @return piece attribute value
	 */
	public int getVal()
	{
		if(hasAttribute(PieceAttributeID.FLY))
		{
			for (PieceAttribute pdLooper : pa)
			{
				if(pdLooper.id == PieceAttributeID.FLY)
				{
					
					return pdLooper.getValue();
				}
			}
		}
		for(PieceAttribute pdLooper : pa)
		{
			if(pdLooper.id == PieceAttributeID.DISTANCE)
			{
				return pdLooper.getValue();
			}
		}
		return -1;
	}
	
	/**
	 * This function determines whether or not the piece has the given attribute  
	 * @param pid
	 * @return true if it does have the target attribute and false if not
	 */
	public boolean hasAttribute(PieceAttributeID pid)
	{
		for (PieceAttribute pdLooper : pa)
		{
			if(pdLooper.id == pid)
			{
				return true;
			}
		}
		return false;
	}
}
