/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Copyright ©2016 Gary F. Pollice
 *******************************************************************************/

package escape;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;

import java.util.LinkedList;
import java.util.List;

import org.junit.jupiter.api.Test;

import board.SquareBoard;
import coordinate.Coordinate.CoordinateType;
import manager.EscapeGameManager;
import manager.EscapeGameManagerImpl;
import pathFinding.Path;
import piece.Player;
import piece.EscapePiece;
import piece.EscapePiece.MovementPattern;
import piece.EscapePiece.PieceAttributeID;
import piece.EscapePiece.PieceName;
import piece.EscapePieceImpl;
import coordinate.Coordinate;
import coordinate.CoordinateFactory;
import coordinate.EscapeCoordinateImpl;
import coordinate.EscapeCoordinateImpl.CompassRose;
import coordinate.SquareCoordinate;
import coordinate.TriangleCoord;

/**
 * This is a simple test, not really a unit test, to make sure tht the
 * EscapeGameBuilder, in the starting code, is actually working.
 * 
 * @version May 30, 2020
 */
class EscapeBetaTest
{
	
	@Test
	void createTriangleCoordinate5_2()
	{
		assertNotNull(new TriangleCoord(5,2));
	}
	
	@Test
	void createTriangleCoordinate5_2WithCoordinateFactory()
	{
		assertNotNull(CoordinateFactory.makeCoordinate(CoordinateType.TRIANGLE, 5, 2));
	}
	
	@Test
	void checkTriangleGameUsingTriangleCoordinate() throws Exception
	{
	
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		TriangleCoord newOne = new TriangleCoord(4,4);
		assertEquals(newOne, egm.makeCoordinate(4, 4));
	}
	@Test
	void checkTriangleGameNoTriangleCoordinate() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		assertNotNull(egm.makeCoordinate(8, 8));
	}
	
	@Test
	void getXandYTriangleCoordinate5_2()
	{
		TriangleCoord five_two = new TriangleCoord(5,2);
		assertEquals(5, five_two.getX());
		assertEquals(2, five_two.getY());
	}
	
	@Test
	void testingEqualsMethodInstance()
	{
		TriangleCoord five_two = new TriangleCoord(5,2);
		SquareCoordinate sqfive_two = new SquareCoordinate(5,2);
		assertFalse(five_two.equals(sqfive_two));
		assertTrue(five_two.equals(five_two));
	}
	
	@Test
	void distance1_1To3_0() //downward source to upward target; look above
	{
		TriangleCoord one_one = new TriangleCoord(1,1);
		TriangleCoord three_zero = new TriangleCoord(3,0);
		assertEquals(3, one_one.DistanceTo(three_zero));
	}
	@Test
	void distance1_1To4_2() //downward source to downward target; look above
	{
		TriangleCoord one_one = new TriangleCoord(1,1);
		TriangleCoord four_two = new TriangleCoord(4,2);
		assertEquals(6, one_one.DistanceTo(four_two));
	}
	@Test
	void distance1_2To4_1() //upward source to upward target; look above
	{
		TriangleCoord one_two = new TriangleCoord(1,2);
		TriangleCoord four_one = new TriangleCoord(4,1);
		assertEquals(6, one_two.DistanceTo(four_one));
	}
	@Test
	void distance1_2To4_0() //upward source to downward target; look above
	{
		TriangleCoord one_two = new TriangleCoord(1,2);
		TriangleCoord four_zero = new TriangleCoord(4,0);
		assertEquals(7, one_two.DistanceTo(four_zero));
	}
	@Test
	void distance1_1ToNeg2_3() //downward source to upward target; look down
	{
		TriangleCoord one_one = new TriangleCoord(1,1);
		TriangleCoord negtwo_three = new TriangleCoord(-2,3);
		assertEquals(7, one_one.DistanceTo(negtwo_three));
	}
	@Test
	void distance1_1ToNeg2_2() //downward source to downward target; look down
	{
		TriangleCoord one_one = new TriangleCoord(1,1);
		TriangleCoord negtwo_two = new TriangleCoord(-2,2);
		assertEquals(6, one_one.DistanceTo(negtwo_two));
	}
	@Test
	void distance1_2ToNeg2_3() //up source to up target; look down
	{
		TriangleCoord one_two = new TriangleCoord(1,2);
		TriangleCoord negtwo_three = new TriangleCoord(-2,3);
		assertEquals(6, one_two.DistanceTo(negtwo_three));
	}
	@Test
	void distance1_2ToNeg2_0() //up source to down target; look down
	{
		TriangleCoord one_two = new TriangleCoord(1,2);
		TriangleCoord negtwo_zero = new TriangleCoord(-2,0);
		assertEquals(5, one_two.DistanceTo(negtwo_zero));
	}
	@Test
	void distance1_1To2_8() 
	{
		TriangleCoord one_one = new TriangleCoord(1,1);
		TriangleCoord two_eight = new TriangleCoord(2,8);
		assertEquals(8, one_one.DistanceTo(two_eight));
	}
	@Test
	void distanceNeg1_1To3_Neg5() 
	{
		TriangleCoord negone_one = new TriangleCoord(-1,1);
		TriangleCoord three_negfive = new TriangleCoord(3,-5);
		assertEquals(10, negone_one.DistanceTo(three_negfive));
	}
	@Test
	void distance2_5To8_12() 
	{
		TriangleCoord two_five = new TriangleCoord(2,5);
		TriangleCoord eight_twelve = new TriangleCoord(8,12);
		assertEquals(13, two_five.DistanceTo(eight_twelve));
	}
	//upward source
	@Test
	void distanceUp1_0To2_0() 
	{
		TriangleCoord one_zero = new TriangleCoord(1,0);
		TriangleCoord two_zero = new TriangleCoord(2,0);
		assertEquals(3, one_zero.DistanceTo(two_zero));
	}
	@Test
	void distanceUp1_0To3_0() 
	{
		TriangleCoord one_zero = new TriangleCoord(1,0);
		TriangleCoord three_zero = new TriangleCoord(3,0);
		assertEquals(4, one_zero.DistanceTo(three_zero));
	}
	@Test
	void distanceUp1_0To4_0() 
	{
		TriangleCoord one_zero = new TriangleCoord(1,0);
		TriangleCoord four_zero = new TriangleCoord(4,0);
		assertEquals(7, one_zero.DistanceTo(four_zero));
	}
	@Test
	void distanceUp1_0ToNeg2_0() 
	{
		TriangleCoord one_zero = new TriangleCoord(1,0);
		TriangleCoord negtwo_zero = new TriangleCoord(-2,0);
		assertEquals(5, one_zero.DistanceTo(negtwo_zero));
	}
	@Test
	void distanceUp1_0ToNeg3_0() 
	{
		TriangleCoord one_zero = new TriangleCoord(1,0);
		TriangleCoord negthree_zero = new TriangleCoord(-3,0);
		assertEquals(8, one_zero.DistanceTo(negthree_zero));
	}
	@Test
	void distanceUp1_0ToNeg4_0() 
	{
		TriangleCoord one_zero = new TriangleCoord(1,0);
		TriangleCoord negfour_zero = new TriangleCoord(-4,0);
		assertEquals(9, one_zero.DistanceTo(negfour_zero));
	}
	//downward source
	@Test
	void distanceDown0_0To2_0() 
	{
		TriangleCoord zero_zero = new TriangleCoord(0,0);
		TriangleCoord two_zero = new TriangleCoord(2,0);
		assertEquals(4, zero_zero.DistanceTo(two_zero));
	}
	@Test
	void distanceDown0_0To3_0() 
	{
		TriangleCoord zero_zero = new TriangleCoord(0,0);
		TriangleCoord three_zero = new TriangleCoord(3,0);
		assertEquals(5, zero_zero.DistanceTo(three_zero));
	}
	@Test
	void distanceDown0_0To4_0() 
	{
		TriangleCoord zero_zero = new TriangleCoord(0,0);
		TriangleCoord four_zero = new TriangleCoord(4,0);
		assertEquals(8, zero_zero.DistanceTo(four_zero));
	}
	@Test
	void distanceDown0_0ToNeg2_0() 
	{
		TriangleCoord zero_zero = new TriangleCoord(0,0);
		TriangleCoord negtwo_zero = new TriangleCoord(-2,0);
		assertEquals(4, zero_zero.DistanceTo(negtwo_zero));
	}
	@Test
	void distanceDown0_0ToNeg3_0() 
	{
		TriangleCoord zero_zero = new TriangleCoord(0,0);
		TriangleCoord negthree_zero = new TriangleCoord(-3,0);
		assertEquals(7, zero_zero.DistanceTo(negthree_zero));
	}
	@Test
	void distanceDown0_0ToNeg4_0() 
	{
		TriangleCoord zero_zero = new TriangleCoord(0,0);
		TriangleCoord negfour_zero = new TriangleCoord(-4,0);
		assertEquals(8, zero_zero.DistanceTo(negfour_zero));
	}
	
	@Test
	void getPlayer1SnailAt4_4() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate four_four = new TriangleCoord(4,4);
		
		
		assertEquals(Player.PLAYER1, egm.getPieceAt(four_four).getPlayer());
		assertEquals(PieceName.SNAIL, egm.getPieceAt(four_four).getName());
	}
	@Test
	void getPlayer2HorseAt10_12() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		
		Coordinate ten_twelve = new TriangleCoord(10,12);
		
		assertEquals(Player.PLAYER2, egm.getPieceAt(ten_twelve).getPlayer());
		assertEquals(PieceName.HORSE, egm.getPieceAt(ten_twelve).getName());
	}
	@Test
	void getNullPiece() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate zero_zero = new TriangleCoord(0,0);
		
		assertNull(egm.getPieceAt(zero_zero));
	}
	@Test
	void checkGetPieceAtBorderUpperLimit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3TriReplica.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate border = egm.makeCoordinate(25,20);
		assertNotNull(egm.getPieceAt(border)); //gets the piece at the border
	}
	@Test
	void checkGetPieceAtNull() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3TriReplica.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate nuller = null;
		assertNull(egm.getPieceAt(nuller));
	}
	@Test
	void checkGetPieceAtNoPiece() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3TriReplica.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate noPiece = egm.makeCoordinate(3,4); //no piece here
		assertNull(egm.getPieceAt(noPiece));
	}
	
	@Test
	void checkGetPieceAtOutOfBoundsX() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3TriReplica.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(26,20);
		assertNull(egm.getPieceAt(outOfBounds));
	}
	@Test
	void checkGetPieceAtOutOfBoundsY() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3TriReplica.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(25,21);
		assertNull(egm.getPieceAt(outOfBounds));
	}
	@Test
	void checkGetPieceAtOutOfBoundsXAndY() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3TriReplica.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(26,21);
		assertNull(egm.getPieceAt(outOfBounds));
	}
	@Test
	void checkGetPieceAtOutOfBounds0_0() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3TriReplica.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(0,0);
		assertNull(egm.getPieceAt(outOfBounds));
	}
	@Test
	void checkGetPieceAtOutOfBounds0_1() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3TriReplica.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(0,1);
		assertNull(egm.getPieceAt(outOfBounds));
	}
	@Test
	void checkGetPieceAtOutOfBounds1_0() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3TriReplica.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(1,0);
		assertNull(egm.getPieceAt(outOfBounds));
	}
	@Test
	void checkGetPieceAtOutOfBoundsNegative() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3TriReplica.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(-8,-5);
		assertNull(egm.getPieceAt(outOfBounds));
	}
	@Test
	void checkInfiniteBoard() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/infiniteTriBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate neg800_500 = egm.makeCoordinate(-800, 500);
		assertEquals(Player.PLAYER1, egm.getPieceAt(neg800_500).getPlayer());
		assertEquals(PieceName.FROG, egm.getPieceAt(neg800_500).getName());
	}
	
	@Test
	void getMovementPatternAtTriangle6_2() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3TriReplica.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate six_two = egm.makeCoordinate(6,2);
		EscapePieceImpl newPiece = (EscapePieceImpl)egm.getPieceAt(six_two);
		assertEquals(MovementPattern.OMNI, newPiece.getMovementPattern());
	}
	@Test
	void getMovementPatternAtSquare6_2() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate six_two = egm.makeCoordinate(6,2);
		EscapePieceImpl newPiece = (EscapePieceImpl)egm.getPieceAt(six_two);
		assertEquals(MovementPattern.DIAGONAL, newPiece.getMovementPattern());
	}
	@Test
	void triangleBoardFromCoordinateNull() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate nuller = null;
		Coordinate eight_eight = egm.makeCoordinate(4, 4);
		assertFalse(egm.move(nuller, eight_eight));
	}
	@Test
	void triangleBoardToCoordinateNull() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate nuller = null;
		Coordinate four_four = egm.makeCoordinate(4, 4);
		assertFalse(egm.move(four_four, nuller));
	}
	@Test
	void triangleBoardNoPieceOnFrom() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate four_four = egm.makeCoordinate(4, 4);
		Coordinate eight_eight = egm.makeCoordinate(8, 8);
		assertFalse(egm.move(eight_eight, four_four));
	}
	@Test
	void triangleBoardToAndFromSame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate four_four = egm.makeCoordinate(4, 4);
		Coordinate anotherfour_four = egm.makeCoordinate(4, 4);
		assertFalse(egm.move(four_four, anotherfour_four));
	}
	@Test
	void checkMoveToOutOfBoundsX() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(26,20);
		Coordinate four_four = egm.makeCoordinate(4, 4);
		assertFalse(egm.move(four_four, outOfBounds));
	}
	@Test
	void checkMoveToOutOfBoundsY() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(25,21);
		Coordinate four_four = egm.makeCoordinate(4, 4);
		assertFalse(egm.move(four_four, outOfBounds));
	}
	@Test
	void checkMoveToOutOfBoundsXAndY() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(26,21);
		Coordinate four_four = egm.makeCoordinate(4, 4);
		assertFalse(egm.move(four_four, outOfBounds));
	}
	@Test
	void checkMoveToOutOfBounds0_0() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(0,0);
		Coordinate four_four = egm.makeCoordinate(4, 4);
		assertFalse(egm.move(four_four, outOfBounds));
	}
	@Test
	void checkMoveToOutOfBounds0_1() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(0,1);
		Coordinate four_four = egm.makeCoordinate(4, 4);
		assertFalse(egm.move(four_four, outOfBounds));
	}
	@Test
	void checkMoveToOutOfBounds1_0() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(1,0);
		Coordinate four_four = egm.makeCoordinate(4, 4);
		assertFalse(egm.move(four_four, outOfBounds));
	}
	@Test
	void checkMoveToOutOfBoundsNegative() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(-8,-5);
		Coordinate four_four = egm.makeCoordinate(4, 4);
		assertFalse(egm.move(four_four, outOfBounds));
	}
	@Test
	void existingPlayerSpotLand() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate four_four = egm.makeCoordinate(4, 4);
		Coordinate nine_one = egm.makeCoordinate(9, 1);
		assertFalse(egm.move(four_four, nine_one));
	}
	@Test
	void playerMovesToBlock() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate four_four = egm.makeCoordinate(4, 4);
		Coordinate blocker = egm.makeCoordinate(3, 5);
		assertFalse(egm.move(four_four, blocker));
	}
	@Test
	void player1MovesPlayer2Piece() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate eight_twelve = egm.makeCoordinate(8, 12);
		Coordinate ten_twelve = egm.makeCoordinate(10, 12); // player 2's piece
		assertFalse(egm.move(ten_twelve, eight_twelve));
	}
	@Test
	void getTriangleNeighborsFor2_5ObjectCheck() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate two_five = egm.makeCoordinate(2, 5);
		TriangleCoord caster = (TriangleCoord) two_five;
		TriangleCoord neighbor1 = new TriangleCoord(1, 5);
		Coordinate neighbor2 = egm.makeCoordinate(2, 4);
		Coordinate neighbor3 = egm.makeCoordinate(2, 6);
		assertTrue(neighbor1.equals(caster.getNeighbors()[0]));//same object - so far so good
		assertTrue(neighbor2.equals(caster.getNeighbors()[1]));
		assertTrue(neighbor3.equals(caster.getNeighbors()[2]));
	}
	@Test
	void getTriangleNeighborsFor2_5ValueCheck() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate two_five = egm.makeCoordinate(2, 5);
		TriangleCoord caster = (TriangleCoord) two_five;
		TriangleCoord neighbor1 = new TriangleCoord(1, 5);
		TriangleCoord neighbor2 = new TriangleCoord(2, 4);
		TriangleCoord neighbor3 = new TriangleCoord(2, 6);
		assertEquals(neighbor1.getX(),caster.getNeighbors()[0].getX());
		assertEquals(neighbor1.getY(),caster.getNeighbors()[0].getY());
		assertEquals(neighbor2.getX(),caster.getNeighbors()[1].getX());
		assertEquals(neighbor2.getY(),caster.getNeighbors()[1].getY());
		assertEquals(neighbor3.getX(),caster.getNeighbors()[2].getX());
		assertEquals(neighbor3.getY(),caster.getNeighbors()[2].getY());
	}
	@Test
	void getTriangleNeighborsFor2_4ObjectCheck() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate two_four = egm.makeCoordinate(2, 4);
		TriangleCoord caster = (TriangleCoord) two_four;
		TriangleCoord neighbor1 = new TriangleCoord(2, 3);
		Coordinate neighbor2 = egm.makeCoordinate(2, 5);
		Coordinate neighbor3 = egm.makeCoordinate(3, 4);
		assertTrue(neighbor1.equals(caster.getNeighbors()[0]));//same object - so far so good
		assertTrue(neighbor2.equals(caster.getNeighbors()[1]));
		assertTrue(neighbor3.equals(caster.getNeighbors()[2]));
	}
	@Test
	void getTriangleNeighborsFor2_4ValueCheck() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate two_four = egm.makeCoordinate(2, 4);
		TriangleCoord caster = (TriangleCoord) two_four;
		TriangleCoord neighbor1 = new TriangleCoord(2, 3);
		TriangleCoord neighbor2 = new TriangleCoord(2, 5);
		TriangleCoord neighbor3 = new TriangleCoord(3, 4);
		assertEquals(neighbor1.getX(),caster.getNeighbors()[0].getX());
		assertEquals(neighbor1.getY(),caster.getNeighbors()[0].getY());
		assertEquals(neighbor2.getX(),caster.getNeighbors()[1].getX());
		assertEquals(neighbor2.getY(),caster.getNeighbors()[1].getY());
		assertEquals(neighbor3.getX(),caster.getNeighbors()[2].getX());
		assertEquals(neighbor3.getY(),caster.getNeighbors()[2].getY());
	}
	@Test
	void getSquareNeighborsFor4_4ObjectCheck() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate four_four = egm.makeCoordinate(4, 4);
		SquareCoordinate caster = (SquareCoordinate) four_four;
		SquareCoordinate neighbor1 = new SquareCoordinate(3, 3);
		SquareCoordinate neighbor2 = new SquareCoordinate(3, 4);
		SquareCoordinate neighbor3 = new SquareCoordinate(3, 5);
		SquareCoordinate neighbor4 = new SquareCoordinate(4, 3);
		SquareCoordinate neighbor5 = new SquareCoordinate(4, 5);
		SquareCoordinate neighbor6 = new SquareCoordinate(5, 3);
		SquareCoordinate neighbor7 = new SquareCoordinate(5, 4);
		SquareCoordinate neighbor8 = new SquareCoordinate(5, 5);
		assertTrue(neighbor1.equals(caster.getNeighbors()[0]));
		assertTrue(neighbor2.equals(caster.getNeighbors()[1]));
		assertTrue(neighbor3.equals(caster.getNeighbors()[2]));
		assertTrue(neighbor4.equals(caster.getNeighbors()[3]));
		assertTrue(neighbor5.equals(caster.getNeighbors()[4]));
		assertTrue(neighbor6.equals(caster.getNeighbors()[5]));
		assertTrue(neighbor7.equals(caster.getNeighbors()[6]));
		assertTrue(neighbor8.equals(caster.getNeighbors()[7]));
	}
	@Test
	void getSquareNeighborsFor4_4ValueCheck() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate four_four = egm.makeCoordinate(4, 4);
		SquareCoordinate caster = (SquareCoordinate) four_four;
		SquareCoordinate neighbor1 = new SquareCoordinate(3, 3);
		SquareCoordinate neighbor2 = new SquareCoordinate(3, 4);
		SquareCoordinate neighbor3 = new SquareCoordinate(3, 5);
		SquareCoordinate neighbor4 = new SquareCoordinate(4, 3);
		SquareCoordinate neighbor5 = new SquareCoordinate(4, 5);
		SquareCoordinate neighbor6 = new SquareCoordinate(5, 3);
		SquareCoordinate neighbor7 = new SquareCoordinate(5, 4);
		SquareCoordinate neighbor8 = new SquareCoordinate(5, 5);
		assertEquals(neighbor1.getX(), caster.getNeighbors()[0].getX());
		assertEquals(neighbor1.getY(), caster.getNeighbors()[0].getY());
		assertEquals(neighbor2.getX(), caster.getNeighbors()[1].getX());
		assertEquals(neighbor2.getY(), caster.getNeighbors()[1].getY());
		assertEquals(neighbor3.getX(), caster.getNeighbors()[2].getX());
		assertEquals(neighbor3.getY(), caster.getNeighbors()[2].getY());
		assertEquals(neighbor4.getX(), caster.getNeighbors()[3].getX());
		assertEquals(neighbor4.getY(), caster.getNeighbors()[3].getY());
		assertEquals(neighbor5.getX(), caster.getNeighbors()[4].getX());
		assertEquals(neighbor5.getY(), caster.getNeighbors()[4].getY());
		assertEquals(neighbor6.getX(), caster.getNeighbors()[5].getX());
		assertEquals(neighbor6.getY(), caster.getNeighbors()[5].getY());
		assertEquals(neighbor7.getX(), caster.getNeighbors()[6].getX());
		assertEquals(neighbor7.getY(), caster.getNeighbors()[6].getY());
		assertEquals(neighbor8.getX(), caster.getNeighbors()[7].getX());
		assertEquals(neighbor8.getY(), caster.getNeighbors()[7].getY());
	}
	@Test
	void getDirectionToNorthSquare()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate seven_four = new SquareCoordinate (7,4);
		assertEquals(CompassRose.NORTH, four_four.getDirectionTo(seven_four));
	}
	@Test
	void getDirectionToSouthSquare()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate one_four = new SquareCoordinate (1,4);
		assertEquals(CompassRose.SOUTH, four_four.getDirectionTo(one_four));
	}
	@Test
	void getDirectionToEastSquare()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate four_seven = new SquareCoordinate (4, 7);
		assertEquals(CompassRose.EAST, four_four.getDirectionTo(four_seven));
	}
	@Test
	void getDirectionToWestSquare()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate four_one = new SquareCoordinate (4, 1);
		assertEquals(CompassRose.WEST, four_four.getDirectionTo(four_one));
	}
	@Test
	void getDirectionToNorthEastSquare()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate eight_eight = new SquareCoordinate (8, 8);
		assertEquals(CompassRose.NORTHEAST, four_four.getDirectionTo(eight_eight));
	}
	@Test
	void getDirectionToNorthWestSquare()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate six_two = new SquareCoordinate (6, 2);
		assertEquals(CompassRose.NORTHWEST, four_four.getDirectionTo(six_two));
	}
	@Test
	void getDirectionToSouthEastSquare()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate three_five = new SquareCoordinate (3,5);
		assertEquals(CompassRose.SOUTHEAST, four_four.getDirectionTo(three_five));
	}
	@Test
	void getDirectionToSouthWestSquare()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate one_one = new SquareCoordinate (1, 1);
		assertEquals(CompassRose.SOUTHWEST, four_four.getDirectionTo(one_one));
	}
	@Test
	void getDirectionToNoneSquare()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate one_five = new SquareCoordinate (1, 5);
		assertEquals(CompassRose.NONE, four_four.getDirectionTo(one_five));
	}
	@Test
	void getDirectionToSameColumnTriangle()
	{
		TriangleCoord  four_five = new TriangleCoord(4,5);
		TriangleCoord  three_five = new TriangleCoord(3,5);
		TriangleCoord  two_five = new TriangleCoord(2,5);
		TriangleCoord  one_five = new TriangleCoord(1,5);
		assertEquals(CompassRose.NONE, two_five.getDirectionTo(one_five)); // up tri moves up to down tri
		assertEquals(CompassRose.NONE, two_five.getDirectionTo(three_five)); // up tri moves down to down tri
		assertEquals(CompassRose.NONE, three_five.getDirectionTo(four_five)); //down tri moves up to up tri
		assertEquals(CompassRose.NONE, three_five.getDirectionTo(two_five)); // down tri moves down to up tri
	}
	@Test
	void upSourceLowerLeftTargetGetDirectionToTriangle()
	{
		TriangleCoord  two_five = new TriangleCoord(2,5);
		TriangleCoord  negone_three = new TriangleCoord(-1,3);
		assertEquals(CompassRose.NONE, two_five.getDirectionTo(negone_three));
	}
	@Test
	void upSourceLowerRightTargetGetDirectionToTriangle()
	{
		TriangleCoord  two_five = new TriangleCoord(2,5);
		TriangleCoord  zero_seven = new TriangleCoord(-1,7);
		assertEquals(CompassRose.NONE, two_five.getDirectionTo(zero_seven));
	}
	@Test
	void upSourceUpTargetGetDirectionToNorthEastTriangle()
	{
		TriangleCoord  two_five = new TriangleCoord(2,5);
		TriangleCoord  five_eight = new TriangleCoord(5,8);
		assertEquals(CompassRose.NORTHEAST, two_five.getDirectionTo(five_eight));
	}
	@Test
	void upSourceUpTargetGetDirectionToNorthWestTriangle()
	{
		TriangleCoord  two_five = new TriangleCoord(2,5);
		TriangleCoord  four_three = new TriangleCoord(4,3);
		assertEquals(CompassRose.NORTHWEST, two_five.getDirectionTo(four_three));
	}
	@Test
	void upSourceDownTargetGetDirectionToNorthEastTriangle()
	{
		TriangleCoord  two_five = new TriangleCoord(2,5);
		TriangleCoord  four_eight = new TriangleCoord(4,8);
		assertEquals(CompassRose.NORTHEAST, two_five.getDirectionTo(four_eight));
	}
	@Test
	void upSourceDownTargetGetDirectionToNorthWestTriangle()
	{
		TriangleCoord  two_five = new TriangleCoord(2,5);
		TriangleCoord  six_zero = new TriangleCoord(6,0);
		assertEquals(CompassRose.NORTHWEST, two_five.getDirectionTo(six_zero));
	}
	@Test
	void downSourceUpperLeftTargetGetDirectionToTriangle()
	{
		TriangleCoord  three_five = new TriangleCoord(3,5);
		TriangleCoord  seven_nine = new TriangleCoord(7,9);
		assertEquals(CompassRose.NONE, three_five.getDirectionTo(seven_nine));
	}
	@Test
	void downSourceUpperRightTargetGetDirectionToTriangle()
	{
		TriangleCoord  three_five = new TriangleCoord(3,5);
		TriangleCoord  eight_one = new TriangleCoord(8,1);
		assertEquals(CompassRose.NONE, three_five.getDirectionTo(eight_one));
	}
	@Test
	void downSourceDownTargetGetDirectionToSouthWestTriangle()
	{
		TriangleCoord  three_five = new TriangleCoord(3,5);
		TriangleCoord  zero_two = new TriangleCoord(0,2);
		assertEquals(CompassRose.SOUTHWEST, three_five.getDirectionTo(zero_two));
	}
	//do third
	@Test
	void downSourceDownTargetGetDirectionToSouthEastTriangle()
	{
		TriangleCoord  three_five = new TriangleCoord(3,5);
		TriangleCoord  one_seven = new TriangleCoord(1,7);
		assertEquals(CompassRose.SOUTHEAST, three_five.getDirectionTo(one_seven));
	}
	@Test
	void downSourceUpTargetGetDirectionToSouthWestTriangle()
	{
		TriangleCoord  five_five = new TriangleCoord(5,5);
		TriangleCoord  two_one = new TriangleCoord(2, 1);
		assertEquals(CompassRose.SOUTHWEST, five_five.getDirectionTo(two_one));
	}
	@Test
	void downSourceUpTargetGetDirectionToSouthEastTriangle()
	{
		TriangleCoord  three_five = new TriangleCoord(3,5);
		TriangleCoord  two_seven = new TriangleCoord(2, 7);
		assertEquals(CompassRose.SOUTHEAST, three_five.getDirectionTo(two_seven));
	}
	
	@Test
	void equalSourceXLessSourceYTargetDownTriangle()
	{
		TriangleCoord  two_five = new TriangleCoord(2,5);
		TriangleCoord  two_ten = new TriangleCoord(2,10);
		assertEquals(CompassRose.EAST, two_five.getDirectionTo(two_ten));
	}
	@Test
	void equalSourceXLessSourceYTargetUpTriangle()
	{
		TriangleCoord  two_five = new TriangleCoord(2,5);
		TriangleCoord  two_eleven = new TriangleCoord(2,11);
		assertEquals(CompassRose.EAST, two_five.getDirectionTo(two_eleven));
	}
	@Test
	void equalSourceXGreaterSourceYTargetDownTriangle()
	{
		TriangleCoord  two_five = new TriangleCoord(2,5);
		TriangleCoord  two_zero = new TriangleCoord(2,0);
		assertEquals(CompassRose.WEST, two_five.getDirectionTo(two_zero));
	}
	@Test
	void equalSourceXGreaterSourceYTargetUpTriangle()
	{
		TriangleCoord  two_five = new TriangleCoord(2,5);
		TriangleCoord  two_one = new TriangleCoord(2,1);
		assertEquals(CompassRose.WEST, two_five.getDirectionTo(two_one));
	}
	@Test
	void randomUpSourceDownTargetNoDirectionChecker()
	{
		TriangleCoord  two_five = new TriangleCoord(2,5);
		TriangleCoord  three_nine = new TriangleCoord(3,9);
		assertEquals(CompassRose.NONE, two_five.getDirectionTo(three_nine));
	}
	@Test
	void randomUpSourceUpTargetNoDirectionChecker()
	{
		TriangleCoord  two_five = new TriangleCoord(2,5);
		TriangleCoord  five_twelve = new TriangleCoord(5,12);
		assertEquals(CompassRose.NONE, two_five.getDirectionTo(five_twelve));
	}
	@Test
	void randomDownSourceDownTargetNoDirectionChecker()
	{
		TriangleCoord  one_five = new TriangleCoord(1,5);
		TriangleCoord  negone_eleven = new TriangleCoord(3,9);
		assertEquals(CompassRose.NONE, one_five.getDirectionTo(negone_eleven));
	}
	@Test
	void randomDownSourceUpTargetNoDirectionChecker()
	{
		TriangleCoord  one_five = new TriangleCoord(1,5);
		TriangleCoord  negtwo_eleven = new TriangleCoord(-2,11);
		assertEquals(CompassRose.NONE, one_five.getDirectionTo(negtwo_eleven));
	}
	@Test
	void isLinearTo4_4To100_4SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate onehundred_four = new SquareCoordinate (100, 4);
		assertEquals(true, four_four.isLinearTo(onehundred_four));
	}
	@Test
	void isLinearTo4_4To8_5SquareNO()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate eight_five = new SquareCoordinate (8, 5);
		assertEquals(false, four_four.isLinearTo(eight_five));
	}
	@Test
	void isLinearTo4_4To100_4TriangleNO()
	{
		TriangleCoord four_four = new TriangleCoord (4,4);
		TriangleCoord onehundred_four = new TriangleCoord (100, 4);
		assertEquals(false, four_four.isLinearTo(onehundred_four));
	}
	@Test
	void isLinearTo4_4ToNeg100_4TriangleNO()
	{
		TriangleCoord four_four = new TriangleCoord (4,4);
		TriangleCoord negonehundred_four = new TriangleCoord (-100, 4);
		assertEquals(false, four_four.isLinearTo(negonehundred_four));
	}
	@Test
	void isLinearToDOWN4_4ToUPNeg1_10SOUTHEASTTriangleYES()
	{
		TriangleCoord four_four = new TriangleCoord (4,4);
		TriangleCoord negone_ten = new TriangleCoord (-1, 10);
		assertEquals(true, four_four.isLinearTo(negone_ten));
	}
	@Test
	void isLinearToDOWN4_4ToDOWN2_6SOUTHEASTTriangleYES()
	{
		TriangleCoord four_four = new TriangleCoord (4,4);
		TriangleCoord two_six = new TriangleCoord (2,6);
		assertEquals(true, four_four.isLinearTo(two_six));
	}
	@Test
	void isLinearToDOWN4_4ToUP3_2SOUTHWESTTriangleYES()
	{
		TriangleCoord four_four = new TriangleCoord (4,4);
		TriangleCoord three_two = new TriangleCoord (3, 2);
		assertEquals(true, four_four.isLinearTo(three_two));
	}
	@Test
	void isLinearToDOWN4_4ToDOWN1_1SOUTHWESTTriangleYES()
	{
		TriangleCoord four_four = new TriangleCoord (4,4);
		TriangleCoord one_one = new TriangleCoord (1,1);
		assertEquals(true, four_four.isLinearTo(one_one));
	}
	@Test
	void isLinearToUP2_1ToUP4_3NORTHEASTTriangleYES()
	{
		TriangleCoord two_one = new TriangleCoord (2,1);
		TriangleCoord four_three = new TriangleCoord (4,3);
		assertEquals(true, two_one.isLinearTo(four_three));
	}
	@Test
	void isLinearToUP2_1ToDOWN3_3NORTHEASTTriangleYES()
	{
		TriangleCoord two_one = new TriangleCoord (2,1);
		TriangleCoord three_three = new TriangleCoord (3,3);
		assertEquals(true, two_one.isLinearTo(three_three));
	}
	@Test
	void isLinearToUP2_5ToUP6_1NORTHWESTTriangleYES()
	{
		TriangleCoord two_five = new TriangleCoord (2,5);
		TriangleCoord six_one = new TriangleCoord (6,1);
		assertEquals(true, two_five.isLinearTo(six_one));
	}
	@Test
	void isLinearToUP2_5ToDOWN3_3NORTHWESTTriangleYES()
	{
		TriangleCoord two_five = new TriangleCoord (2,5);
		TriangleCoord four_two = new TriangleCoord (4,2);
		assertEquals(true, two_five.isLinearTo(four_two));
	}
	@Test
	void isOrthagonalTo4_4To7_4SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate seven_four = new SquareCoordinate (7, 4);
		assertTrue(four_four.isOrthagonalTo(seven_four));
	}
	@Test
	void isOrthagonalTo4_4To4_1SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate four_one = new SquareCoordinate (4, 1);
		assertTrue(four_four.isOrthagonalTo(four_one));
	}
	@Test
	void isOrthagonalTo4_4To4_5SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate four_five = new SquareCoordinate (4, 5);
		assertTrue(four_four.isOrthagonalTo(four_five));
	}
	@Test
	void isOrthagonalTo4_4To2_4SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate two_four = new SquareCoordinate (2, 4);
		assertTrue(four_four.isOrthagonalTo(two_four));
	}
	@Test
	void isOrthagonalTo4_4To2_4TriangleNO()
	{
		TriangleCoord four_four = new TriangleCoord (4,4);
		TriangleCoord two_four = new TriangleCoord (2, 4);
		assertFalse(four_four.isOrthagonalTo(two_four));
	}
	@Test
	void isDiagonalTo4_4To5_3SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate five_three = new SquareCoordinate (5, 3);
		assertTrue(four_four.isDiagonalTo(five_three));
	}
	@Test
	void isDiagonalTo4_4To7_7SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate seven_seven = new SquareCoordinate (7, 7);
		assertTrue(four_four.isDiagonalTo(seven_seven));
	}
	@Test
	void isDiagonalTo4_4To1_1SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate one_one = new SquareCoordinate (1, 1);
		assertTrue(four_four.isDiagonalTo(one_one));
	}
	@Test
	void isDiagonalTo4_4To2_6SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate two_six = new SquareCoordinate (2, 6);
		assertTrue(four_four.isDiagonalTo(two_six));
	}
	@Test
	void isDiagonalTo4_4To2_6TriangleNO()
	{
		TriangleCoord four_four = new TriangleCoord (4,4);
		TriangleCoord two_six = new TriangleCoord (2, 6);
		assertFalse(four_four.isDiagonalTo(two_six));
	}
	
	@Test
	void isOmniTo4_4To7_4SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate seven_four = new SquareCoordinate (7, 4);
		assertTrue(four_four.isOmniTo(seven_four));
	}
	@Test
	void isOmniTo4_4To4_1SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate four_one = new SquareCoordinate (4, 1);
		assertTrue(four_four.isOmniTo(four_one));
	}
	@Test
	void isOmniTo4_4To4_5SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate four_five = new SquareCoordinate (4, 5);
		assertTrue(four_four.isOmniTo(four_five));
	}
	@Test
	void isOmniTo4_4To2_4SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate two_four = new SquareCoordinate (2, 4);
		assertTrue(four_four.isOmniTo(two_four));
	}
	@Test
	void isOmniTo4_4To5_3SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate five_three = new SquareCoordinate (5, 3);
		assertTrue(four_four.isOmniTo(five_three));
	}
	@Test
	void isOmniTo4_4To7_7SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate seven_seven = new SquareCoordinate (7, 7);
		assertTrue(four_four.isOmniTo(seven_seven));
	}
	@Test
	void isOmniTo4_4To1_1SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate one_one = new SquareCoordinate (1, 1);
		assertTrue(four_four.isOmniTo(one_one));
	}
	@Test
	void isOmniTo4_4To2_6SquareYES()
	{
		SquareCoordinate four_four = new SquareCoordinate (4,4);
		SquareCoordinate two_six = new SquareCoordinate (2, 6);
		assertTrue(four_four.isOmniTo(two_six));
	}
	@Test
	void isOmniTo4_4To100_4TriangleNO()
	{
		TriangleCoord four_four = new TriangleCoord (4,4);
		TriangleCoord onehundred_four = new TriangleCoord (100, 4);
		assertEquals(false, four_four.isOmniTo(onehundred_four));
	}
	@Test
	void isOmniTo4_4ToNeg100_4TriangleNO()
	{
		TriangleCoord four_four = new TriangleCoord (4,4);
		TriangleCoord negonehundred_four = new TriangleCoord (-100, 4);
		assertEquals(false, four_four.isOmniTo(negonehundred_four));
	}
	@Test
	void isOmniToDOWN4_4ToUPNeg1_10SOUTHEASTTriangleYES()
	{
		TriangleCoord four_four = new TriangleCoord (4,4);
		TriangleCoord negone_ten = new TriangleCoord (-1, 10);
		assertEquals(true, four_four.isOmniTo(negone_ten));
	}
	@Test
	void isOmniToDOWN4_4ToDOWN2_6SOUTHEASTTriangleYES()
	{
		TriangleCoord four_four = new TriangleCoord (4,4);
		TriangleCoord two_six = new TriangleCoord (2,6);
		assertEquals(true, four_four.isOmniTo(two_six));
	}
	@Test
	void isOmniToDOWN4_4ToUP3_2SOUTHWESTTriangleYES()
	{
		TriangleCoord four_four = new TriangleCoord (4,4);
		TriangleCoord three_two = new TriangleCoord (3, 2);
		assertEquals(true, four_four.isOmniTo(three_two));
	}
	@Test
	void isOmniToDOWN4_4ToDOWN1_1SOUTHWESTTriangleYES()
	{
		TriangleCoord four_four = new TriangleCoord (4,4);
		TriangleCoord one_one = new TriangleCoord (1,1);
		assertEquals(true, four_four.isOmniTo(one_one));
	}
	@Test
	void isOmniToUP2_1ToUP4_3NORTHEASTTriangleYES()
	{
		TriangleCoord two_one = new TriangleCoord (2,1);
		TriangleCoord four_three = new TriangleCoord (4,3);
		assertEquals(true, two_one.isOmniTo(four_three));
	}
	@Test
	void isOmniToUP2_1ToDOWN3_3NORTHEASTTriangleYES()
	{
		TriangleCoord two_one = new TriangleCoord (2,1);
		TriangleCoord three_three = new TriangleCoord (3,3);
		assertEquals(true, two_one.isOmniTo(three_three));
	}
	@Test
	void isOmniToUP2_5ToUP6_1NORTHWESTTriangleYES()
	{
		TriangleCoord two_five = new TriangleCoord (2,5);
		TriangleCoord six_one = new TriangleCoord (6,1);
		assertEquals(true, two_five.isOmniTo(six_one));
	}
	@Test
	void isOmniToUP2_5ToDOWN3_3NORTHWESTTriangleYES()
	{
		TriangleCoord two_five = new TriangleCoord (2,5);
		TriangleCoord four_two = new TriangleCoord (4,2);
		assertEquals(true, two_five.isOmniTo(four_two));
	}
	
	@Test
	void testPathCreationSQUARE()
	{
		SquareCoordinate one_one = new SquareCoordinate(1,1);
		Path newP = new Path(one_one);
		LinkedList<SquareCoordinate> coordinates = new LinkedList<SquareCoordinate>();
		coordinates.add(one_one);
		assertEquals(coordinates, newP.getPath());
	}
	@Test
	void testPathCreationTRIANGLE()
	{
		TriangleCoord one_one = new TriangleCoord(1,1);
		Path newP = new Path(one_one);
		LinkedList<TriangleCoord> coordinates = new LinkedList<TriangleCoord>();
		coordinates.add(one_one);
		assertEquals(coordinates, newP.getPath());
	}
	@Test
	void testPathExtensionSQUARE()
	{
		SquareCoordinate one_one = new SquareCoordinate(1,1);
		SquareCoordinate one_two = new SquareCoordinate(1,2);
		Path newP = new Path(one_one);
		LinkedList<SquareCoordinate> coordinates = new LinkedList<SquareCoordinate>();
		coordinates.add(one_one);
		coordinates.add(one_two);
		assertEquals(coordinates, newP.extend(one_two).getPath());
	}
	@Test
	void testPathExtensionTRIANGLE()
	{
		TriangleCoord one_one = new TriangleCoord(1,1);
		TriangleCoord one_two = new TriangleCoord(1,2);
		Path newP = new Path(one_one);
		LinkedList<TriangleCoord> coordinates = new LinkedList<TriangleCoord>();
		coordinates.add(one_one);
		coordinates.add(one_two);
		assertEquals(coordinates, newP.extend(one_two).getPath());
	}
	@Test
	void testPathLastExtractSQUARE()
	{
		SquareCoordinate one_one = new SquareCoordinate(1,1);
		SquareCoordinate one_two = new SquareCoordinate(1,2);
		Path newP = new Path(one_one);
		assertEquals(one_two, newP.extend(one_two).getLast());
	}
	@Test
	void testPathLastExtractTRIANGLE()
	{
		TriangleCoord one_one = new TriangleCoord(1,1);
		TriangleCoord one_two = new TriangleCoord(1,2);
		Path newP = new Path(one_one);
		assertEquals(one_two, newP.extend(one_two).getLast());
	}
	@Test
	void testPathLengthSQUARE()
	{
		SquareCoordinate one_one = new SquareCoordinate(1,1);
		SquareCoordinate one_two = new SquareCoordinate(1,2);
		Path newP = new Path(one_one);
		assertEquals(2, newP.extend(one_two).length());
	}
	@Test
	void testPathLengthTRIANGLE()
	{
		TriangleCoord one_one = new TriangleCoord(1,1);
		TriangleCoord one_two = new TriangleCoord(1,2);
		Path newP = new Path(one_one);
		assertEquals(2, newP.extend(one_two).length());
	}
	@Test
	void testLinearPathSQUARE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		EscapeGameManager egm = egb.makeGameManager();
		SquareCoordinate sixteens = new SquareCoordinate(16,16);
		SquareCoordinate seventeens = new SquareCoordinate(17,17);
		SquareCoordinate fly_birdie = new SquareCoordinate(18,18);
		Path newP = new Path(sixteens); 
		Path newOne = newP.extend(seventeens);
		assertEquals(true, newOne.isLinear((EscapePieceImpl)egm.getPieceAt(fly_birdie)));	
	}
	@Test
	void testLinearPathTRIANGLE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		TriangleCoord two_one = new TriangleCoord(2,1);
		TriangleCoord three_three = new TriangleCoord(3,3);
		TriangleCoord fly_birdie = new TriangleCoord(1,1);
		Path newP = new Path(two_one); 
		Path newOne = newP.extend(three_three);
		assertEquals(true, newOne.isLinear((EscapePieceImpl)egm.getPieceAt(fly_birdie)));	
	}
	@Test
	void testLinearLargerThan2PathSQUARE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		EscapeGameManager egm = egb.makeGameManager();
		SquareCoordinate four_four = new SquareCoordinate(4,4);
		SquareCoordinate five_five = new SquareCoordinate(5,5);
		SquareCoordinate six_five = new SquareCoordinate(6,5);
		SquareCoordinate fly_birdie = new SquareCoordinate(18,18);
		Path newP = new Path(four_four); 
		Path newOne = newP.extend(five_five).extend(six_five);
		assertEquals(false, newOne.isLinear((EscapePieceImpl)egm.getPieceAt(fly_birdie)));	
	}
	@Test
	void testLinearLargerThan2PathTRIANGLE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		TriangleCoord two_one = new TriangleCoord(2,1);
		TriangleCoord three_two = new TriangleCoord(3,2);
		TriangleCoord four_zero = new TriangleCoord(4,0);
		TriangleCoord fly_birdie = new TriangleCoord(1,1);
		Path newP = new Path(two_one); 
		Path newOne = newP.extend(three_two).extend(four_zero);
		assertEquals(false, newOne.isLinear((EscapePieceImpl)egm.getPieceAt(fly_birdie)));	
	}
	@Test
	void testLinearLargerThan2PathAndSameDirectionSQUARE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		EscapeGameManager egm = egb.makeGameManager();
		SquareCoordinate four_four = new SquareCoordinate(4,4);
		SquareCoordinate five_five = new SquareCoordinate(5,5);
		SquareCoordinate six_six = new SquareCoordinate(6,6);
		SquareCoordinate birdie_noFly = new SquareCoordinate(10,12);
		Path newP = new Path(four_four); 
		Path newOne = newP.extend(five_five).extend(six_six);
		assertEquals(true, newOne.isLinear((EscapePieceImpl)egm.getPieceAt(birdie_noFly)));	
	}
	@Test
	void testLinearLargerThan2PathAndSameDirectionTRIANGLE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		TriangleCoord two_one = new TriangleCoord(2,1);
		TriangleCoord three_two = new TriangleCoord(3,2);
		TriangleCoord four_three = new TriangleCoord(4,3);
		TriangleCoord birdie_noFly = new TriangleCoord(9,1);
		Path newP = new Path(two_one); 
		Path newOne = newP.extend(three_two).extend(four_three);
		assertEquals(true, newOne.isLinear((EscapePieceImpl)egm.getPieceAt(birdie_noFly)));	
	}
	
	@Test
	void testLinearLargerThan2PathAndNotSameDirectionSQUARE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		EscapeGameManager egm = egb.makeGameManager();
		SquareCoordinate four_four = new SquareCoordinate(4,4);
		SquareCoordinate five_five = new SquareCoordinate(5,5);
		SquareCoordinate six_five = new SquareCoordinate(6,5);
		SquareCoordinate birdie_noFly = new SquareCoordinate(10,12);
		Path newP = new Path(four_four); 
		Path newOne = newP.extend(five_five).extend(six_five);
		assertEquals(false, newOne.isLinear((EscapePieceImpl)egm.getPieceAt(birdie_noFly)));	
	}
	@Test
	void testLinearLargerThan2PathAndNotSameDirectionTRIANGLE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		TriangleCoord two_one = new TriangleCoord(2,1);
		TriangleCoord three_two = new TriangleCoord(3,2);
		TriangleCoord four_zero = new TriangleCoord(4,0);
		TriangleCoord birdie_noFly = new TriangleCoord(9,1);
		Path newP = new Path(two_one); 
		Path newOne = newP.extend(three_two).extend(four_zero);
		assertEquals(false, newOne.isLinear((EscapePieceImpl)egm.getPieceAt(birdie_noFly)));	
	}
	
	@Test
	void moveFLYPieceWithOmniPatternSQUARE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate eightteen_eighteen = egm.makeCoordinate(18,18);
		Coordinate three_three = egm.makeCoordinate(3, 3);
		assertTrue(egm.move(eightteen_eighteen, three_three));
	}
	@Test
	void moveFLYPieceWithOmniPatternToExitSQUARE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate eightteen_eighteen = egm.makeCoordinate(18,18);
		Coordinate exit = egm.makeCoordinate(5, 12);
		assertTrue(egm.move(eightteen_eighteen, exit));
		assertEquals(null, egm.getPieceAt(eightteen_eighteen)); //removes piece from board
	}
	@Test
	void moveFLYPieceWithOmniPatternToOpposingPlayerPieceSQUARE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate eightteen_eighteen = egm.makeCoordinate(18,18);
		Coordinate ten_twelve = egm.makeCoordinate(10, 12);
		assertTrue(egm.move(eightteen_eighteen, ten_twelve));
		assertEquals(null, egm.getPieceAt(eightteen_eighteen)); //removes piece from board
		assertEquals(Player.PLAYER1, egm.getPieceAt(ten_twelve).getPlayer()); //removes piece from board
	}
	@Test
	void moveFLYPieceWithOmniPatternTRIANGLE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate one_one = egm.makeCoordinate(1,1);
		Coordinate three_three = egm.makeCoordinate(3, 3);
		assertTrue(egm.move(one_one, three_three));
	}
	@Test
	void moveFLYPieceWithOmniPatternToExitTRIANGLE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate one_one = egm.makeCoordinate(1,1);
		Coordinate exit = egm.makeCoordinate(5, 12);
		assertTrue(egm.move(one_one, exit));
		assertEquals(null, egm.getPieceAt(one_one)); //removes piece from board
	}
	@Test
	void moveFLYPieceWithOmniPatternToOpposingPlayerPieceTRIANGLE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate one_one = egm.makeCoordinate(1,1);
		Coordinate ten_twelve = egm.makeCoordinate(10, 12);
		assertTrue(egm.move(one_one, ten_twelve));
		assertEquals(null, egm.getPieceAt(one_one)); //removes piece from board
		assertEquals(Player.PLAYER1, egm.getPieceAt(ten_twelve).getPlayer()); //removes piece from board
	}
	@Test
	void moveFLYPieceWithOrthoPatternSQUARE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/flyPathBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate one_one = egm.makeCoordinate(1,1);
		Coordinate three_four = egm.makeCoordinate(3, 4);
		assertTrue(egm.move(one_one, three_four));
	}
	@Test
	void moveFLYPieceWithOrthoPatternToExitSQUARE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/flyPathBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate one_one = egm.makeCoordinate(1,1);
		Coordinate exit = egm.makeCoordinate(3, 1);
		assertTrue(egm.move(one_one, exit));
		assertEquals(null, egm.getPieceAt(one_one)); //removes piece from board
	}
	@Test
	void moveFLYPieceWithOrthoPatternToOpposingPlayerPieceSQUARE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/flyPathBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate one_one = egm.makeCoordinate(1,1);
		Coordinate four_two = egm.makeCoordinate(4, 2);
		assertTrue(egm.move(one_one, four_two));
		assertEquals(null, egm.getPieceAt(one_one)); //removes piece from board
		assertEquals(Player.PLAYER1, egm.getPieceAt(four_two).getPlayer()); //removes piece from board
	}
	@Test
	void moveFLYPieceWithDiagPatternSQUARE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/flyPathBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate four_four = egm.makeCoordinate(4, 4);
		Coordinate six_two = egm.makeCoordinate(6,2);
		assertTrue(egm.move(four_four, six_two));
	}
	@Test
	void moveFLYPieceWithDiagPatternToExitSQUARE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/flyPathBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate four_four = egm.makeCoordinate(4, 4);
		Coordinate exit = egm.makeCoordinate(5, 1);
		assertTrue(egm.move(four_four, exit));
		assertEquals(null, egm.getPieceAt(four_four)); //removes piece from board
	}
	@Test
	void moveFLYPieceWithDiagPatternToOpposingPlayerPieceSQUARE() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/flyPathBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate four_four = egm.makeCoordinate(4, 4);
		Coordinate four_two = egm.makeCoordinate(4, 2);
		assertTrue(egm.move(four_four, four_two));
		assertEquals(null, egm.getPieceAt(four_four)); //removes piece from board
		assertEquals(Player.PLAYER1, egm.getPieceAt(four_two).getPlayer()); //removes piece from board
	}
	@Test
	void moveOMNIPieceWithDistanceGreaterThanActual() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceDISTGreater-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate snail_four_four = egm.makeCoordinate(4, 4); //snail omni at 4,4
		Coordinate six_six = egm.makeCoordinate(6, 6); //move 4,4 to 6,6
		assertTrue(egm.move(snail_four_four, six_six));
	}
	@Test
	void moveOMNIPieceWithDistanceLessThanActual() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceDISTLess-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate snail_four_four = egm.makeCoordinate(4, 4); //snail omni at 4,4
		Coordinate ten_six = egm.makeCoordinate(10, 6); 
		assertFalse(egm.move(snail_four_four, ten_six));
	}
	@Test
	void moveOMNIPieceWithProperDistanceBlockSurroundingTarget() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/EQDIST-BLOCKTARG.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate snail_four_four = egm.makeCoordinate(4, 4); //snail omni at 4,4
		Coordinate ten_six = egm.makeCoordinate(10, 6); 
		assertFalse(egm.move(snail_four_four, ten_six));
	}
	@Test
	void moveOMNIPieceWithProperDistanceBlockSurroundingSource() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/EQDIST-BLOCKSRC.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate snail_four_four = egm.makeCoordinate(4, 4); //snail omni at 4,4
		Coordinate ten_six = egm.makeCoordinate(10, 6); 
		assertFalse(egm.move(snail_four_four, ten_six));
	}
	@Test
	void moveOMNIPieceWithDistanceGreaterThanActualOnAnotherPlayer() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceDISTGreater-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate snail_four_four = egm.makeCoordinate(4, 4); //snail omni at 4,4
		Coordinate five_eight = egm.makeCoordinate(5, 8); //move 4,4 to 6,6
		assertTrue(egm.move(snail_four_four, five_eight));
		assertNull(egm.getPieceAt(snail_four_four)); //clears old location
		assertEquals(Player.PLAYER1, egm.getPieceAt(five_eight).getPlayer()); //moves to new
	}
	@Test
	void moveOMNIPieceWithDistanceLessThanActualOnAnotherPlayer() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceDISTLess-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate snail_four_four = egm.makeCoordinate(4, 4); //snail omni at 4,4
		Coordinate ten_one = egm.makeCoordinate(10, 1);
		assertFalse(egm.move(snail_four_four, ten_one));
	}
	@Test
	void moveOMNIPieceWithDistanceGreaterThanActualOntoExit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceDISTGreater-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate snail_four_four = egm.makeCoordinate(4, 4); //snail omni at 4,4
		Coordinate exit = egm.makeCoordinate(5, 12);
		assertTrue(egm.move(snail_four_four, exit));
		assertEquals(null, egm.getPieceAt(snail_four_four));
		assertEquals(null, egm.getPieceAt(exit));
	}
	@Test
	void moveORTHOPieceWithDistanceGreaterThanActual() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceDISTGreater-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_two_two = egm.makeCoordinate(2, 2); //dog ortho 2,2
		Coordinate two_three = egm.makeCoordinate(2, 3); 
		assertTrue(egm.move(dog_two_two, two_three));
	}
	@Test
	void moveORTHOPieceWithDistanceLessThanActual() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceDISTLess-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_two_two = egm.makeCoordinate(2, 2); //dog ortho 2,2
		Coordinate two_eight = egm.makeCoordinate(2, 8); 
		assertFalse(egm.move(dog_two_two, two_eight));
	}
	@Test
	void moveORTHOPieceWithProperDistanceBlockSurroundingTarget() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/EQDIST-BLOCKTARG.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_two_two = egm.makeCoordinate(2, 2); //dog ortho 2,2
		Coordinate two_eight = egm.makeCoordinate(2, 8); 
		assertFalse(egm.move(dog_two_two, two_eight));
	}
	@Test
	void moveORTHOPieceWithProperDistanceBlockSurroundingSource() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/EQDIST-BLOCKSRC.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_two_two = egm.makeCoordinate(2, 2); //dog ortho 2,2
		Coordinate two_eight = egm.makeCoordinate(2, 8);  
		assertFalse(egm.move(dog_two_two, two_eight));
	}
	@Test
	void moveORTHOPieceWithDistanceGreaterThanActualOnAnotherPlayer() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceDISTGreater-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_two_two = egm.makeCoordinate(2, 2); //dog ortho 2,2
		Coordinate two_one = egm.makeCoordinate(2, 1); //move 4,4 to 6,6
		assertTrue(egm.move(dog_two_two, two_one));
		assertNull(egm.getPieceAt(dog_two_two)); //clears old location
		assertEquals(Player.PLAYER1, egm.getPieceAt(two_one).getPlayer()); //moves to new
	}
	@Test
	void moveORTHOPieceWithDistanceLessThanActualOnAnotherPlayer() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceDISTLess-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_two_two = egm.makeCoordinate(2, 2); //dog ortho 2,2
		Coordinate eight_one = egm.makeCoordinate(8, 1);
		assertFalse(egm.move(dog_two_two, eight_one));
	}
	@Test
	void moveORTHOPieceWithDistanceGreaterThanActualOntoExit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceDISTGreater-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_two_two = egm.makeCoordinate(2, 2); //dog ortho 2,2
		Coordinate exit = egm.makeCoordinate(5, 2);
		assertTrue(egm.move(dog_two_two, exit));
		assertEquals(null, egm.getPieceAt(dog_two_two));
		assertEquals(null, egm.getPieceAt(exit));
	}
	@Test
	void moveDIAGPieceWithDistanceGreaterThanActual() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceDISTGreater-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate horse_two_eight = egm.makeCoordinate(2, 8); //horse diag 2,8
		Coordinate eight_two = egm.makeCoordinate(8, 2); 
		assertTrue(egm.move(horse_two_eight, eight_two));
	}
	@Test
	void moveDIAGPieceWithDistanceLessThanActual() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceDISTLess-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate horse_two_eight = egm.makeCoordinate(2, 8); //horse diag 2,8
		Coordinate eight_two = egm.makeCoordinate(8, 2);
		assertFalse(egm.move(horse_two_eight, eight_two));
	}
	@Test
	void moveDIAGPieceWithProperDistanceBlockSurroundingTarget() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/EQDIST-BLOCKTARG.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate horse_two_eight = egm.makeCoordinate(2, 8); //horse diag 2,8
		Coordinate eight_two = egm.makeCoordinate(8, 2);
		assertFalse(egm.move(horse_two_eight, eight_two));
	}
	@Test
	void moveDIAGPieceWithProperDistanceBlockSurroundingSource() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/EQDIST-BLOCKSRC.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate horse_two_eight = egm.makeCoordinate(2, 8); //horse diag 2,8
		Coordinate eight_two = egm.makeCoordinate(8, 2);
		assertFalse(egm.move(horse_two_eight, eight_two));
	}
	@Test
	void moveDIAGPieceWithDistanceGreaterThanActualOnAnotherPlayer() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceDISTGreater-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate horse_two_eight = egm.makeCoordinate(2, 8); //horse diag 2,8
		Coordinate four_eight = egm.makeCoordinate(4,8); 
		assertTrue(egm.move(horse_two_eight, four_eight));
		assertNull(egm.getPieceAt(horse_two_eight)); //clears old location
		assertEquals(Player.PLAYER1, egm.getPieceAt(four_eight).getPlayer()); //moves to new
	}
	@Test
	void moveDIAGPieceWithDistanceLessThanActualOnAnotherPlayer() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceDISTLess-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate horse_two_eight = egm.makeCoordinate(2, 8); //horse diag 2,8
		Coordinate eight_six = egm.makeCoordinate(8, 6);
		assertFalse(egm.move(horse_two_eight, eight_six));
	}
	@Test
	void moveDIAGPieceWithDistanceGreaterThanActualOntoExit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceDISTGreater-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate horse_two_eight = egm.makeCoordinate(2, 8); //horse diag 2,8
		Coordinate exit = egm.makeCoordinate(5, 7);
		assertTrue(egm.move(horse_two_eight, exit));
		assertEquals(null, egm.getPieceAt(horse_two_eight));
		assertEquals(null, egm.getPieceAt(exit));
	}
	@Test
	void moveORTHOPieceWithJUMP() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/jumpBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate horse_four_four = egm.makeCoordinate(4, 4); //horse ortho 4,4
		Coordinate goal = egm.makeCoordinate(4, 1); //one piece in the way
		assertTrue(egm.move(horse_four_four, goal));
	}
	@Test
	void moveORTHOPieceWithJUMPConsecObstacleNoWhiteSpace() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/jumpBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate horse_four_four = egm.makeCoordinate(4, 4); //horse ortho 4,4
		Coordinate goal = egm.makeCoordinate(1, 4); //one piece in the way
		assertFalse(egm.move(horse_four_four, goal));
	}
	@Test
	void moveORTHOPieceWithJUMPOntoExit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/jumpBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate horse_four_four = egm.makeCoordinate(4, 4); //horse ortho 4,4
		Coordinate goal = egm.makeCoordinate(7, 4); //one piece in the way
		assertTrue(egm.move(horse_four_four, goal));
		assertNull(egm.getPieceAt(horse_four_four));
		assertNull(egm.getPieceAt(goal));
	}
	@Test
	void moveORTHOPieceWithJUMPTwoObstaclesWithOneWhiteSpace() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/twojumpBoard2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_four_four = egm.makeCoordinate(4, 4); //dog ortho 4,4
		Coordinate goal = egm.makeCoordinate(4, 8); //one piece in the way
		assertTrue(egm.move(dog_four_four, goal));
	}
	@Test
	void moveDIAGPieceWithJUMP() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/jumpBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_six_nine = egm.makeCoordinate(6, 9); //dog diag 6,9
		Coordinate goal = egm.makeCoordinate(3,6); //one piece in the way
		assertTrue(egm.move(dog_six_nine, goal));
	}
	@Test
	void moveDIAGPieceWithJUMPConsecObstacleNoWhiteSpace() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/jumpBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_six_nine = egm.makeCoordinate(6, 9); //dog diag 6,9
		Coordinate goal = egm.makeCoordinate(3,12); //one piece in the way
		assertFalse(egm.move(dog_six_nine, goal));
	}
	@Test
	void moveDIAGPieceWithJUMPOntoExit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/jumpBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_six_nine = egm.makeCoordinate(6, 9); //dog diag 6,9
		Coordinate goal = egm.makeCoordinate(9, 12); //one piece in the way
		assertTrue(egm.move(dog_six_nine, goal));
		assertNull(egm.getPieceAt(dog_six_nine));
		assertNull(egm.getPieceAt(goal));
	}
	@Test
	void moveDIAGPieceWithJUMPTwoObstaclesWithOneWhiteSpace() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/twojumpBoard2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate horse_six_nine = egm.makeCoordinate(6, 9); //horse ortho 4,4
		Coordinate goal = egm.makeCoordinate(10, 5); //one piece in the way
		assertTrue(egm.move(horse_six_nine, goal));
	}
	//start
	@Test
	void moveOMNIPieceWithSingleJUMP() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/OMNIjumpBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_five_thirteen = egm.makeCoordinate(5,13); //dog omni 5,13
		Coordinate goal = egm.makeCoordinate(9,13); //one piece in the way
		assertTrue(egm.move(dog_five_thirteen, goal));
	}
	@Test
	void moveOMNIPieceWithJUMPConsecObstacleNoWhiteSpace() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/OMNIjumpBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_five_thirteen = egm.makeCoordinate(5,13); //dog omni 5,13
		Coordinate goal = egm.makeCoordinate(1,17); //one piece in the way
		assertFalse(egm.move(dog_five_thirteen, goal));
	}
	@Test
	void moveOMNIPieceWithJUMPOntoExit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/OMNIjumpBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_five_thirteen = egm.makeCoordinate(5,13); //dog omni 5,13
		Coordinate goal = egm.makeCoordinate(9, 17); //one piece in the way
		assertTrue(egm.move(dog_five_thirteen, goal));
		assertNull(egm.getPieceAt(dog_five_thirteen));
		assertNull(egm.getPieceAt(goal));
	}
	@Test
	void moveOMNIPieceWithJUMPTwoObstaclesWithOneWhiteSpace() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/OMNIjumpBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_five_thirteen = egm.makeCoordinate(5,13); //dog omni 5,13
		Coordinate goal = egm.makeCoordinate(5, 17); //one piece in the way
		assertTrue(egm.move(dog_five_thirteen, goal));
	}
	@Test
	void moveOMNIPieceWithJUMPTwoObstaclesWithOneWhiteSpaceNorthWest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/OMNIjumpBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_five_thirteen = egm.makeCoordinate(5,13); //dog omni 5,13
		Coordinate goal = egm.makeCoordinate(9, 9); //one piece in the way
		assertTrue(egm.move(dog_five_thirteen, goal));
	}
	@Test
	void moveOMNIPieceWithJUMPTwoObstaclesWithOneWhiteSpaceWest()throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/OMNIjumpBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_five_thirteen = egm.makeCoordinate(5,13); //dog omni 5,13
		Coordinate goal = egm.makeCoordinate(5, 9); //one piece in the way
		assertTrue(egm.move(dog_five_thirteen, goal));
	}
	@Test
	void moveOMNIPieceWithJUMPThreeObstaclesWithNoWhiteSpaceWest()throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/OMNIjumpBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_five_thirteen = egm.makeCoordinate(5,13); //dog omni 5,13
		Coordinate goal = egm.makeCoordinate(1, 13); //three pieces to jump over but there are alternate routes
		assertTrue(egm.move(dog_five_thirteen, goal));
	}
	@Test
	void moveOMNIPieceWithJUMPOneObstacleAndTwoWhiteSpaceSouthWest()throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/OMNIjumpBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog_five_thirteen = egm.makeCoordinate(5,13); //dog omni 5,13
		Coordinate goal = egm.makeCoordinate(1, 9); //one piece in the way
		assertTrue(egm.move(dog_five_thirteen, goal));
	}
	@Test
	void moveTriangleOMNIWithDistanceGreaterThanActual() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TriPieceDISTGreater-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate two_five = egm.makeCoordinate(2, 5);
		Coordinate five_eight = egm.makeCoordinate(5, 8);
		assertTrue(egm.move(two_five, five_eight));
	}
	@Test
	void moveTriangleOMNIWithDistanceLessThanActual() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TriPieceDISTLess-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate two_five = egm.makeCoordinate(2, 5);
		Coordinate five_eight = egm.makeCoordinate(5, 8);
		assertFalse(egm.move(two_five, five_eight));
	}
	
	@Test
	void moveTriangleOMNIWithObstaclesBlockingSource() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TriEQDIST-BLOCKSRC.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate two_five = egm.makeCoordinate(2, 5);
		Coordinate four_two = egm.makeCoordinate(4, 2);
		assertFalse(egm.move(two_five, four_two));
	}
	@Test
	void moveTriangleOMNIWithPieceDistGreaterOntoAnotherPlayersPiece() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TriPieceDISTGreater-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate two_five = egm.makeCoordinate(2, 5);
		Coordinate four_seven = egm.makeCoordinate(4, 7);
		assertTrue(egm.move(two_five, four_seven));
		assertEquals(Player.PLAYER1, egm.getPieceAt(four_seven).getPlayer());
		assertNull(egm.getPieceAt(two_five));
		
	}
	@Test
	void moveTriangleOMNIWithPieceDistLessOntoAnotherPlayersPiece() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TriPieceDISTLess-NO-OBS.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate two_five = egm.makeCoordinate(2, 5);
		Coordinate four_seven = egm.makeCoordinate(4, 7);
		assertFalse(egm.move(two_five, four_seven));
	}
	@Test
	void infiniteTriBoardOMNIPieceDistEqualToActualDist() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/infiniteTriBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate four_four = egm.makeCoordinate(4, 4);
		Coordinate negative8_8 = egm.makeCoordinate(-8, 8);
		assertTrue(egm.move(four_four, negative8_8));
	}
	@Test
	void infiniteTriBoardOMNIPieceDistGreaterThanActualDist() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/infiniteTriBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate four_five = egm.makeCoordinate(4, 5);
		Coordinate neg8_neg7 = egm.makeCoordinate(-8, -7);
		assertTrue(egm.move(four_five, neg8_neg7));
	}
	@Test
	void infiniteTriBoardOMNIPieceDistLessThanActualDist() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/infiniteTriBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate four_six = egm.makeCoordinate(4, 6);
		Coordinate neg9_10 = egm.makeCoordinate(-9, 10);
		assertFalse(egm.move(four_six, neg9_10));
	}
	//WE ONLY GET TO ONE COORDINATE BELOW
	@Test
	void simpleTriJumperOmni() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TriJumper.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate two_four = egm.makeCoordinate(2, 4);
		Coordinate two_six = egm.makeCoordinate(2, 6);
		Coordinate one_five = egm.makeCoordinate(1, 5);
		assertTrue(egm.move(two_four, two_six));
		
	}
	@Test
	void simpleTriJumperOmniPt2() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TriJumper.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate two_four = egm.makeCoordinate(2, 4);
		Coordinate two_six = egm.makeCoordinate(2, 6);
		Coordinate one_five = egm.makeCoordinate(1, 5);
		assertTrue(egm.move(two_four, one_five));
		
	}
	@Test
	void singleLineTriangleJumper() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TriJumper.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate three_two = egm.makeCoordinate(3, 2);
		Coordinate three_seven = egm.makeCoordinate(3, 7);
		assertTrue(egm.move(three_two, three_seven));
	}
	@Test 
	void trappedSourceToTrappedTarget() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TrappedtriJumper.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate three_eight = egm.makeCoordinate(3, 8);
		Coordinate three_four = egm.makeCoordinate(3, 4);
		assertTrue(egm.move(three_eight, three_four));
	}
	@Test
	void precedenceCheck() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TriJumper.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate twenty_twenty = egm.makeCoordinate(20, 20);
		EscapePieceImpl checker = (EscapePieceImpl) egm.getPieceAt(twenty_twenty);
		assertTrue(checker.hasAttribute(PieceAttributeID.FLY));
		assertFalse(checker.hasAttribute(PieceAttributeID.JUMP));
		
	}
	@Test
	void infiniteTriangleGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/infiniteTriangleFullGameTester.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate dog = egm.makeCoordinate(9, 12);
		Coordinate horse = egm.makeCoordinate(4, 2);
		Coordinate frog = egm.makeCoordinate(2, 2);
		Coordinate snail = egm.makeCoordinate(0, 0);
		Coordinate snail2 = egm.makeCoordinate(9, -2);
		Coordinate bird = egm.makeCoordinate(0, -6);
		assertEquals(egm.getPieceAt(dog).getName(), PieceName.DOG);
		assertEquals(egm.getPieceAt(horse).getName(), PieceName.HORSE);
		assertEquals(egm.getPieceAt(frog).getName(), PieceName.FROG);
		assertEquals(egm.getPieceAt(snail).getName(), PieceName.SNAIL);
		assertEquals(egm.getPieceAt(bird).getName(), PieceName.BIRD);
		assertFalse(egm.move(horse, snail)); //fail bc its not player 2's turn
		assertFalse(egm.move(dog, bird)); //player 1's move - we cant land on player 1s piece
		assertTrue(egm.move(dog, snail));
		assertEquals(egm.getPieceAt(snail).getName(), PieceName.DOG);
		assertNull(egm.getPieceAt(dog));
		assertFalse(egm.move(snail, egm.makeCoordinate(3, 6))); //player 1 tries to move on player 2s turn
		assertTrue(egm.move(horse, egm.makeCoordinate(3, 6))); // player 2 exits
		assertNull(egm.getPieceAt(horse));
		assertNull(egm.getPieceAt(egm.makeCoordinate(3, 6))); //player 1s turn
		assertTrue(egm.move(snail, egm.makeCoordinate(2, 1))); //player 2 turn
		assertEquals(egm.getPieceAt(egm.makeCoordinate(2, 1)).getName(), PieceName.DOG);
		assertTrue(egm.move(snail2, egm.makeCoordinate(7, 2)));
		assertEquals(egm.getPieceAt(egm.makeCoordinate(7, 2)).getName(), PieceName.SNAIL); //player 1 turn
		assertTrue(egm.move(egm.makeCoordinate(2, 1), egm.makeCoordinate(8, 1))); //player 2 now
		assertTrue(egm.move(egm.makeCoordinate(7, 2), egm.makeCoordinate(7, 3))); //JUMP
	}
	
	@Test 
	void ruggedSquareGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/squareFullGame.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate one_one = egm.makeCoordinate(1, 1); //frog p1
		Coordinate one_two = egm.makeCoordinate(1, 2); //bird p2
		Coordinate four_three = egm.makeCoordinate(4, 3); //dog p1
		Coordinate six_three = egm.makeCoordinate(6, 3); //horse p2
		Coordinate six_nine = egm.makeCoordinate(6, 9); //snail p1
		Coordinate one_nine = egm.makeCoordinate(1, 9);
		Coordinate four_five = egm.makeCoordinate(4, 5);
		Coordinate eight_eleven = egm.makeCoordinate(8, 11);
		Coordinate seven_six = egm.makeCoordinate(7, 6);
		Coordinate nine_twelve = egm.makeCoordinate(9, 12);
		Coordinate five_six = egm.makeCoordinate(5, 6);
		Coordinate exit = egm.makeCoordinate(10, 15);
		assertTrue(egm.move(one_one, one_nine));
		assertNull(egm.getPieceAt(one_one));
		assertEquals(egm.getPieceAt(one_nine).getName(), PieceName.FROG);
		assertFalse(egm.move(one_nine, nine_twelve)); //not player 1s turn
		assertTrue(egm.move(one_two, four_five)); //player 2 move
		assertNull(egm.getPieceAt(one_two));
		assertEquals(egm.getPieceAt(four_five).getName(), PieceName.BIRD);
		assertTrue(egm.move(four_three, eight_eleven)); //player 1 move
		assertEquals(egm.getPieceAt(eight_eleven).getName(), PieceName.DOG);
		assertNull(egm.getPieceAt(four_three));
		assertFalse(egm.move(eight_eleven, nine_twelve)); //cant move player 1s piece
		assertTrue(egm.move(six_three, seven_six));
		assertEquals(egm.getPieceAt(seven_six).getName(), PieceName.HORSE);
		assertNull(egm.getPieceAt(six_three));
		assertTrue(egm.move(six_nine, nine_twelve));
		assertEquals(egm.getPieceAt(nine_twelve).getName(), PieceName.SNAIL);
		assertNull(egm.getPieceAt(six_nine));
		assertTrue(egm.move(four_five, five_six));
		assertEquals(egm.getPieceAt(five_six).getName(), PieceName.BIRD);
		assertNull(egm.getPieceAt(four_five));
		assertTrue(egm.move(nine_twelve, exit));
		assertNull(egm.getPieceAt(nine_twelve));
	}

	
	
	/* Removed functionality as not due to BETA
	@Test 
	void simpleGameOverConditional() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 4);
		Coordinate target = egm.makeCoordinate(10, 12);
		assertTrue(egm.move(source, target));
		assertNull(egm.getPieceAt(source));
		assertEquals(egm.getPieceAt(target).getPlayer(), Player.PLAYER1);
		assertFalse(egm.move(source, target));
	}*/
	
}