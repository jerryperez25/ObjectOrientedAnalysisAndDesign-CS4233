/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Copyright ©2016 Gary F. Pollice
 *******************************************************************************/

package escape;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertThrows;
import static org.junit.Assert.assertTrue;

import java.util.LinkedList;
import java.util.List;

import org.junit.jupiter.api.Test;

import escape.board.EscapeBoard;
import escape.board.SquareBoard;
import escape.board.TriangleBoard;
import escape.coordinate.Coordinate;
import escape.coordinate.CoordinateFactory;
import escape.coordinate.EscapeCoordinateImpl;
import escape.coordinate.SquareCoordinate;
import escape.coordinate.TriangleCoord;
import escape.coordinate.Coordinate.CoordinateType;
import escape.coordinate.EscapeCoordinateImpl.CompassRose;
import escape.exception.EscapeException;
import escape.manager.EscapeGameManager;
import escape.manager.EscapeGameManagerImpl;
import escape.pathFinding.Path;
import escape.piece.EscapePiece;
import escape.piece.EscapePieceImpl;
import escape.piece.Player;
import escape.piece.EscapePiece.MovementPattern;
import escape.piece.EscapePiece.PieceAttributeID;
import escape.piece.EscapePiece.PieceName;

/**
 * These tests will be made specifically for the TODO list that belongs to Gamma
 * 
 * @version December 5th, 2020
 */
class EscapeGammaTest 
{
	// ------------------------SQUARE-----------------
	// --------NORTH--------
	//square board linear with valid distance, flies over block onto exit
	@Test
	void squareLinearityFlyOverBlockOntoExitNORTH() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(8, 10);
		assertTrue(egm.move(source, target)); //moves onto exit
		assertNull(egm.getPieceAt(source)); //from is null
		assertNull(egm.getPieceAt(target)); //to is still null because its exit
	}
	//square board linear with valid distance, flies over block onto clear
	@Test
	void squareLinearityLandOnClearNorth() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(9, 8);
		assertTrue(egm.move(source, target)); //moves onto clear
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); //piece now at to
		assertNull(egm.getPieceAt(source)); //no piece at from 
	}
	//square board linear with valid distance, flies onto block
	@Test
	void squareLinearityLandOnBlockNorth() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(7, 8);
		assertFalse(egm.move(source, target)); //moves onto block
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //player 1 still at to
		assertNull(egm.getPieceAt(target)); //exit is still null
	}
	//square board linear with valid distance, flies onto opposing player
	@Test
	void squareLinearityLandOnOpposingPlayerNorth() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(10, 8);
		assertFalse(egm.move(source, target)); //player 1 tries to land on player 2
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //player 1 on same spot
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD); //player 2 stays as well
		
	}
	//square board linear with valid distance, flies onto something that is not linear
	@Test
	void squareLinearityDirectionIsNoneNorthward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(9, 9);
		assertFalse(egm.move(source, target)); //the target is not linear
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //player 1 on same spot
		assertNull(egm.getPieceAt(target)); // the target is still empty
		
	}
	// --------SOUTH--------
	//square board linear with valid distance, flies over block onto exit
	@Test
	void squareLinearityFlyOverBlockOntoExitSouth() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(4, 8);
		assertTrue(egm.move(source, target)); //player 1 lands on southbound exit
		assertNull(egm.getPieceAt(target)); //exit is still null
		assertNull(egm.getPieceAt(source)); //to is null because piece is removed
	}
	//square board linear with valid distance, flies over block onto clear
	@Test
	void squareLinearityLandOnClearSouth() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(3, 8);
		assertTrue(egm.move(source, target)); //player 1 lands on southbound clear
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); //target is snail
		assertNull(egm.getPieceAt(source)); //to is null because piece is moved
	}
	//square board linear with valid distance, flies onto block
	@Test
	void squareLinearityLandOnBlockSouth() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(5, 8);
		assertFalse(egm.move(source, target));
		assertNull(egm.getPieceAt(target)); //target is still a block
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //piece not moved
	}
	//square board linear with valid distance, flies onto opposing player
	@Test
	void squareLinearityLandOnOpposingPlayerSouth() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(2, 8);
		assertFalse(egm.move(source, target));
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD); //target is still a bird
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //piece not moved
	}
	//square board linear with valid distance, flies onto something that is not linear
	@Test
	void squareLinearityDirectionIsNoneSouthward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(3, 9);
		assertFalse(egm.move(source, target));
		assertNull(egm.getPieceAt(target)); //target still has no piece
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //piece not moved
	}
	// --------EAST--------
	//square board linear with valid distance, flies over block onto exit
	@Test
	void squareLinearityFlyOverBlockOntoExitEast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(6, 10);
		assertTrue(egm.move(source, target)); //piece can move onto exit
		assertNull(egm.getPieceAt(source)); //piece is removed
		assertNull(egm.getPieceAt(target)); //target is still an exit
	}
	//square board linear with valid distance, flies over block onto clear
	@Test
	void squareLinearityLandOnClearEast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(6, 11);
		assertTrue(egm.move(source, target)); //piece can move onto clear
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); //player on clear
		assertNull(egm.getPieceAt(source)); //piece has been moved
	}
	//square board linear with valid distance, flies onto block
	@Test
	void squareLinearityLandOnBlockEast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(6, 9);
		assertFalse(egm.move(source, target)); //cannot move onto block
		assertNull(egm.getPieceAt(target)); //location is still an exit
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //move not done
	}
	//square board linear with valid distance, flies onto opposing player
	@Test
	void squareLinearityLandOnOpposingPlayerEast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(6, 12);
		assertFalse(egm.move(source, target)); //cannot move onto other players spot
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD); //location is still bird
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //move not done
		
	}
	//square board linear with valid distance, flies onto something that is not linear
	@Test
	void squareLinearityDirectionIsNoneEastward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(7, 11);
		assertFalse(egm.move(source, target)); //cannot go non-linear
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //piece never moves
		assertNull(egm.getPieceAt(target)); //target still empty
		
	}
	// --------WEST--------
	//square board linear with valid distance, flies over block onto exit
	@Test
	void squareLinearityFlyOverBlockOntoExitWest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(6, 6); 
		assertTrue(egm.move(source, target)); //player lands on exit 
		assertNull(egm.getPieceAt(source)); //piece is removed
		assertNull(egm.getPieceAt(target)); //exit is still null
	}
	//square board linear with valid distance, flies over block onto clear
	@Test
	void squareLinearityLandOnClearWest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(6, 5); 
		assertTrue(egm.move(source, target)); //player lands on clear
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); //successful move
		assertNull(egm.getPieceAt(source)); //piece no longer there
	}
	//square board linear with valid distance, flies onto block
	@Test
	void squareLinearityLandOnBlockWest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(6, 7);
		assertFalse(egm.move(source, target)); //cannot move onto block
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece does not move
		assertNull(egm.getPieceAt(target)); //target is still a block
	}
	//square board linear with valid distance, flies onto opposing player
	@Test
	void squareLinearityLandOnOpposingPlayerWest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(6, 4);
		assertFalse(egm.move(source, target)); // cannot land on opposing player
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //to is still the same
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD); //to is still the same
	}
	//square board linear with valid distance, flies onto something that is not linear
	@Test
	void squareLinearityDirectionIsNoneWestward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(7, 5);
		assertFalse(egm.move(source, target)); //not linear
		assertNull(egm.getPieceAt(target)); //no piece on to
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //player 1 stays
	}
	// --------NORTHEAST--------
	//square board linear with valid distance, flies over block onto exit
	@Test
	void squareLinearityFlyOverBlockOntoExitNortheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(8, 10);
		assertTrue(egm.move(source, target)); //moves to exit
		assertNull(egm.getPieceAt(target)); // target is still exit
		assertNull(egm.getPieceAt(source)); //piece is removed
		
	}
	//square board linear with valid distance, flies over block onto clear
	@Test
	void squareLinearityLandOnClearNortheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(9, 11);
		assertTrue(egm.move(source, target)); //player moves to clear
		assertNull(egm.getPieceAt(source)); //player is no longer there
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); //player at target
	}
	//square board linear with valid distance, flies onto block
	@Test
	void squareLinearityLandOnBlockNortheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(7, 9);
		assertFalse(egm.move(source, target)); //cannot land on block
		assertNull(egm.getPieceAt(target)); //target is still block
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //player doesnt move
	}
	//square board linear with valid distance, flies onto opposing player
	@Test
	void squareLinearityLandOnOpposingPlayerNortheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(10, 12);
		assertFalse(egm.move(source, target)); // cannot land on opposing players piece
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL);
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD);
	}
	//square board linear with valid distance, flies onto something that is not linear
	@Test
	void squareLinearityDirectionIsNoneNorthEastward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(10, 11);
		assertFalse(egm.move(source, target)); // not linear
		assertNull(egm.getPieceAt(target)); //no piece
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //piece not moved
	}
	// --------NORTHWEST--------
	//square board linear with valid distance, flies over block onto exit
	@Test
	void squareLinearityFlyOverBlockOntoExitNorthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(8, 6);
		assertTrue(egm.move(source, target)); //landing on exit
		assertNull(egm.getPieceAt(source)); //piece exits
		assertNull(egm.getPieceAt(target)); //to is still an exit
	}
	//square board linear with valid distance, flies over block onto clear
	@Test
	void squareLinearityLandOnClearNorthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(9, 5);
		assertTrue(egm.move(source, target)); //landing on clear
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); //player moves successfully
		assertNull(egm.getPieceAt(source)); //piece is removed
	}
	//square board linear with valid distance, flies onto block
	@Test
	void squareLinearityLandOnBlockNorthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(7, 7);
		assertFalse(egm.move(source, target)); //cannot move onto block
		assertNull(egm.getPieceAt(target)); //target is still block
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //source stays
	}
	//square board linear with valid distance, flies onto opposing player
	@Test
	void squareLinearityLandOnOpposingPlayerNorthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(10, 4);
		assertFalse(egm.move(source, target)); //cannot land on opposing player
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //player 1 same
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD);  //player 2 same
	}
	//square board linear with valid distance, flies onto something that is not linear
	@Test
	void squareLinearityDirectionIsNoneNorthwestward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(9, 6);
		assertFalse(egm.move(source, target)); //non-linear move
		assertNull(egm.getPieceAt(target)); //no piece there
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //player 1 same
	}
	// --------SOUTHEAST--------
	//square board linear with valid distance, flies over block onto exit
	@Test
	void squareLinearityFlyOverBlockOntoExitSoutheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(4, 10);
		assertTrue(egm.move(source, target)); //moves to exit
		assertNull(egm.getPieceAt(source)); //piece is removed
		assertNull(egm.getPieceAt(target)); //piece is still exit
	}
	//square board linear with valid distance, flies over block onto clear
	@Test
	void squareLinearityLandOnClearSoutheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(3, 11);
		assertTrue(egm.move(source, target)); //moving onto clear
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); //player 1 moves
		assertNull(egm.getPieceAt(source)); //no piece at previous
	}
	//square board linear with valid distance, flies onto block
	@Test
	void squareLinearityLandOnBlockSoutheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(5, 9);
		assertFalse(egm.move(source, target)); //moves to block
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //player 1 stays
		assertNull(egm.getPieceAt(target)); //target is still block
		
	}
	//square board linear with valid distance, flies onto opposing player
	@Test
	void squareLinearityLandOnOpposingPlayerSoutheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(2, 12);
		assertFalse(egm.move(source, target)); //cannot move onto opposing piece
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //player 1 stays
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD); //player 2 stays
	}
	//square board linear with valid distance, flies onto something that is not linear
	@Test
	void squareLinearityDirectionIsNoneSoutheastward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(4, 12);
		assertFalse(egm.move(source, target)); // non-linear move
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //player 1 stays
		assertNull(egm.getPieceAt(target)); //no piece at to
	}
	// --------SOUTHWEST--------
	//square board linear with valid distance, flies over block onto exit
	@Test
	void squareLinearityFlyOverBlockOntoExitSouthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(4, 6);
		assertTrue(egm.move(source, target)); //moves onto exit
		assertNull(egm.getPieceAt(target)); // target is still exit
		assertNull(egm.getPieceAt(source)); // piece is removed
	}
	//square board linear with valid distance, flies over block onto clear
	@Test
	void squareLinearityLandOnClearSouthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(3, 5);
		assertTrue(egm.move(source, target)); //moves onto clear
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); //player 1 moves
		assertNull(egm.getPieceAt(source)); //no piece at from
	}
	//square board linear with valid distance, flies onto block
	@Test
	void squareLinearityLandOnBlockSouthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(5, 7);
		assertFalse(egm.move(source, target)); //moves onto block
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //player 1 stays
		assertNull(egm.getPieceAt(target)); //target is still block
	}
	//square board linear with valid distance, flies onto opposing player
	@Test
	void squareLinearityLandOnOpposingPlayerSouthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(2, 4);
		assertFalse(egm.move(source, target)); //cannot land on opposing player
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //player 1 stays
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD); //player 1 stays
	}
	//square board linear with valid distance, flies onto something that is not linear
	@Test
	void squareLinearityDirectionIsNoneSouthwestward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(6, 8);
		Coordinate target = egm.makeCoordinate(2, 5);
		assertFalse(egm.move(source, target)); //non-linear move
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); //player 1 stays
		assertNull(egm.getPieceAt(target)); //target still has no piece on it
	}

	// ------------------------TRIANGLE-----------------
	// --------Upward Facing--------
	// --------NorthEast----------
	//triangle board linear with valid distance, flies onto something that is not linear
	@Test
	void triangleLinearityDirectionIsNoneNortheastward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(1,  9);
		assertFalse(egm.move(source, target)); // should return false because the move is not linear
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target has no piece still
	}
	//triangle board linear with valid distance, flies over block onto exit
	@Test
	void triangleLinearityLandOnExitNortheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(5,  7);
		assertTrue(egm.move(source, target)); // lands on exit
		assertNull(egm.getPieceAt(source)); // piece is removed
		assertNull(egm.getPieceAt(target)); //target is still exit
	}
	//triangle board linear with valid distance, flies over block onto clear
	@Test
	void triangleLinearityLandOnClearNortheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(6,  7);
		assertTrue(egm.move(source, target)); // move onto clear
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); // piece moves
		assertNull(egm.getPieceAt(source)); //old location is wiped
	}
	//triangle board linear with valid distance, flies onto opposing player
	@Test
	void triangleLinearityLandOnOpposingPlayerNortheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(7,  8);
		assertFalse(egm.move(source, target)); // cannot land on opposing player
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD); //second piece stays
	}
	//triangle board linear with valid distance, flies onto block
	@Test
	void triangleLinearityLandOnBlockNortheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(5,  6);
		assertFalse(egm.move(source, target)); // landing on block
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still block
	}
	//triangle board linear with move distance greater than given distance
	@Test
	void triangleLinearityMoreDistanceNortheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(9,  11);
		assertFalse(egm.move(source, target)); // too high of a distance
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still pieceless
	}
	// --------Norhwest--------
	//triangle board linear with valid distance, flies onto something that is not linear
	@Test
	void triangleLinearityDirectionIsNoneNorthwestward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(8,  3);
		assertFalse(egm.move(source, target)); // should return false because the move is not linear
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target has no piece still
	}
	//triangle board linear with valid distance, flies over block onto exit
	@Test
	void triangleLinearityLandOnExitNorthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(5,  3);
		assertTrue(egm.move(source, target)); // lands on exit
		assertNull(egm.getPieceAt(source)); // piece is removed
		assertNull(egm.getPieceAt(target)); //target is still exit
	}
	//triangle board linear with valid distance, flies over block onto clear
	@Test
	void triangleLinearityLandOnClearNorthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(6,  3);
		assertTrue(egm.move(source, target)); // move onto clear
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); // piece moves
		assertNull(egm.getPieceAt(source)); //old location is wiped
	}
	//triangle board linear with valid distance, flies onto opposing player
	@Test
	void triangleLinearityLandOnOpposingPlayerNorthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(7,  2);
		assertFalse(egm.move(source, target)); // cannot land on opposing player
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD); //second piece stays
	}
	//triangle board linear with valid distance, flies onto block
	@Test
	void triangleLinearityLandOnBlockNorthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(5,  4);
		assertFalse(egm.move(source, target)); // landing on block
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still block
	}
	//triangle board linear with move distance greater than given distance
	@Test
	void triangleLinearityMoreDistanceNorthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(8,  1);
		assertFalse(egm.move(source, target)); // too high of a distance
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still pieceless
	}	
	
	// --------east--------
	//triangle board linear with valid distance, flies onto something that is not linear
	@Test
	void triangleLinearityDirectionIsNoneEastwardUpward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(5,  12);
		assertFalse(egm.move(source, target)); // should return false because the move is not linear
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target has no piece still
	}
	//triangle board linear with valid distance, flies over block onto exit
	@Test
	void triangleLinearityLandOnExitEastUpward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(4,  7);
		assertTrue(egm.move(source, target)); // lands on exit
		assertNull(egm.getPieceAt(source)); // piece is removed
		assertNull(egm.getPieceAt(target)); //target is still exit
	}
	//triangle board linear with valid distance, flies over block onto clear
	@Test
	void triangleLinearityLandOnClearEastUpward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(4,  8);
		assertTrue(egm.move(source, target)); // move onto clear
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); // piece moves
		assertNull(egm.getPieceAt(source)); //old location is wiped
	}
	//triangle board linear with valid distance, flies onto opposing player
	@Test
	void triangleLinearityLandOnOpposingPlayerEastUpward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(4,  9);
		assertFalse(egm.move(source, target)); // cannot land on opposing player
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD); //second piece stays
	}
	//triangle board linear with valid distance, flies onto block
	@Test
	void triangleLinearityLandOnBlockEastUpward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(4,  6);
		assertFalse(egm.move(source, target)); // landing on block
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still block
	}
	//triangle board linear with move distance greater than given distance
	@Test
	void triangleLinearityMoreDistanceEastUpward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(4,  12);
		assertFalse(egm.move(source, target)); // too high of a distance
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still pieceless
	}
	//--------west--------
	//triangle board linear with valid distance, flies onto something that is not linear
	@Test
	void triangleLinearityDirectionIsNoneWestwardUpward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(5,  -1);
		assertFalse(egm.move(source, target)); // should return false because the move is not linear
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target has no piece still
	}
	//triangle board linear with valid distance, flies over block onto exit
	@Test
	void triangleLinearityLandOnExitWestUpward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(4,  3);
		assertTrue(egm.move(source, target)); // lands on exit
		assertNull(egm.getPieceAt(source)); // piece is removed
		assertNull(egm.getPieceAt(target)); //target is still exit
	}
	//triangle board linear with valid distance, flies over block onto clear
	@Test
	void triangleLinearityLandOnClearWestUpward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(4,  2);
		assertTrue(egm.move(source, target)); // move onto clear
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); // piece moves
		assertNull(egm.getPieceAt(source)); //old location is wiped
	}
	//triangle board linear with valid distance, flies onto opposing player
	@Test
	void triangleLinearityLandOnOpposingPlayerWestUpward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(4,  1);
		assertFalse(egm.move(source, target)); // cannot land on opposing player
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD); //second piece stays
	}
	//triangle board linear with valid distance, flies onto block
	@Test
	void triangleLinearityLandOnBlockWestUpward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(4,  4);
		assertFalse(egm.move(source, target)); // landing on block
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still block
	}
	//triangle board linear with move distance greater than given distance
	@Test
	void triangleLinearityMoreDistanceWestUpward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 5);
		Coordinate target = egm.makeCoordinate(4,  -2);
		assertFalse(egm.move(source, target)); // too high of a distance
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still pieceless
	}
	
	// --------Downward Facing--------
	// --------Southeast--------
	//triangle board linear with valid distance, flies onto something that is not linear
	@Test
	void triangleLinearityDirectionIsNoneSoutheastward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(6,  6);
		assertFalse(egm.move(source, target)); // should return false because the move is not linear
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target has no piece still
	}
	//triangle board linear with valid distance, flies over block onto exit
	@Test
	void triangleLinearityLandOnExitSoutheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(2,  7);
		assertTrue(egm.move(source, target)); // lands on exit
		assertNull(egm.getPieceAt(source)); // piece is removed
		assertNull(egm.getPieceAt(target)); //target is still exit
	}
	//triangle board linear with valid distance, flies over block onto clear
	@Test
	void triangleLinearityLandOnClearSoutheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(1,  7);
		assertTrue(egm.move(source, target)); // move onto clear
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); // piece moves
		assertNull(egm.getPieceAt(source)); //old location is wiped
	}	
	//triangle board linear with valid distance, flies onto opposing player
	@Test
	void triangleLinearityLandOnOpposingPlayerSoutheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(1,  8);
		assertFalse(egm.move(source, target)); // cannot land on opposing player
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD); //second piece stays
	}
	//triangle board linear with valid distance, flies onto block
	@Test
	void triangleLinearityLandOnBlockSoutheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(2,  6);
		assertFalse(egm.move(source, target)); // landing on block
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still block
	}
	//triangle board linear with move distance greater than given distance
	@Test
	void triangleLinearityMoreDistanceSoutheast() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(-1,  9);
		assertFalse(egm.move(source, target)); // too high of a distance
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still pieceless
	}
	
	// --------Southwest--------
	//triangle board linear with valid distance, flies onto something that is not linear
	@Test
	void triangleLinearityDirectionIsNoneSouthwestward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(1,  1);
		assertFalse(egm.move(source, target)); // should return false because the move is not linear
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target has no piece still
	}
	//triangle board linear with valid distance, flies over block onto exit
	@Test
	void triangleLinearityLandOnExitSouthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(2,  3);
		assertTrue(egm.move(source, target)); // lands on exit
		assertNull(egm.getPieceAt(source)); // piece is removed
		assertNull(egm.getPieceAt(target)); //target is still exit
	}
	//triangle board linear with valid distance, flies over block onto clear
	@Test
	void triangleLinearityLandOnClearSouthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(1,  3);
		assertTrue(egm.move(source, target)); // move onto clear
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); // piece moves
		assertNull(egm.getPieceAt(source)); //old location is wiped
	}	
	//triangle board linear with valid distance, flies onto opposing player
	@Test
	void triangleLinearityLandOnOpposingPlayerSouthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(1,  2);
		assertFalse(egm.move(source, target)); // cannot land on opposing player
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD); //second piece stays
	}
	//triangle board linear with valid distance, flies onto block
	@Test
	void triangleLinearityLandOnBlockSouthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(2,  4);
		assertFalse(egm.move(source, target)); // landing on block
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still block
	}
	//triangle board linear with move distance greater than given distance
	@Test
	void triangleLinearityMoreDistanceSouthwest() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(-1,  0);
		assertFalse(egm.move(source, target)); // too high of a distance
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still pieceless
	}
	// --------east--------
	//triangle board linear with valid distance, flies onto something that is not linear
	@Test
	void triangleLinearityDirectionIsNoneEastwardDownward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(5,  9);
		assertFalse(egm.move(source, target)); // should return false because the move is not linear
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target has no piece still
	}
	//triangle board linear with valid distance, flies over block onto exit
	@Test
	void triangleLinearityLandOnExitEastDownward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(3,  7);
		assertTrue(egm.move(source, target)); // lands on exit
		assertNull(egm.getPieceAt(source)); // piece is removed
		assertNull(egm.getPieceAt(target)); //target is still exit
	}
	//triangle board linear with valid distance, flies over block onto clear
	@Test
	void triangleLinearityLandOnClearEastDownward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(3,  8);
		assertTrue(egm.move(source, target)); // move onto clear
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); // piece moves
		assertNull(egm.getPieceAt(source)); //old location is wiped
	}
	//triangle board linear with valid distance, flies onto opposing player
	@Test
	void triangleLinearityLandOnOpposingPlayerEastDownward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(3,  9);
		assertFalse(egm.move(source, target)); // cannot land on opposing player
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD); //second piece stays
	}
	//triangle board linear with valid distance, flies onto block
	@Test
	void triangleLinearityLandOnBlockEastDownward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(3,  6);
		assertFalse(egm.move(source, target)); // landing on block
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still block
	}
	//triangle board linear with move distance greater than given distance
	@Test
	void triangleLinearityMoreDistanceEastDownward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(3,  12);
		assertFalse(egm.move(source, target)); // too high of a distance
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still pieceless
	}
	// --------west--------
	//triangle board linear with valid distance, flies onto something that is not linear
	@Test
	void triangleLinearityDirectionIsNoneWestwardDownward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(8,  0);
		assertFalse(egm.move(source, target)); // should return false because the move is not linear
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target has no piece still
	}
	//triangle board linear with valid distance, flies over block onto exit
	@Test
	void triangleLinearityLandOnExitWestDownward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(3,  3);
		assertTrue(egm.move(source, target)); // lands on exit
		assertNull(egm.getPieceAt(source)); // piece is removed
		assertNull(egm.getPieceAt(target)); //target is still exit
	}
	//triangle board linear with valid distance, flies over block onto clear
	@Test
	void triangleLinearityLandOnClearWestDownward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(3,  2);
		assertTrue(egm.move(source, target)); // move onto clear
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); // piece moves
		assertNull(egm.getPieceAt(source)); //old location is wiped
	}
	//triangle board linear with valid distance, flies onto opposing player
	@Test
	void triangleLinearityLandOnOpposingPlayerWestDownward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(3,  1);
		assertFalse(egm.move(source, target)); // cannot land on opposing player
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertEquals(egm.getPieceAt(target).getName(), PieceName.BIRD); //second piece stays
	}
	//triangle board linear with valid distance, flies onto block
	@Test
	void triangleLinearityLandOnBlockWestDownward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(3,  4);
		assertFalse(egm.move(source, target)); // landing on block
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still block
	}
	//triangle board linear with move distance greater than given distance
	@Test
	void triangleLinearityMoreDistanceWestDownward() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLinear.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(3, 5);
		Coordinate target = egm.makeCoordinate(3,  -2);
		assertFalse(egm.move(source, target)); // too high of a distance
		assertEquals(egm.getPieceAt(source).getName(), PieceName.SNAIL); // piece doesnt move
		assertNull(egm.getPieceAt(target)); //target still pieceless
	}
	
	//Turn Limit - SQUARE
	//a turn counts as the end of player 2's successful move
	@Test
	void squarePlayer1FalseCheckTurnLimit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TwoPieceSquareBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		SquareBoard board = (SquareBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate target = egm.makeCoordinate(1, 3);
		assertEquals(20, board.getTurnCount()); //original turn count
		assertFalse(egm.move(player2Source, target)); //cannot move Player 2 on P1
		assertEquals(20, board.getTurnCount()); //turn count doesnt change
		
	}
	@Test
	void squarePlayer2FalseCheckTurnLimit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TwoPieceSquareBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		SquareBoard board = (SquareBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate target = egm.makeCoordinate(1, 3);
		Coordinate target2 = egm.makeCoordinate(1, 5);
		assertEquals(20, board.getTurnCount()); //original turn count
		assertTrue(egm.move(player1Source, target)); //cannot move Player 2 on P1
		assertEquals(20, board.getTurnCount()); //turn count doesnt change
		assertFalse(egm.move(player2Source, target2)); //dog has diagonal pattern
		assertEquals(20, board.getTurnCount()); //turn count doesnt change
		
	}
	@Test
	void squarePlayer2TrueCheckTurnLimit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TwoPieceSquareBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		SquareBoard board = (SquareBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate target = egm.makeCoordinate(1, 3);
		Coordinate target2 = egm.makeCoordinate(2, 3);
		Coordinate target3 = egm.makeCoordinate(1, 4);
		assertEquals(20, board.getTurnCount()); //original turn count
		assertTrue(egm.move(player1Source, target)); //cannot move Player 2 on P1
		assertEquals(20, board.getTurnCount()); //turn count doesnt change
		assertTrue(egm.move(player2Source, target2)); //player 2 moves successfully
		assertEquals(19, board.getTurnCount()); //turn count decrements
		
	}
	@Test
	void squarePlayer1FalseAfterPlayer2TrueCheckTurnLimit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TwoPieceSquareBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		SquareBoard board = (SquareBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate target = egm.makeCoordinate(1, 3);
		Coordinate target2 = egm.makeCoordinate(2, 3);
		Coordinate target3 = egm.makeCoordinate(1, 4);
		Coordinate target4 = egm.makeCoordinate(20, 20);
		assertEquals(20, board.getTurnCount()); //original turn count
		assertTrue(egm.move(player1Source, target)); //cannot move Player 2 on P1
		assertEquals(20, board.getTurnCount()); //turn count doesnt change
		assertTrue(egm.move(player2Source, target2)); //player 2 moves successfully
		assertEquals(19, board.getTurnCount()); //turn count decrements
		assertFalse(egm.move(target, target4)); //piece doesnt have enough distance
		assertEquals(19, board.getTurnCount()); //turn count doesnt change
		
	}
	@Test
	void squarePlayer2FalseAfterPlayer2TrueCheckTurnLimit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TwoPieceSquareBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		SquareBoard board = (SquareBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate target = egm.makeCoordinate(1, 3);
		Coordinate target2 = egm.makeCoordinate(2, 3);
		Coordinate target3 = egm.makeCoordinate(1, 4);
		Coordinate target4 = egm.makeCoordinate(20, 20);
		assertEquals(20, board.getTurnCount()); //original turn count
		assertTrue(egm.move(player1Source, target)); //cannot move Player 2 on P1 -P2
		assertEquals(20, board.getTurnCount()); //turn count doesnt change
		assertTrue(egm.move(player2Source, target2)); //player 2 moves successfully -P1
		assertEquals(19, board.getTurnCount()); //turn count decrements
		assertFalse(egm.move(target, target4)); //piece doesnt have enough distance -P1
		assertTrue(egm.move(target, player2Source)); //player 1 success move -P2
		assertEquals(19, board.getTurnCount()); //turn count doesnt change
		assertFalse(egm.move(target2, target4)); //not enough distance -P2
		assertEquals(19, board.getTurnCount()); //turn count doesnt change
	}
	@Test
	void squarePlayer2TrueAfterPlayer2TrueCheckTurnLimit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TwoPieceSquareBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		SquareBoard board = (SquareBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate target = egm.makeCoordinate(1, 3);
		Coordinate target2 = egm.makeCoordinate(2, 3);
		Coordinate target3 = egm.makeCoordinate(1, 4);
		Coordinate target4 = egm.makeCoordinate(20, 20);
		Coordinate target5 = egm.makeCoordinate(3, 4);
		assertEquals(20, board.getTurnCount()); //original turn count
		assertTrue(egm.move(player1Source, target)); //cannot move Player 2 on P1 -P2
		assertEquals(20, board.getTurnCount()); //turn count doesnt change
		assertTrue(egm.move(player2Source, target2)); //player 2 moves successfully -P1
		assertEquals(19, board.getTurnCount()); //turn count decrements
		assertFalse(egm.move(target, target4)); //piece doesnt have enough distance -P1
		assertTrue(egm.move(target, player2Source)); //player 1 success move -P2
		assertEquals(19, board.getTurnCount()); //turn count doesnt change
		assertFalse(egm.move(target2, target4)); //not enough distance -P2
		assertEquals(19, board.getTurnCount()); //turn count doesnt change
		assertTrue(egm.move(target2, target5)); // player 2 successful move -P1
		assertEquals(18, board.getTurnCount()); //turn decrements 1 more
	}
	
	//Turn Limit - TRIANGLE
	//a turn counts as the end of player 2's successful move
	@Test
	void trianglePlayer1FalseCheckTurnLimit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TwoPieceTriangleBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		TriangleBoard board = (TriangleBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate target = egm.makeCoordinate(1, 3);
		assertEquals(20, board.getTurnCount()); //original turn count
		assertFalse(egm.move(player2Source, target)); //cannot move Player 2 on P1
		assertEquals(20, board.getTurnCount()); //turn count doesnt change
		
	}
	@Test
	void trianglePlayer2FalseCheckTurnLimit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TwoPieceTriangleBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		TriangleBoard board = (TriangleBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate target = egm.makeCoordinate(1, 3);
		Coordinate target2 = egm.makeCoordinate(1, 20);
		assertEquals(20, board.getTurnCount()); //original turn count
		assertTrue(egm.move(player1Source, target)); //p1 move is successful
		assertEquals(20, board.getTurnCount()); //turn count doesnt change
		assertFalse(egm.move(player2Source, target2)); //distance too great
		assertEquals(20, board.getTurnCount()); //turn count doesnt change
		
	}
	@Test
	void trianglePlayer2TrueCheckTurnLimit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TwoPieceTriangleBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		TriangleBoard board = (TriangleBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate target = egm.makeCoordinate(1, 3);
		Coordinate target2 = egm.makeCoordinate(2, 3);
		Coordinate target3 = egm.makeCoordinate(1, 4);
		assertEquals(20, board.getTurnCount()); //original turn count
		assertTrue(egm.move(player1Source, target)); //p1 has a successful move
		assertEquals(20, board.getTurnCount()); //turn count doesnt change
		assertTrue(egm.move(player2Source, target2)); //player 2 moves successfully
		assertEquals(19, board.getTurnCount()); //turn count decrements
		
	}
	@Test
	void trianglePlayer1FalseAfterPlayer2TrueCheckTurnLimit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TwoPieceTriangleBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		TriangleBoard board = (TriangleBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate target = egm.makeCoordinate(1, 3);
		Coordinate target2 = egm.makeCoordinate(2, 3);
		Coordinate target3 = egm.makeCoordinate(1, 4);
		Coordinate target4 = egm.makeCoordinate(20, 20);
		assertEquals(20, board.getTurnCount()); //original turn count
		assertTrue(egm.move(player1Source, target)); //player 1 successful
		assertEquals(20, board.getTurnCount()); //turn count doesnt change
		assertTrue(egm.move(player2Source, target2)); //player 2 moves successfully
		assertEquals(19, board.getTurnCount()); //turn count decrements
		assertFalse(egm.move(target, target4)); //piece doesnt have enough distance
		assertEquals(19, board.getTurnCount()); //turn count doesnt change
		
	}
	@Test
	void trianglePlayer2FalseAfterPlayer2TrueCheckTurnLimit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TwoPieceTriangleBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		TriangleBoard board = (TriangleBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate target = egm.makeCoordinate(1, 3);
		Coordinate target2 = egm.makeCoordinate(2, 3);
		Coordinate target3 = egm.makeCoordinate(1, 4);
		Coordinate target4 = egm.makeCoordinate(20, 20);
		assertEquals(20, board.getTurnCount()); //original turn count
		assertTrue(egm.move(player1Source, target)); //p1 successful, P2 turn
		assertEquals(20, board.getTurnCount()); //turn count doesnt change
		assertTrue(egm.move(player2Source, target2)); //player 2 moves successfully -P1
		assertEquals(19, board.getTurnCount()); //turn count decrements
		assertFalse(egm.move(target, target4)); //piece doesnt have enough distance -P1
		assertTrue(egm.move(target, player2Source)); //player 1 success move -P2
		assertEquals(19, board.getTurnCount()); //turn count doesnt change
		assertFalse(egm.move(target2, target4)); //not enough distance -P2
		assertEquals(19, board.getTurnCount()); //turn count doesnt change
	}
	@Test
	void trianglePlayer2TrueAfterPlayer2TrueCheckTurnLimit() throws Exception

	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TwoPieceTriangleBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		TriangleBoard board = (TriangleBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate target = egm.makeCoordinate(1, 3);
		Coordinate target2 = egm.makeCoordinate(2, 3);
		Coordinate target3 = egm.makeCoordinate(1, 4);
		Coordinate target4 = egm.makeCoordinate(20, 20);
		Coordinate target5 = egm.makeCoordinate(3, 4);
		assertEquals(20, board.getTurnCount()); //original turn count
		assertTrue(egm.move(player1Source, target)); //p1 successful - p2 turn
		assertEquals(20, board.getTurnCount()); //turn count doesnt change
		assertTrue(egm.move(player2Source, target2)); //player 2 moves successfully -P1
		assertEquals(19, board.getTurnCount()); //turn count decrements
		assertFalse(egm.move(target, target4)); //piece doesnt have enough distance -P1
		assertTrue(egm.move(target, player2Source)); //player 1 success move -P2
		assertEquals(19, board.getTurnCount()); //turn count doesnt change
		assertFalse(egm.move(target2, target4)); //not enough distance -P2
		assertEquals(19, board.getTurnCount()); //turn count doesnt change
		assertTrue(egm.move(target2, target5)); // player 2 successful move -P1
		assertEquals(18, board.getTurnCount()); //turn decrements 1 more
	}
	
	//Game Over with Turn Limit - SQUARE
	//the game ends when the turn limit hits 0
	@Test
	void endGameWithTurnLimitSquare() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/SquareBoard1Turn.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		SquareBoard board = (SquareBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate player1Target = egm.makeCoordinate(2, 2);
		Coordinate player2Target = egm.makeCoordinate(3, 3);
		assertEquals(1, board.getTurnCount()); //what we start with
		assertTrue(egm.move(player1Source,player1Target)); //P1 successful move
		assertEquals(1, board.getTurnCount()); //turn count shouldnt change yet
		assertTrue(egm.move(player2Source,player2Target)); //P2 successful move
		assertEquals(0, board.getTurnCount()); //now we decrement - game should be over
		assertFalse(egm.move(player1Target,player1Source)); //cant move
		assertFalse(egm.move(player2Target,player2Source)); //cant move
	}
	
	//Game Over with Turn Limit - Triangle
	//the game ends when the turn limit hits 0
	@Test
	void endGameWithTurnLimitTriangle() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/TriangleBoard1Turn.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		TriangleBoard board = (TriangleBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate player1Target = egm.makeCoordinate(2, 2);
		Coordinate player2Target = egm.makeCoordinate(3, 3);
		assertEquals(1, board.getTurnCount()); //what we start with
		assertTrue(egm.move(player1Source,player1Target)); //P1 successful move
		assertEquals(1, board.getTurnCount()); //turn count shouldnt change yet
		assertTrue(egm.move(player2Source,player2Target)); //P2 successful move
		assertEquals(0, board.getTurnCount()); //now we decrement - game should be over
		assertFalse(egm.move(player1Target,player1Source)); //cant move
		assertFalse(egm.move(player2Target,player2Source)); //cant move
	}

	//Game Scoring - SQUARE
	//This first test will check to see if not given a value, we get 1
	@Test
	void defaultPieceValueSquareGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/ValueTestSquareBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		SquareBoard board = (SquareBoard) egmi.getBoard();
		Coordinate source = egm.makeCoordinate(1, 1);
		Coordinate target = egm.makeCoordinate(1, 3);
		EscapePieceImpl piecer = (EscapePieceImpl) egm.getPieceAt(source); //gets piece at 1,1 
		assertEquals(10, board.getGameScore()); //ensure the game Score is correctly set
		assertEquals(1, piecer.getPieceVal()); //player 1 has no value so we give it 1
	}
	//This test makes sure no score is added if a player makes a move that is not exit
	@Test
	void nonScoringP1MoveSquareGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/ValueTestSquareBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		SquareBoard board = (SquareBoard) egmi.getBoard();
		Coordinate source = egm.makeCoordinate(1, 1);
		Coordinate target = egm.makeCoordinate(1, 3);
		assertTrue(egm.move(source, target));
		assertEquals(0, board.getPlayerOneScore()); //player 1 doesnt total
		assertEquals(0, board.getPlayerTwoScore()); //player 2 doesnt get a total either
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL);
		assertNull(egm.getPieceAt(source));
	}
	//This test makes sure no score is added if a player makes a move that is not exit
	@Test
	void nonScoringP2MoveSquareGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/ValueTestSquareBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		SquareBoard board = (SquareBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate target1 = egm.makeCoordinate(1, 3);
		Coordinate target2 = egm.makeCoordinate(1, 6);
		assertTrue(egm.move(player1Source, target1)); //p1 moves to empty
		assertEquals(0, board.getPlayerOneScore()); //player 1 doesnt total
		assertEquals(0, board.getPlayerTwoScore()); //player 2 doesnt get a total either
		assertEquals(egm.getPieceAt(target1).getName(), PieceName.SNAIL); //success move
		assertNull(egm.getPieceAt(player1Source)); //remove piece from old
		
		assertTrue(egm.move(player2Source, target2)); //p2 moves to empty
		assertEquals(0, board.getPlayerOneScore()); //player 1 doesnt total
		assertEquals(0, board.getPlayerTwoScore()); //player 2 doesnt get a total either
		assertEquals(egm.getPieceAt(target2).getName(), PieceName.DOG); //success move
		assertNull(egm.getPieceAt(player2Source)); //remove piece from old
	}
	//This test makes sure score is added once player one exits the board
	@Test
	void scoringP1MoveSquareGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/ValueTestSquareBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		SquareBoard board = (SquareBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate target1 = egm.makeCoordinate(1, 3);
		Coordinate target2 = egm.makeCoordinate(1, 6);
		Coordinate exit = egm.makeCoordinate(1, 5);
		assertTrue(egm.move(player1Source, target1)); //p1 moves to empty
		assertEquals(0, board.getPlayerOneScore()); //player 1 doesnt total
		assertEquals(0, board.getPlayerTwoScore()); //player 2 doesnt get a total either
		assertEquals(egm.getPieceAt(target1).getName(), PieceName.SNAIL); //success move
		assertNull(egm.getPieceAt(player1Source)); //remove piece from old
		
		assertTrue(egm.move(player2Source, target2)); //p2 moves to empty
		assertEquals(0, board.getPlayerOneScore()); //player 1 doesnt total
		assertEquals(0, board.getPlayerTwoScore()); //player 2 doesnt get a total either
		assertEquals(egm.getPieceAt(target2).getName(), PieceName.DOG); //success move
		assertNull(egm.getPieceAt(player2Source)); //remove piece from old
		
		assertTrue(egm.move(target1, exit)); //player 1 moves to exit
		assertNull(egm.getPieceAt(target1)); //old position is wiped
		assertNull(egm.getPieceAt(exit)); //the target is still exit
		assertEquals(1, board.getPlayerOneScore()); //player 1 should be 1
		assertEquals(0, board.getPlayerTwoScore()); //player 1 should be 1
	}
	//This test makes sure score is added once player two exits the board
	@Test
	void almostScoringP2MoveSquareGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/ValueTestSquareBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		SquareBoard board = (SquareBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(1, 1);
		Coordinate player2Source = egm.makeCoordinate(1, 2);
		Coordinate target1 = egm.makeCoordinate(1, 3);
		Coordinate target2 = egm.makeCoordinate(1, 6);
		Coordinate exit = egm.makeCoordinate(1, 5);
		assertTrue(egm.move(player1Source, target1)); //p1 moves to empty
		assertEquals(0, board.getPlayerOneScore()); //player 1 doesnt total
		assertEquals(0, board.getPlayerTwoScore()); //player 2 doesnt get a total either
		assertEquals(egm.getPieceAt(target1).getName(), PieceName.SNAIL); //success move
		assertNull(egm.getPieceAt(player1Source)); //remove piece from old
		
		assertTrue(egm.move(player2Source, target2)); //p2 moves to empty
		assertEquals(0, board.getPlayerOneScore()); //player 1 doesnt total
		assertEquals(0, board.getPlayerTwoScore()); //player 2 doesnt get a total either
		assertEquals(egm.getPieceAt(target2).getName(), PieceName.DOG); //success move
		assertNull(egm.getPieceAt(player2Source)); //remove piece from old
		
		assertTrue(egm.move(target1, exit)); //player 1 moves to exit
		assertNull(egm.getPieceAt(target1)); //old position is wiped
		assertNull(egm.getPieceAt(exit)); //the target is still exit
		assertEquals(1, board.getPlayerOneScore()); //player 1 should be 1
		assertEquals(0, board.getPlayerTwoScore()); //player 2 should be 0
		
		assertTrue(egm.move(target2, exit)); // player 2 moves to exit
		assertNull(egm.getPieceAt(target2)); //old position is wiped
		assertNull(egm.getPieceAt(exit)); //the target is still exit
		assertEquals(1, board.getPlayerOneScore()); //player 1 should be 1
		assertEquals(0, board.getPlayerTwoScore()); //player 2 gets 0 here because they dont have the value attribute
	}
	//This test makes sure that the winner is the player who extracts higher than gameScore first
	@Test
	void player1PointExtractionGameOverSquareGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLargeValue.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		SquareBoard board = (SquareBoard) egmi.getBoard();
		Coordinate source1P1 = egm.makeCoordinate(7, 6);
		Coordinate source1P2 = egm.makeCoordinate(7, 8);
		Coordinate exit = egm.makeCoordinate(6, 7);
		assertEquals(10, board.getGameScore()); //should return 10
		assertTrue(egm.move(source1P1, exit)); //player 1 moves to exit - score should be 300
		assertFalse(egm.move(source1P2, exit)); //player 1 is already winner
	}
	//This test makes sure that the winner is the player who extracts higher than gameScore first
	@Test
	void player2PointExtractionGameOverSquareGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareLargeValue.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		SquareBoard board = (SquareBoard) egmi.getBoard();
		Coordinate source1P1 = egm.makeCoordinate(7, 6);
		Coordinate source1P2 = egm.makeCoordinate(7, 8);
		Coordinate exit = egm.makeCoordinate(6, 7);
		assertEquals(10, board.getGameScore()); //should return 10
		assertTrue(egm.move(source1P1, egm.makeCoordinate(7, 7))); //player 1 makes normal move
		assertTrue(egm.move(source1P2, exit)); //player 2 cashes in
		assertFalse(egm.move(source1P1, exit)); //cant move bc game is over
	}
	//Game Scoring - TRIANGLE
	//This first test will check to see if not given a value, we get 1
	@Test
	void defaultPieceValueTriangleGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/ValueTestTriangleBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		TriangleBoard board = (TriangleBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(2, 5);
		Coordinate player1Target = egm.makeCoordinate(4, 5);
		EscapePieceImpl piecer = (EscapePieceImpl) egm.getPieceAt(player1Source);
		assertEquals(13, board.getGameScore()); //make sure gameScore is correct
		assertEquals(1, piecer.getPieceVal()); //player 1 has no value so we give it 1
		
	}
	//This test makes sure no score is added if a player makes a move that is not exit
	@Test
	void nonScoringP1MoveTriangleGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/ValueTestTriangleBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		TriangleBoard board = (TriangleBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(2, 5);
		Coordinate player1Target = egm.makeCoordinate(4, 5);
		EscapePieceImpl piecer = (EscapePieceImpl) egm.getPieceAt(player1Source);
		assertEquals(13, board.getGameScore()); //make sure gameScore is correct
		assertEquals(1, piecer.getPieceVal()); //player 1 has no value so we give it 1
		
		assertTrue(egm.move(player1Source, player1Target)); //successful move from 2,5 to 4,5
		assertEquals(egm.getPieceAt(player1Target).getName(), PieceName.SNAIL); //piece is moved
		assertNull(egm.getPieceAt(player1Source)); //old location is wiped
		assertEquals(0, board.getPlayerOneScore()); //player 1 has nothing
		assertEquals(0, board.getPlayerTwoScore()); //player 2 has nothing
		
	}
	//This test makes sure no score is added if a player makes a move that is not exit
	@Test
	void nonScoringP2MoveTriangleGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/ValueTestTriangleBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		TriangleBoard board = (TriangleBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(2, 5);
		Coordinate player1Target = egm.makeCoordinate(4, 5);
		Coordinate player2Source = egm.makeCoordinate(2, 4);
		Coordinate player2Target = egm.makeCoordinate(2, 2);
		EscapePieceImpl piecer = (EscapePieceImpl) egm.getPieceAt(player1Source);
		assertEquals(13, board.getGameScore()); //make sure gameScore is correct
		assertEquals(1, piecer.getPieceVal()); //player 1 has no value so we give it 1
		
		assertTrue(egm.move(player1Source, player1Target)); //successful move from 2,5 to 4,5
		assertEquals(egm.getPieceAt(player1Target).getName(), PieceName.SNAIL); //piece is moved
		assertNull(egm.getPieceAt(player1Source)); //old location is wiped
		assertEquals(0, board.getPlayerOneScore()); //player 1 has nothing
		assertEquals(0, board.getPlayerTwoScore()); //player 2 has nothing
		
		assertTrue(egm.move(player2Source, player2Target)); //successful move from 2,4 to 2,2
		assertEquals(egm.getPieceAt(player2Target).getName(), PieceName.DOG); //piece is moved
		assertNull(egm.getPieceAt(player2Source)); //old location is wiped
		assertEquals(0, board.getPlayerOneScore()); //player 1 has nothing
		assertEquals(0, board.getPlayerTwoScore()); //player 2 has nothing
		
	}
	//This test makes sure score is added once player one exits the board
	@Test
	void scoringP1MoveTriangleGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/ValueTestTriangleBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		TriangleBoard board = (TriangleBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(2, 5);
		Coordinate player1Target = egm.makeCoordinate(4, 5);
		Coordinate player2Source = egm.makeCoordinate(2, 4);
		Coordinate player2Target = egm.makeCoordinate(2, 2);
		Coordinate exit = egm.makeCoordinate(1, 5);
		EscapePieceImpl piecer = (EscapePieceImpl) egm.getPieceAt(player1Source);
		assertEquals(13, board.getGameScore()); //make sure gameScore is correct
		assertEquals(1, piecer.getPieceVal()); //player 1 has no value so we give it 1
		
		assertTrue(egm.move(player1Source, player1Target)); //successful move from 2,5 to 4,5
		assertEquals(egm.getPieceAt(player1Target).getName(), PieceName.SNAIL); //piece is moved
		assertNull(egm.getPieceAt(player1Source)); //old location is wiped
		assertEquals(0, board.getPlayerOneScore()); //player 1 has nothing
		assertEquals(0, board.getPlayerTwoScore()); //player 2 has nothing
		
		assertTrue(egm.move(player2Source, player2Target)); //successful move from 2,4 to 2,2
		assertEquals(egm.getPieceAt(player2Target).getName(), PieceName.DOG); //piece is moved
		assertNull(egm.getPieceAt(player2Source)); //old location is wiped
		assertEquals(0, board.getPlayerOneScore()); //player 1 has nothing
		assertEquals(0, board.getPlayerTwoScore()); //player 2 has nothing
		
		assertTrue(egm.move(player1Target, exit)); //player 1 moves to exit
		assertNull(egm.getPieceAt(player1Target)); //old location wiped
		assertNull(egm.getPieceAt(exit)); //target is still exit
		assertEquals(1, board.getPlayerOneScore()); //player 1 cashes in
		assertEquals(0, board.getPlayerTwoScore()); //player 2 has nothing
		
		
	}
	//This test makes sure score is added once player two exits the board
	@Test
	void almostScoringP2MoveTriangleGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/ValueTestTriangleBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		TriangleBoard board = (TriangleBoard) egmi.getBoard();
		Coordinate player1Source = egm.makeCoordinate(2, 5);
		Coordinate player1Target = egm.makeCoordinate(4, 5);
		Coordinate player2Source = egm.makeCoordinate(2, 4);
		Coordinate player2Target = egm.makeCoordinate(2, 2);
		Coordinate exit = egm.makeCoordinate(1, 5);
		EscapePieceImpl piecer = (EscapePieceImpl) egm.getPieceAt(player1Source);
		assertEquals(13, board.getGameScore()); //make sure gameScore is correct
		assertEquals(1, piecer.getPieceVal()); //player 1 has no value so we give it 1
		
		assertTrue(egm.move(player1Source, player1Target)); //successful move from 2,5 to 4,5
		assertEquals(egm.getPieceAt(player1Target).getName(), PieceName.SNAIL); //piece is moved
		assertNull(egm.getPieceAt(player1Source)); //old location is wiped
		assertEquals(0, board.getPlayerOneScore()); //player 1 has nothing
		assertEquals(0, board.getPlayerTwoScore()); //player 2 has nothing
		
		assertTrue(egm.move(player2Source, player2Target)); //successful move from 2,4 to 2,2
		assertEquals(egm.getPieceAt(player2Target).getName(), PieceName.DOG); //piece is moved
		assertNull(egm.getPieceAt(player2Source)); //old location is wiped
		assertEquals(0, board.getPlayerOneScore()); //player 1 has nothing
		assertEquals(0, board.getPlayerTwoScore()); //player 2 has nothing
		
		assertTrue(egm.move(player1Target, exit)); //player 1 moves to exit
		assertNull(egm.getPieceAt(player1Target)); //old location wiped
		assertNull(egm.getPieceAt(exit)); //target is still exit
		assertEquals(1, board.getPlayerOneScore()); //player 1 cashes in
		assertEquals(0, board.getPlayerTwoScore()); //player 2 has nothing
		
		assertTrue(egm.move(player2Target, exit)); //player 1 moves to exit
		assertNull(egm.getPieceAt(player2Target)); //old location wiped
		assertNull(egm.getPieceAt(exit)); //target is still exit
		assertEquals(1, board.getPlayerOneScore()); //player 1 cashes in
		assertEquals(0, board.getPlayerTwoScore()); //player 2 has nothing
	
	}
	//This test makes sure that the winner is the player who extracts higher than gameScore first
	@Test
	void player1PointExtractionGameOverTriangleGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLargeValue.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		TriangleBoard board = (TriangleBoard) egmi.getBoard();
		Coordinate source1P1 = egm.makeCoordinate(2, 4);
		Coordinate source1P2 = egm.makeCoordinate(2, 6);
		Coordinate exit = egm.makeCoordinate(2, 5);
		assertEquals(10, board.getGameScore()); //should return 10
		assertTrue(egm.move(source1P1, exit)); //player 1 moves to exit
		assertFalse(egm.move(source1P2, exit)); //cannot move bc player 1 already wins
	}
	//This test makes sure that the winner is the player who extracts higher than gameScore first
	@Test
	void player2PointExtractionGameOverTriangleGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaTriangleLargeValue.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		TriangleBoard board = (TriangleBoard) egmi.getBoard();
		Coordinate source1P1 = egm.makeCoordinate(2, 4);
		Coordinate source1P2 = egm.makeCoordinate(2, 6);
		Coordinate exit = egm.makeCoordinate(2, 5);
		assertEquals(10, board.getGameScore()); //should return 10
		assertTrue(egm.move(source1P1, egm.makeCoordinate(2, 3))); //player 1 makes normal move
		assertTrue(egm.move(source1P2, exit)); //player 2 cashes in and wins
		assertFalse(egm.move(source1P1, exit)); //game is considered over here
	}
	//Piece Count, Piece Totaler - SQUARE
	//This first test will check to make sure that pieces are being removed correctly
	//In addition, the scores will be checked to make sure that scores are totaling
	//the way that they should be.
	@Test
	void pieceCountCheckerScoreTotallerSquareGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceCheckSquareGame.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		SquareBoard board = (SquareBoard) egmi.getBoard();
		Coordinate source1P1 = egm.makeCoordinate(5, 7);
		Coordinate source2P1 = egm.makeCoordinate(6, 7);
		Coordinate source3P1 = egm.makeCoordinate(7, 7);
		Coordinate source4P1 = egm.makeCoordinate(5, 9);
		Coordinate source5P1 = egm.makeCoordinate(7, 9);
		Coordinate exit = egm.makeCoordinate(6, 8);
		Coordinate source1P2 = egm.makeCoordinate(5, 8);
		Coordinate source2P2 = egm.makeCoordinate(7, 8);
		Coordinate source3P2 = egm.makeCoordinate(6, 9);
		assertEquals(20, board.getGameScore()); //make sure gameScore is correct
		assertEquals(0, board.getPlayerOneScore()); //player scores still 0
		assertEquals(0, board.getPlayerTwoScore()); //player scores still 0
		assertEquals(5, board.getPlayer1Count()); //player 1 has 5 pieces starting
		assertEquals(3, board.getPlayer2Count()); //player 2 has 3 pieces starting
		//Player1 moves 1 piece to exit
		assertTrue(egm.move(source1P1, exit)); //player 1 moves to exit
		assertEquals(3, board.getPlayerOneScore()); //player 1 score increases 3
		assertEquals(0, board.getPlayerTwoScore()); //player scores still 0
		assertEquals(4, board.getPlayer1Count()); //player 1 has 4 pieces remaining
		assertEquals(3, board.getPlayer2Count()); //player 2 has 3 pieces remaining
		//Player2 moves 1 piece to exit
		assertTrue(egm.move(source1P2, exit)); //player 2 moves to exit
		assertEquals(3, board.getPlayerOneScore()); //player 1 score still 3
		assertEquals(5, board.getPlayerTwoScore()); //player 2 score increases 5
		assertEquals(4, board.getPlayer1Count()); //player 1 has 4 pieces remaining
		assertEquals(2, board.getPlayer2Count()); //player 2 has 2 pieces remaining
		//Player1 moves its 2nd piece to exit
		assertTrue(egm.move(source2P1, exit)); //player 1 moves to exit
		assertEquals(6, board.getPlayerOneScore()); //player 1 score increases to 6
		assertEquals(5, board.getPlayerTwoScore()); //player 2 score still 5
		assertEquals(3, board.getPlayer1Count()); //player 1 has 3 pieces remaining
		assertEquals(2, board.getPlayer2Count()); //player 2 has 2 pieces remaining
		//Player2 moves its 2nd piece to exit
		assertTrue(egm.move(source2P2, exit)); //player 2 moves to exit
		assertEquals(6, board.getPlayerOneScore()); //player 1 score still at 6
		assertEquals(10, board.getPlayerTwoScore()); //player 2 score increases to 10
		assertEquals(3, board.getPlayer1Count()); //player 1 has 3 pieces remaining
		assertEquals(1, board.getPlayer2Count()); //player 1 has 1 pieces remaining
		//Player1 moves its 3rd piece to exit
		assertTrue(egm.move(source3P1, exit)); //player 1 moves to exit
		assertEquals(9, board.getPlayerOneScore()); //player 1 score increases to 9
		assertEquals(10, board.getPlayerTwoScore()); //player 2 score stays at 10
		assertEquals(2, board.getPlayer1Count()); //player 1 has 2 pieces remaining
		assertEquals(1, board.getPlayer2Count()); //player 1 has 1 pieces remaining
		//Player2 moves to a valid place not exit
		assertTrue(egm.move(source3P2, egm.makeCoordinate(6, 10))); //successful move
		assertEquals(9, board.getPlayerOneScore()); //player 1 score stays at 9
		assertEquals(10, board.getPlayerTwoScore()); //player 2 score stays at 10
		assertEquals(2, board.getPlayer1Count()); //player 1 has 2 pieces remaining
		assertEquals(1, board.getPlayer2Count()); //player 1 has 1 pieces remaining
		//Player1 moves its 4th piece to exit
		assertTrue(egm.move(source4P1, exit)); //player 1 moves to exit
		assertEquals(12, board.getPlayerOneScore()); //player 1 score increases to 12
		assertEquals(10, board.getPlayerTwoScore()); //player 2 score stays at 10
		assertEquals(1, board.getPlayer1Count()); //player 1 has 1 pieces remaining
		assertEquals(1, board.getPlayer2Count()); //player 1 has 1 pieces remaining
		//Player2 moves to a valid place not exit
		assertTrue(egm.move(egm.makeCoordinate(6, 10), source3P2)); //successful move
		assertEquals(12, board.getPlayerOneScore()); //player 1 score stays at 9
		assertEquals(10, board.getPlayerTwoScore()); //player 2 score stays at 10
		assertEquals(1, board.getPlayer1Count()); //player 1 has 1 pieces remaining
		assertEquals(1, board.getPlayer2Count()); //player 1 has 1 pieces remaining
		//Player1 moves its final piece to exit - we should give player 2 a turn here
		assertTrue(egm.move(source5P1, exit)); //player 1 eliminates all pieces
		assertEquals(15, board.getPlayerOneScore()); //player 1 score increases to 15
		assertEquals(10, board.getPlayerTwoScore()); //player 2 score stays at 10
		assertEquals(0, board.getPlayer1Count()); //player 1 has 0 pieces remaining
		assertEquals(1, board.getPlayer2Count()); //player 1 has 1 pieces remaining
		//Player2 can finish its move 
		assertTrue(egm.move(source3P2, egm.makeCoordinate(6, 10))); //successful move
		assertEquals(15, board.getPlayerOneScore()); //player 1 score stays at 15
		assertEquals(10, board.getPlayerTwoScore()); //player 2 score stays at 10
		assertEquals(0, board.getPlayer1Count()); //player 1 has 0 pieces remaining
		assertEquals(1, board.getPlayer2Count()); //player 1 has 1 pieces remaining
		
		//there are no more pieces to move for P1 here
		
		
	}
	//Piece Count, Piece Totaler - TRIANGLE
	//This first test will check to make sure that pieces are being removed correctly
	//In addition, the scores will be checked to make sure that scores are totaling
	//the way that they should be.
	@Test
	void pieceCountCheckerScoreTotallerTriangleGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceCheckTriangleGame.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		TriangleBoard board = (TriangleBoard) egmi.getBoard();
		Coordinate source1P1 = egm.makeCoordinate(2, 4);
		Coordinate source2P1 = egm.makeCoordinate(1, 5);
		Coordinate source1P2 = egm.makeCoordinate(2, 6);
		Coordinate source2P2 = egm.makeCoordinate(2, 7);
		Coordinate exit = egm.makeCoordinate(2, 5);
		assertEquals(20, board.getGameScore()); //make sure gameScore is correct
		assertEquals(0, board.getPlayerOneScore()); //player scores still 0
		assertEquals(0, board.getPlayerTwoScore()); //player scores still 0
		assertEquals(2, board.getPlayer1Count()); //player 1 has 2 pieces starting
		assertEquals(2, board.getPlayer2Count()); //player 2 has 2 pieces starting
		//player 1 moves first piece to exit
		assertTrue(egm.move(source1P1, exit));
		assertEquals(3, board.getPlayerOneScore()); //player 1 score increases to 3
		assertEquals(0, board.getPlayerTwoScore()); //player 2 score stays at 0
		assertEquals(1, board.getPlayer1Count()); //player 1 has 1 piece left now
		assertEquals(2, board.getPlayer2Count()); //player 2 has 2 pieces still
		//player 2 moves first piece to exit
		assertTrue(egm.move(source1P2, exit));
		assertEquals(3, board.getPlayerOneScore()); //player 1 score stays at 3
		assertEquals(5, board.getPlayerTwoScore()); //player 2 score increases to 5
		assertEquals(1, board.getPlayer1Count()); //player 1 has 1 piece left now
		assertEquals(1, board.getPlayer2Count()); //player 2 has 1 piece left now
		//player 1 moves its last piece to exit for the win
		assertTrue(egm.move(source2P1, exit));
		assertEquals(6, board.getPlayerOneScore()); //player 1 score increases to 6
		assertEquals(5, board.getPlayerTwoScore()); //player 2 score stays at 5
		assertEquals(0, board.getPlayer1Count()); //player 1 has 0 pieces left now
		assertEquals(1, board.getPlayer2Count()); //player 2 has 1 piece still
		//player 2 moves to exit now - game is already over though
		assertTrue(egm.move(source2P2, exit));
		assertEquals(6, board.getPlayerOneScore()); //player 1 score stays at 6
		assertEquals(10, board.getPlayerTwoScore()); //player 2 score increases to 10
		assertEquals(0, board.getPlayer1Count()); //player 1 has 1 piece left now
		assertEquals(0, board.getPlayer2Count()); //player 2 has 1 piece left now
		
	}

	//AddObserver - SQUARE
	//This test just ensures that the observer is obtaining the right message at
	//the right point in time. 
	//The simplest thing I could think of for this is when move is given a false requirement
	@Test
	void addObserverSquareGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceCheckSquareGame.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		MasterTestObserver observer = new MasterTestObserver();
		egm.addObserver(observer);
		Coordinate source = egm.makeCoordinate(5, 7);
		Coordinate wayOff = egm.makeCoordinate(500, 500);
		assertFalse(egm.move(source, wayOff)); //exceeds the boundaries
		assertEquals("The move fails a pre-requisite check.", observer.nextMessage().message);
	}
	//RemoveObserver - SQUARE
	//This test checks to see if removeObserver has valid functionality within the game
	@Test
	void removeObserverSquareGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceCheckSquareGame.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		MasterTestObserver observer = new MasterTestObserver();
		egm.addObserver(observer);
		Coordinate source = egm.makeCoordinate(5, 7);
		Coordinate wayOff = egm.makeCoordinate(500, 500);
		egm.removeObserver(observer);
		assertFalse(egm.move(source, wayOff)); //exceeds the boundaries
		assertNull(observer.nextMessage()); //now we dont have an observer to get messages from
	}
	//AddObserver - TRIANGLE
	//This test just ensures that the observer is obtaining the right message at
	//the right point in time. 
	//The simplest thing I could think of for this is when move is given a false requirement
	@Test
	void addObserverTriangleGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceCheckTriangleGame.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		MasterTestObserver observer = new MasterTestObserver();
		egm.addObserver(observer);
		Coordinate source = egm.makeCoordinate(2, 4);
		Coordinate wayOff = egm.makeCoordinate(500, 500);
		assertFalse(egm.move(source, wayOff)); //exceeds the boundaries
		assertEquals("The move fails a pre-requisite check.", observer.nextMessage().message);
	}
	//RemoveObserver - TRIANGLE
	//This test checks to see if removeObserver has valid functionality within the game
	@Test
	void removeObserverTriangleGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/PieceCheckTriangleGame.egc");
		EscapeGameManager egm = egb.makeGameManager();
		EscapeGameManagerImpl egmi = (EscapeGameManagerImpl) egm;
		MasterTestObserver observer = new MasterTestObserver();
		egm.addObserver(observer);
		Coordinate source = egm.makeCoordinate(2, 4);
		Coordinate wayOff = egm.makeCoordinate(500, 500);
		egm.removeObserver(observer);
		assertFalse(egm.move(source, wayOff)); //exceeds the boundaries
		assertNull(observer.nextMessage()); //now we dont have an observer to get messages from
	}
	
	//Move with Unblock - SQUARE
	//This test checks the ability of using unblock with distance, and having it go
	//through the pathFinder in order to get past a barrier of blocks.
	@Test
	void movePastBlocksUsingUnblockSquareGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareUnblock.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(5, 6);
		Coordinate target = egm.makeCoordinate(7, 6);
		assertTrue(egm.move(source, target));
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); //player unblocks its way to the target
		assertNull(egm.getPieceAt(source)); //player has moved
	}
	
	//This test uses the last as a building block
	//We are to have player 2 use unblock to get into the barricade that player 1 got out of
	// into another barricade, and out of that one
	@Test
	void movePastTwoBlockBarricadesSquareGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareUnblock.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate sourceP1 = egm.makeCoordinate(5, 6);
		Coordinate sourceP2 = egm.makeCoordinate(3, 6);
		Coordinate target = egm.makeCoordinate(7, 6);
		assertTrue(egm.move(sourceP1, target));
		assertEquals(egm.getPieceAt(target).getName(), PieceName.SNAIL); //player unblocks its way to the target
		assertNull(egm.getPieceAt(sourceP1)); //player has moved
		
		assertTrue(egm.move(sourceP2, sourceP1)); //move P2 into barricade
		assertEquals(egm.getPieceAt(sourceP1).getName(), PieceName.DOG);
		assertNull(egm.getPieceAt(sourceP2));
		
		assertTrue(egm.move(target, egm.makeCoordinate(8, 6))); //ordinary move
		assertEquals(egm.getPieceAt(egm.makeCoordinate(8, 6)).getName(), PieceName.SNAIL);
		assertNull(egm.getPieceAt(target));
		
		assertTrue(egm.move(sourceP1, egm.makeCoordinate(9, 10))); //gets through double barricade
		assertEquals(egm.getPieceAt(egm.makeCoordinate(9, 10)).getName(), PieceName.DOG);
		assertNull(egm.getPieceAt(sourceP1));
	}
	
	//This test uses the same egc as the last and uses diagonal to overcome unblock barricade
	@Test
	void diagonalUnblockBarricadeSquareGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/gammaSquareUnblock.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate source = egm.makeCoordinate(4, 12);
		Coordinate target = egm.makeCoordinate(7, 15);
		assertTrue(egm.move(source, target));
		assertEquals(egm.getPieceAt(target).getName(), PieceName.HORSE);
		assertNull(egm.getPieceAt(source));
	}
	
}