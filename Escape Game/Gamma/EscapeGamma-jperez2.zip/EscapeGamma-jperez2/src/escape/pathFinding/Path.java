/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Copyright ©2020 Gary F. Pollice
 *******************************************************************************/
package escape.pathFinding;

import java.util.LinkedList;
import java.util.List;

import escape.coordinate.EscapeCoordinateImpl;
import escape.coordinate.EscapeCoordinateImpl.CompassRose;
import escape.piece.EscapePieceImpl;
import escape.piece.EscapePiece.PieceAttributeID;
/**
 * The following code is Professor Pollices code adopted and modified by myself to suit
 * design pattern.
 * @author Gary Pollice with modifications by Jerry Perez
 *
 * @param <C>
 */
public class Path <C extends EscapeCoordinateImpl>
{
	
	private final LinkedList<EscapeCoordinateImpl> path;
    
    public Path(C first)
    {
        path = new LinkedList<EscapeCoordinateImpl>();
        path.add(first);
    }
    
    private Path(LinkedList<EscapeCoordinateImpl> path)
    {
        this.path = path;
    }
    
    public Path<EscapeCoordinateImpl> extend(EscapeCoordinateImpl next)
    {
    	//adds a new node
        LinkedList<EscapeCoordinateImpl> p = (LinkedList<EscapeCoordinateImpl>) path.clone();
        p.add(next);
        return new Path<EscapeCoordinateImpl>(p);
    }
    
    public EscapeCoordinateImpl getLast()
    {
    	return path.getLast();
    }
    
    public List<EscapeCoordinateImpl> getPath()
    {
        return path;
    }
    
    public int length()
    {
        return path.size();
    }
    
    public boolean isLinear(EscapePieceImpl p)
    {
        boolean result = true;
        
        if (p.hasAttribute(PieceAttributeID.FLY)) 
        {
        	//true if the path is not none
        	result = path.getFirst().getDirectionTo(path.getLast()) != CompassRose.NONE;
        }
        
        else if (path.size() > 2) //if the pathsize is greater than 2 
        { 
            for (int i = 1; i < path.size() - 1; i++) 
            {
                if (path.get(i).getDirectionTo(path.get(i+1)) != path.get(0).getDirectionTo(path.get(1))) 
                {
                	//direction from 1 to 2 != direction from 0 to 1 
                    result = false;
                    break;
                }
            }
        }
        return result;
    }

}
