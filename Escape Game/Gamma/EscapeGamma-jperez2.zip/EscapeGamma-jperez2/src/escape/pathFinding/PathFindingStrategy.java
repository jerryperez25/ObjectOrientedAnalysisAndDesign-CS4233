/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Copyright ©2020 Gary F. Pollice
 *******************************************************************************/
package escape.pathFinding;

import escape.coordinate.EscapeCoordinateImpl;
import escape.piece.EscapePieceImpl;

public interface PathFindingStrategy <C extends EscapeCoordinateImpl>
{
	/**
	 * Find a valid path between two locations. If there is none, return null.
	 * There may be more than one path. Just one is returned that is valid.
	 * @param p the piece trying to move
	 * @param from the starting location
	 * @param to the final location
	 * @return a list containing the path between the two coordinates that is valid
	 * 	or null
	 */
	Path<EscapeCoordinateImpl> findPath(EscapePieceImpl p, EscapeCoordinateImpl from, EscapeCoordinateImpl to);
}
