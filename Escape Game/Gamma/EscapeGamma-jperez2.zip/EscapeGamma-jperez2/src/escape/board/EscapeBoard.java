package escape.board;

import java.util.Map;

import escape.coordinate.Coordinate;
import escape.coordinate.EscapeCoordinateImpl;
import escape.coordinate.SquareCoordinate;
import escape.observer.GameObserver;
import escape.pathFinding.PathFindingImpl;
import escape.piece.EscapePiece;
import escape.piece.EscapePieceImpl;
import escape.rule.Rule.RuleID;

public interface EscapeBoard<C extends Coordinate> 
{
	/**
	 * This function gets the max X value of the board
	 */
	int getXMax();
	/**
	 * This function gets the max Y value of the board
	 */
	int getYMax();
	/**
	 * This method is meant to set the player1 piece 
	 * count from the game builder
	 * @param player count obtained from builder
	 */
	void setPlayer1Count(int count);
	/**
	 * This method is meant to set the player2 piece 
	 * count from the game builder
	 * @param player count obtained from builder
	 */
	void setPlayer2Count(int count);
	/**
	 * This function takes in a desired coordinate set and returns the location
	 * type that is associated with it.
	 * @param coordinate
	 * @return LocationType
	 */
	LocationType getLocationType(EscapeCoordinateImpl coordinate);
	/**
	 * This function sets the specified coordinate to a specified type.
	 * @param coordinate
	 * @param Locationtype
	 */
	void setLocationType(EscapeCoordinateImpl coordinate, LocationType type);
	void setRules(Map<RuleID, Integer> rules);
	/**
	 * this function gets the associated piece with the location that we are
	 * passing in. This will be helpful for all boards.
	 * @param coordinate
	 * @return EscapePiece
	 */
	EscapePiece getPieceAt(C coordinate);
	/**
	 * This function puts the specified piece at the specified location.
	 * This will be helpful for all boards.
	 * @param piece
	 * @param coord
	 */
	void putPieceAt(EscapePiece piece, EscapeCoordinateImpl coord);
	/**
	 * Make the move in the current game.
	 * @param from starting location
	 * @param to ending location
	 * @return true if the move was legal, false otherwise
	 */
	boolean move(EscapeCoordinateImpl from, EscapeCoordinateImpl to);
	/**
	 * Add an observer to this manager. Whever the move() method returns
	 * false, the observer will be notified with a message indication the
	 * problem.
	 * @param observer
	 * @return the observer
	 */
	GameObserver addObserver(GameObserver o);
	/**
	 * Remove an observer from this manager. The observer will no longer
	 * receive notifications from this game manager.
	 * @param observer
	 * @return the observer that was removed or null if it had not previously
	 *     been registered
	 */
	GameObserver removeObserver(GameObserver o);
	/**
     * Sends a message to the game
     * @param message
     */
	void notifyObservers(String message);
	/**
	 * This method runs the path finding algorithm if a piece has certain attributes.
	 * If the return isn't null then we know that the move is possible and we should
	 * place our piece at the correct location. This is also where the players counts
	 * will be decremented.  
	 * @param p PathFindingImpl to call the finding algorithm with
	 * @param piece
	 * @param from
	 * @param to
	 * @return
	 */
	boolean isThereAPath(PathFindingImpl p, EscapePieceImpl piece, EscapeCoordinateImpl from, EscapeCoordinateImpl to);
	/**
	 * This method is to delegate the false conditions from the main check. 
	 * It goes through and checks to see if there are certain false board conditions.
	 * @param to
	 * @param from
	 * @param whichPiece
	 * @return true if there is a false condition, false otherwise
	 */
	boolean preReqFalseConditions(EscapeCoordinateImpl to, EscapeCoordinateImpl from, EscapePiece whichPiece);
	/**
	 * This function checks to see if either source or target is null
	 * @param from
	 * @param to
	 * @return true if coordinates are null
	 */
	boolean nullCoordinateCheck(EscapeCoordinateImpl from, EscapeCoordinateImpl to);
	/**
	 * This function checks to make sure that it is the right players turn and that
	 * we actually have a player to move
	 * @param from
	 * @param whichPiece
	 * @return true if the source is null or if its not the right players turn
	 */
	boolean playerCheck(EscapeCoordinateImpl from, EscapePiece whichPiece);
	/**
	 * This method is intended to check to see if either set of coordinates are out of
	 * bounds from the top end, when the board is not infinite.
	 * @param from
	 * @param to
	 * @return true if the coordinate is out of bounds
	 */
	boolean maxBoundChecker(EscapeCoordinateImpl from, EscapeCoordinateImpl to);
	/**
	 * This method is intended to check to see if either set of coordinates are out of
	 * bounds from the bottom end, when the board is not infinite.
	 * @param from
	 * @param to
	 * @return true if the coordinate is out of bounds
	 */
	boolean minBoundChecker(EscapeCoordinateImpl from, EscapeCoordinateImpl to);
	/**
	 * This method checks to see if target has a player
	 * @param to
	 * @param whichPiece
	 * @return true if the target does have a player
	 */
	boolean landingOnPlayerCheck(EscapeCoordinateImpl to, EscapePiece whichPiece);
	/**
	 * This function checks to see if the target is a block
	 * @param to
	 * @return true if the target is a block location
	 */
	boolean blockCheck(EscapeCoordinateImpl to);
	/**
	 * This method checks to see if the location is of type exit, and if it 
	 * is then we remove the piece and toggle the player. In addition,
	 * if the piece is not an exit, then we are to put the piece at the 
	 * target location.
	 * @param locationType
	 * @param whichPiece
	 * @param to
	 * @param from
	 */
	void exitLocOppoPlayerMove(LocationType locationType, EscapePiece whichPiece, EscapeCoordinateImpl to, EscapeCoordinateImpl from);
	/**
	 * This function operates very similar to the false conditions where we check 
	 * what attributes are valid to run the path finder on.
	 * @param casterPiece
	 * @param to
	 * @param from
	 * @return true if we want to run the path finder, and false otherwise.
	 */
	boolean pathFindingMoves(EscapePieceImpl casterPiece, EscapeCoordinateImpl to, EscapeCoordinateImpl from);
	/**
	 * This method determines what pieces don't need to use pathFinding for their move
	 * @param casterPiece
	 * @param to
	 * @param from
	 * @return true if we dont need pathFinding, false otherwise
	 */
	boolean nonPathFindingMoves(EscapePieceImpl casterPiece, EscapeCoordinateImpl to, EscapeCoordinateImpl from);
	/**
	 * This method checks to see if the player count is less than or equal
	 * to 0 and if it is then the game is over. It also checks the turn limit to see if it has been reached.
	 * If it has then it will check the 2 players scores and determine who is the winner.
	 * @return true if the game is over and false otherwise 
	 */
	boolean gameOverCheck();
	/**
	 * This function gets the piece at the from location and determines what player it is
	 * After this is done, it totals the appropriate players scores and notifies the observers.
	 * @param from
	 */
	void scoreTotaler(EscapeCoordinateImpl from);
}
