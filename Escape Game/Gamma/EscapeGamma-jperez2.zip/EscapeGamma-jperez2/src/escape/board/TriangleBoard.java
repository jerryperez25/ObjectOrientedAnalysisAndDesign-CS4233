package escape.board;

import java.util.ArrayList;
import java.util.HashMap;
import java.util.Map;

import escape.coordinate.EscapeCoordinateImpl;
import escape.coordinate.TriangleCoord;
import escape.exception.EscapeException;
import escape.observer.GameObserver;
import escape.pathFinding.PathFindingImpl;
import escape.piece.EscapePiece;
import escape.piece.EscapePieceImpl;
import escape.piece.Player;
import escape.piece.EscapePiece.MovementPattern;
import escape.piece.EscapePiece.PieceAttributeID;
import escape.rule.Rule.RuleID;

public class TriangleBoard implements EscapeBoard<EscapeCoordinateImpl> 
{
	private int xMax;
	private int yMax;
	public Map<EscapeCoordinateImpl, LocationType> coordLoc;
	public Map<EscapeCoordinateImpl, EscapePiece> coordPiece;
	public Map<RuleID, Integer> gameRules;
	public ArrayList<GameObserver> observer = new ArrayList<>();
	private boolean player1Turn = true;
	private boolean infiniteBoard = false;
	private int player1Count = 0;
	private int player2Count = 0;
	private int turnCount;
	private boolean gameOver;
	private int []playerScores = {0,0};
	private int gameScore;
	
	public TriangleBoard(int xMax, int yMax)
	{
		this.xMax = xMax;
		this.yMax = yMax;
		coordLoc = new HashMap<>();
		coordPiece = new HashMap<>();
		gameRules = new HashMap<>();
		gameOver = false;
		gameScore = 0;
		
	}
	//This constructor is used for infinite boards
	public TriangleBoard()
	{
		this.infiniteBoard = true;
		coordLoc = new HashMap<>();
		coordPiece = new HashMap<>();
		gameRules = new HashMap<>();
		gameOver = false;
		gameScore = 0;
	}
	/**
	 * This function gets the max X value of the board
	 */
	@Override
	public int getXMax() 
	{
		return this.xMax;
	}
	/**
	 * This function gets the max Y value of the board
	 */
	@Override
	public int getYMax() 
	{
		return this.yMax;
	}
	/**
	 * This method is meant to set the player1 piece 
	 * count from the game builder
	 * @param player count obtained from builder
	 */
	public void setPlayer1Count(int count)
	{
		this.player1Count = count;
	}
	/**
	 * This method is intended to get the player 1 piece count
	 * @return player1 piece count
	 */
	public int getPlayer1Count()
	{
		return this.player1Count;
	}
	/**
	 * This method is meant to set the player2 piece 
	 * count from the game builder
	 * @param player count obtained from builder
	 */
	public void setPlayer2Count(int count)
	{
		this.player2Count = count;
	}
	/**
	 * This function obtains the number of pieces from the 
	 * @return the number of player 2 pieces
	 */
	public int getPlayer2Count()
	{
		return this.player2Count;
	}
	/**
	 * This function sets global variables to have the values that are obtained from the builder
	 * @param map of rules with values
	 */
	public void setRules(Map<RuleID, Integer>rules)
	{
		this.gameRules = rules;
		this.turnCount = gameRules.get(RuleID.TURN_LIMIT);
		this.gameScore = gameRules.get(RuleID.SCORE);
	}
	/**
	 * This function gets how many turns there are in said game
	 * @return turn value
	 */
	public int getTurnCount()
	{
		return this.turnCount;
	}
	/**
	 * This function gets the games score
	 * @return egc game score
	 */
	public int getGameScore()
	{
		return this.gameScore;
	}
	/**
	 * This function gets Player 1's score
	 * @return player 1's score
	 */
	public int getPlayerOneScore()
	{
		return this.playerScores[0];
	}
	/**
	 * This function gets Player 2's score
	 * @return player 2's score
	 */
	public int getPlayerTwoScore()
	{
		return this.playerScores[1];
	}
	/**
	 * This function returns the state of trinangle board
	 * and whether or not it is infinite
	 * @return the state of board (infinite or not)
	 */
	public boolean isItInfinite()
	{
		return this.infiniteBoard;
	}

	/**
	 * This function takes in a desired coordinate set and returns the location
	 * type that is associated with it.
	 * @param coordinate
	 * @return LocationType
	 */
	@Override
	public LocationType getLocationType(EscapeCoordinateImpl coordinate) 
	{
		return this.coordLoc.get(coordinate);
	}

	/**
	 * This function sets the specified coordinate to a specified type.
	 * @param coordinate
	 * @param Locationtype
	 */
	@Override
	public void setLocationType(EscapeCoordinateImpl coordinate, LocationType type) 
	{
		this.coordLoc.put(coordinate, type);
	}

	/**
	 * This function gets the associated piece with the location that we are
	 * passing in. It is important to note that we can only get pieces for valid
	 * coordinates. Despite the fact that a manager can make whatever coordinate. 
	 * @param coordinate
	 * @return EscapePiece
	 */
	@Override
	public EscapePiece getPieceAt(EscapeCoordinateImpl coordinate) 
	{
		if(infiniteBoard == true)
		{
			//if this is an infinite board then we get the piece wherever it is placed
			return coordPiece.get(coordinate);
		}
		//we check if coordinates x and y is less than 1 because that is the first coordinate in the squareGame
		if (coordinate == null || coordinate.getX() > this.getXMax()|| coordinate.getY() > this.getYMax() || coordinate.getX() < 1 || coordinate.getY() < 1)
		{
			return null;
		}
		return coordPiece.get(coordinate);
	}

	/**
	 * This function puts the specified piece at the specified location.
	 * This will be helpful for all boards.
	 * @param piece
	 * @param coord
	 */
	@Override
	public void putPieceAt(EscapePiece piece, EscapeCoordinateImpl coord) 
	{
		this.coordPiece.put(coord, piece);
	}
	/**
	 * Add an observer to this manager. Whever the move() method returns
	 * false, the observer will be notified with a message indication the
	 * problem.
	 * @param observer
	 * @return the observer
	 */
	public GameObserver addObserver(GameObserver obs)
	{
		this.observer.add(obs);
		return obs;
	}
	/**
	 * Remove an observer from this manager. The observer will no longer
	 * receive notifications from this game manager.
	 * @param observer
	 * @return the observer that was removed or null if it had not previously
	 *     been registered
	 */
	public GameObserver removeObserver(GameObserver obs)
	{
		this.observer.remove(obs);
		return obs;
	}
	/**
     * Sends a message to the game
     * @param message
     */
	public void notifyObservers(String message)
	{
		if(!this.observer.isEmpty())
		{
			this.observer.forEach((obs) -> obs.notify(message));
		}
	}

	/**
	 * Make the move in the current game.
	 * @param from starting location
	 * @param to ending location
	 * @return true if the move was legal, false otherwise
	 */
	@Override
	public boolean move(EscapeCoordinateImpl from, EscapeCoordinateImpl to) 
	{	
		
		EscapePiece whichPiece = this.getPieceAt(from);
		EscapePieceImpl casterPiece = (EscapePieceImpl) whichPiece;
		PathFindingImpl newPath = new PathFindingImpl(this);
		
		//System.out.println(gameRules.get(RuleID.SCORE));
		
		//System.out.println("Player 1 has: " + this.player1Count + " pieces.");
		//System.out.println("Player 2 has: " + this.player2Count + " pieces.");
		if(gameOver == false)
		{
			if(preReqFalseConditions(to, from, whichPiece))
			{
				this.notifyObservers("The move fails a pre-requisite check.");
				return false;
			}
			
			if(nonPathFindingMoves(casterPiece, to, from))
			{
				//if we land on exit
				exitLocOppoPlayerMove(this.getLocationType(to), whichPiece, to, from);
				return true;
			}
			
			if(pathFindingMoves(casterPiece, to, from))
			{
				
				if(isThereAPath(newPath, casterPiece, from, to) && from.DistanceTo(to) <= casterPiece.getMoveVal())
				{
					return true; //if there is, return true
				}
				else
				{
					this.notifyObservers("There is not a valid path to the specified target.");
					return false; //if not then return false
				}
			}
			//System.out.println("Not yet implemented... Remember this is a catch-all");
			return false;
		}
		else
		{
			//game is over
			this.notifyObservers("The game is over. You must create a new game in order to make a move.");
			return false;
			//throw new EscapeException("The game is over, please create a new game to start over.");
		}
		
	}
	// -------------HELPER FUNCTIONS BELOW---------------------
	
	/**
	 * This method runs the path finding algorithm if a piece has certain attributes.
	 * If the return isn't null then we know that the move is possible and we should
	 * place our piece at the correct location. This is also where the players counts
	 * will be decremented.  
	 * @param p PathFindingImpl to call the finding algorithm with
	 * @param piece
	 * @param from
	 * @param to
	 * @return
	 */
	public boolean isThereAPath(PathFindingImpl p, EscapePieceImpl piece, EscapeCoordinateImpl from, EscapeCoordinateImpl to)
	{
		if(p.findPath(piece, from, to) != null )
		{
			exitLocOppoPlayerMove(this.getLocationType(to), piece, to, from);
			return true;
		}
		else
		{
			return false;
		}
	}
	/**
	 * This method is to delegate the false conditions from the main check. 
	 * It goes through and checks to see if there are certain false board conditions.
	 * @param to
	 * @param from
	 * @param whichPiece
	 * @return true if there is a false condition, false otherwise
	 */
	public boolean preReqFalseConditions(EscapeCoordinateImpl to, EscapeCoordinateImpl from, EscapePiece whichPiece)
	{
		if(nullCoordinateCheck(from, to)
				||playerCheck(from, whichPiece)
				||(from.getX() == to.getX() && from.getY() == to.getY())
				||maxBoundChecker(from, to)
				||minBoundChecker(from, to)
				||landingOnPlayerCheck(to, whichPiece)
				||blockCheck(to))
		{
			return true;
		}
		
		return false; // none of the false conditions are met
	}
	/**
	 * This function checks to make sure that it is the right players turn and that
	 * we actually have a player to move
	 * @param from
	 * @param whichPiece
	 * @return true if the source is null or if its not the right players turn
	 */
	public boolean playerCheck(EscapeCoordinateImpl from, EscapePiece whichPiece)
	{
		return (this.coordPiece.get(from) == null) || ((whichPiece.getPlayer() == Player.PLAYER1) != player1Turn);
	}
	/**
	 * This function checks to see if either source or target is null
	 * @param from
	 * @param to
	 * @return true if coordinates are null
	 */
	public boolean nullCoordinateCheck(EscapeCoordinateImpl from, EscapeCoordinateImpl to)
	{
		return (from == null || to == null);
	}
	/**
	 * This method is intended to check to see if either set of coordinates are out of
	 * bounds from the top end, when the board is not infinite.
	 * @param from
	 * @param to
	 * @return true if the coordinate is out of bounds
	 */
	public boolean maxBoundChecker(EscapeCoordinateImpl from, EscapeCoordinateImpl to)
	{
		return (isItInfinite() == false) && (from.getX() > this.xMax || from.getY() > this.yMax || to.getX() > this.xMax || to.getY() > this.yMax);
	}
	/**
	 * This method is intended to check to see if either set of coordinates are out of
	 * bounds from the bottom end, when the board is not infinite.
	 * @param from
	 * @param to
	 * @return true if the coordinate is out of bounds
	 */
	public boolean minBoundChecker(EscapeCoordinateImpl from, EscapeCoordinateImpl to)
	{
		return isItInfinite() == false && (from.getX() < 1 || from.getY() < 1 || to.getX() < 1 || to.getY() < 1);
	}
	/**
	 * This method checks to see if target has a player
	 * @param to
	 * @param whichPiece
	 * @return true if the target does have a player
	 */
	public boolean landingOnPlayerCheck(EscapeCoordinateImpl to, EscapePiece whichPiece)
	{
		return ((this.getPieceAt(to)!= null) && this.getPieceAt(to).getPlayer() == whichPiece.getPlayer()) 
				|| ((this.getPieceAt(to)!= null) && this.getPieceAt(to).getPlayer() != whichPiece.getPlayer());
	}
	/**
	 * This function checks to see if the target is a block
	 * @param to
	 * @return true if the target is a block location
	 */
	public boolean blockCheck(EscapeCoordinateImpl to)
	{
		return (this.getLocationType(to) != null && this.getLocationType(to) == LocationType.BLOCK);
	}
	
	/**
	 * This method checks to see if the location is of type exit, and if it 
	 * is then we remove the piece and toggle the player. In addition,
	 * if the piece is not an exit, then we are to put the piece at the 
	 * target location.
	 * @param locationType
	 * @param whichPiece
	 * @param to
	 * @param from
	 */
	public void exitLocOppoPlayerMove(LocationType locationType, EscapePiece whichPiece, EscapeCoordinateImpl to, EscapeCoordinateImpl from)
	{
		if(player1Turn == false)
		{
			turnCount--;
			gameOverCheck();
		}
		if ((this.getLocationType(to)== LocationType.EXIT)) 
		{
			scoreTotaler(from);
			this.coordPiece.remove(from);
			player1Turn = !player1Turn;
			
		}
		else
		{
			//if we land on valid piece or opposing players piece
			this.putPieceAt(whichPiece, to);
			this.putPieceAt(null, from); //removes the piece from
			player1Turn = !player1Turn;
		}
		
	}
	/**
	 * This function operates very similar to the false conditions where we check 
	 * what attributes are valid to run the path finder on.
	 * @param casterPiece
	 * @param to
	 * @param from
	 * @return true if we want to run the path finder, and false otherwise.
	 */
	public boolean pathFindingMoves(EscapePieceImpl casterPiece, EscapeCoordinateImpl to, EscapeCoordinateImpl from)
	{
		if(casterPiece.hasAttribute(PieceAttributeID.DISTANCE) 
				&& casterPiece.getMovementPattern() == MovementPattern.OMNI
				|| casterPiece.hasAttribute(PieceAttributeID.JUMP)
				|| casterPiece.hasAttribute(PieceAttributeID.UNBLOCK))
		{
			return true;
		}
		return false;
	}
	/**
	 * This method determines what pieces don't need to use pathFinding for their move
	 * @param casterPiece
	 * @param to
	 * @param from
	 * @return true if we dont need pathFinding, false otherwise
	 */
	public boolean nonPathFindingMoves(EscapePieceImpl casterPiece, EscapeCoordinateImpl to, EscapeCoordinateImpl from)
	{
		if(casterPiece.hasAttribute(PieceAttributeID.FLY) && 
					casterPiece.getMovementPattern() == MovementPattern.OMNI
					&& from.DistanceTo(to) <= casterPiece.getMoveVal()
					|| casterPiece.hasAttribute(PieceAttributeID.FLY) 
					&& casterPiece.getMovementPattern() == MovementPattern.LINEAR
							&& from.DistanceTo(to) <= casterPiece.getMoveVal() && from.isLinearTo(to) )
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	/**
	 * This method checks to see if the player count is less than or equal
	 * to 0 and if it is then the game is over. It also checks the turn limit to see if it has been reached.
	 * If it has then it will check the 2 players scores and determine who is the winner.
	 * @return true if the game is over and false otherwise 
	 */
	public boolean gameOverCheck()
	{
		if(this.player1Count == 0 || this.player2Count == 0)
		{
			if(this.player1Count == 0)
			{
		
				//System.out.println("Player 1 is the loser by piece count");
				this.notifyObservers("Player2 Wins By Opposing Player running out of pieces to move.");
			}
			else
			{
				//System.out.println("Player 2 is the loser by piece count");
				this.notifyObservers("Player1 Wins By Opposing Player running out of pieces to move.");
			}
			gameOver = true;
			return true;
		}
		if(turnCount == 0)
		{
			gameOver = true;
			if(this.getPlayerOneScore() > this.getPlayerTwoScore())
			{
				//System.out.println("Player1 Wins For Score");
				this.notifyObservers("Player1 Wins By Score");
			}
			if(this.getPlayerOneScore() < this.getPlayerTwoScore())
			{
				//System.out.println("Player2 Wins For Score");
				this.notifyObservers("Player2 Wins By Score");
			}
			if(this.getPlayerOneScore() == this.getPlayerTwoScore())
			{
				//System.out.println("The game is a draw by score");
				this.notifyObservers("The game is a draw by score");
			}
		}
		if (gameOver)
		{
			return true;
		}
		return false;
	}
	/**
	 * This function gets the piece at the from location and determines what player it is
	 * After this is done, it totals the appropriate players scores and notifies the observers.
	 * @param from
	 */
	public void scoreTotaler(EscapeCoordinateImpl from)
	{
		if(this.getPieceAt(from).getPlayer() == Player.PLAYER1)
		{
			this.player1Count--;
			EscapePieceImpl playerValue = (EscapePieceImpl) this.getPieceAt(from); 
			playerScores[0] = playerScores[0] + playerValue.getPieceVal();
			if(playerScores[0] >= this.gameScore)
			{
				//System.out.println("Player1 Wins By Exceeding GameScore");
				this.notifyObservers("Player1 Wins By Exceeding GameScore");
				gameOver = true;
				
			}
		}
		if(this.getPieceAt(from).getPlayer() == Player.PLAYER2)
		{
			this.player2Count--;
			EscapePieceImpl playerValue = (EscapePieceImpl) this.getPieceAt(from);
			playerScores[1] = playerScores[1] + playerValue.getPieceVal();
			if(playerScores[1] >= this.gameScore)
			{
				//System.out.println("Player2 Wins By Exceeding GameScore");
				this.notifyObservers("Player2 Wins By Exceeding GameScore");
				gameOver = true;
				
			}
		}
	}

}
