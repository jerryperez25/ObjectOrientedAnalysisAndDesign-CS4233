package escape.coordinate;

import escape.coordinate.EscapeCoordinateImpl.CompassRose;

public interface EscapeCoordinateImpl extends Coordinate 
{
	/**
	 * Obtains the X coordinate
	 */
	public int getX();
	/**
	 * Obtains the Y coordinate
	 */
	public int getY();
	public int hashCode();
	public boolean equals(Object o);
	//public boolean isLinear(Coordinate to);
	/**
	 * This function gets all of the neighbors of the coordinate that calls it 
	 * @return an array of neighbors 
	 */
	public EscapeCoordinateImpl[] getNeighbors();
	/**
	 * This function is called upon by a coordinate and takes in a direction
	 * to see what neighbors are at that direction.
	 * @param direction
	 * @return coordinate
	 */
	public EscapeCoordinateImpl getNeighborAt(CompassRose direction);
	static enum CompassRose {NORTH, EAST, SOUTH, WEST, NORTHEAST, NORTHWEST, SOUTHEAST, SOUTHWEST, NONE};
	/**
	 * This function uses a coordinate that calls it and a target and determines
	 * where the target is in relation to the source.
	 * @param target
	 * @return CompassRose direction
	 */
	public CompassRose getDirectionTo(EscapeCoordinateImpl target);
	/**
	 * This function uses the coordinate that calls it and a target
	 * and determines if the target is linear to the source.
	 * @param target
	 * @return false if not linear and true if it is linear
	 */
	public boolean isLinearTo(EscapeCoordinateImpl target);
	/**
	 * This function uses the coordinate that calls it and a target
	 * and determines if the target is orthogonal to the source.
	 * @param target
	 * @return true if orthogonal and false if else
	 */
	public boolean isOrthagonalTo(EscapeCoordinateImpl target);
	/**
	 * This function uses the coordinate that calls it and a target
	 * and determines if the target is diagonal to the source.
	 * @param target
	 * @return true if diagonal and false if else
	 */
	public boolean isDiagonalTo(EscapeCoordinateImpl target);
	/**
	 * This function uses the coordinate that calls it and a target
	 * and determines if the target is omni to the source.
	 * @param target
	 * @return boolean if it is omni and false if not
	 */
	public boolean isOmniTo(EscapeCoordinateImpl target);
}
