package escape.coordinate;

import java.util.Objects;

import escape.coordinate.EscapeCoordinateImpl.CompassRose;
import escape.exception.EscapeException;

public class TriangleCoord<C extends Coordinate> implements EscapeCoordinateImpl
{
	private int x;
	private int y;
	
	public TriangleCoord(int x, int y)
	{
		this.x = x;
		this.y = y;
	}

	/**
	 * This function uses a coordinate to determine the distance to the
	 * location given to it as the argument.
	 * @param Coordinate
	 */
	@Override
	public int DistanceTo(Coordinate c) 
	{
		//if a different type then 
		Throwable newThrow = new Throwable("Invalid Coordinate Type");
				
			if (!(c instanceof TriangleCoord))
			{
				throw new EscapeException("Coordinate is not appropriate type", newThrow);
			}
			
		TriangleCoord caster = (TriangleCoord) c;
		//perform a check here if the coordinate is the right type
		int deltaX = Math.abs(this.x - caster.getX());
		int deltaY = Math.abs(this.y - caster.getY());
		
		if(this.getY() == caster.getY())
		{
			//source and target in the same column
			if(upChecker(this.getX(), this.getY()))
			{
				//source is facing upward, plus 0 it
				if(upChecker(caster.getX(), caster.getY()))
				{
					//target is upward facing, plus 0 it
					int sourceTotaller = this.getX() + this.getY() + 0;
					int targetTotaller = caster.getX() + caster.getY() + 0;
					return deltaX + deltaY + Math.abs(sourceTotaller - targetTotaller); 
				}
				else
				{
					//target is downward facing
					int sourceTotaller = this.getX() + this.getY() + 0;
					int targetTotaller = caster.getX() + caster.getY() + 1;
					return deltaX + deltaY + Math.abs(sourceTotaller - targetTotaller);
				}
			}
			else
			{
				//source is facing downward, plus 1 it
				if(upChecker(caster.getX(), caster.getY()))
				{
					//target is upward facing, plus 0 it
					int sourceTotaller = this.getX() + this.getY() + 1;
					int targetTotaller = caster.getX() + caster.getY() + 0;
					return deltaX + deltaY + Math.abs(sourceTotaller - targetTotaller); 
				}
				else
				{
					//target is downward facing
					int sourceTotaller = this.getX() + this.getY() + 1;
					int targetTotaller = caster.getX() + caster.getY() + 1;
					return deltaX + deltaY + Math.abs(sourceTotaller - targetTotaller);
				}
			}
		}
		if(deltaY<=deltaX)
		{
			if (this.x < caster.getX())
			{
				//we look up
				if (upChecker(this.getX(), this.getY()))
				{
					//source is upward triangle
					if(upChecker(caster.getX(), caster.getY()))
					{
						//target is up
						return 2*deltaX;
					}
					else
					{
						//target is down
						return 2*deltaX+1;
					}
				}
				else
				{
					//source is downward triangle
					if(upChecker(caster.getX(), caster.getY()))
					{
						//target is up
						return (2*deltaX)-1;
					}
					else
					{
						//target is down
						return 2* deltaX;
					}
				}
				
			}
			else
			{
				//we look down
				if (upChecker(this.getX(), this.getY()))
				{
					//source is upward triangle
					if(upChecker(caster.getX(), caster.getY()))
					{
						//target is up
						return 2*deltaX;
					}
					else
					{
						//target is down
						return (2*deltaX)-1;
					}
				}
				else
				{
					//source is downward triangle
					if(upChecker(caster.getX(), caster.getY()))
					{
						//target is up
						return (2*deltaX)+1;
					}
					else
					{
						//target is down
						return 2*deltaX;
					}
				}
			}
		}
		else
		{
			return deltaX + deltaY;
		}
		
	}
	/**
	 * This function checks to see if the triangle coordinate that calls it is 
	 * upward facing or downward facing.
	 * @param x
	 * @param y
	 * @return true if the triangle is upward facing, false if downward
	 */
	public boolean upChecker(int x, int y)
	{
		if((x%2 == 0 && y%2 != 0) || (x%2 != 0 && y%2 == 0))
		{
			return true;
		}
		else
		{
			return false;
		}
	}
	/**
	 * Obtains the X coordinate
	 */
	@Override
	public int getX() 
	{
		return this.x;
	}
	/**
	 * Obtains the Y coordinate
	 */
	@Override
	public int getY() 
	{
		return this.y;
	}
	
	/**
	 * This function facilitates hashing in maps.
	 */
	@Override
	public int hashCode()
	{
		return Objects.hash(x,y);
	}
	/**
	 * this function is overridden and checks to make sure the give object
	 * matches the instance that we would like to check
	 */
	@Override
	public boolean equals(Object o)
	{
		if ((o instanceof TriangleCoord))
		{
			TriangleCoord newOne = (TriangleCoord) o;
			return newOne.x == this.x && newOne.y == this.y;
		}
		return false;
		
	}
	/**
	 * This function gets all of the neighbors of the coordinate that calls it 
	 * @return an array of neighbors 
	 */
	public EscapeCoordinateImpl[] getNeighbors()
	{		
		if(upChecker(this.x, this.y) == true)
		{
			//source is facing up
			EscapeCoordinateImpl neighborArray[] = {new TriangleCoord(this.x-1, this.y), 
					new TriangleCoord(this.x, this.y-1),
					new TriangleCoord(this.x, this.y+1)}; 
			return neighborArray;
		}
		else
		{
			//source is facing down
			EscapeCoordinateImpl neighborArray[] = { new TriangleCoord(this.x, this.y-1),
					new TriangleCoord(this.x, this.y+1),
					new TriangleCoord(this.x+1, this.y)};
			return neighborArray;
		}
	}
	/**
	 * This function uses a coordinate that calls it and a target and determines
	 * where the target is in relation to the source.
	 * @param target
	 * @return CompassRose direction
	 */
	public CompassRose getDirectionTo(EscapeCoordinateImpl target)
	{
		int deltaX = Math.abs(this.x - target.getX());
		int deltaY = Math.abs(this.y - target.getY());
		
		if(this.getY() == target.getY())
		{
			return CompassRose.NONE;
		}
		if (upChecker(this.getX(), this.getY()))
		{
			//source is facing up
			if(this.getX() > target.getX())
			{
				//source X is greater than target X 
				return CompassRose.NONE;
			}
			if(upChecker(target.getX(), target.getY()))
			{
				//target is facing up
				if(this.getX() - this.getY() ==target.getX() - target.getY() && this.getX() < target.getX())
				{
					return CompassRose.NORTHEAST;
				}
				if(deltaX == deltaY && this.getX() < target.getX() && this.getY() > target.getY())
				{
					return CompassRose.NORTHWEST;
				}
				
				
			}
			else
			{
				//target is facing down
				if(deltaX+1 == deltaY && this.getX() < target.getX() && this.getY()< target.getY())
				{
					return CompassRose.NORTHEAST;
				}
				if(deltaX+1 == deltaY && this.getX() < target.getX() && this.getY()> target.getY())
				{
					return CompassRose.NORTHWEST;
				}
			}
		}
		else
		{
			//source is facing down
			if(this.getX() < target.getX())
			{
				return CompassRose.NONE;
			}
			if(upChecker(target.getX(), target.getY()))
			{
				//target is facing up
				if(deltaX+1 == deltaY && this.getX() > target.getX() && this.getY()> target.getY())
				{
					return CompassRose.SOUTHWEST;
				}
				if(deltaX+1 == deltaY && this.getX() > target.getX() && this.getY()< target.getY())
				{
					return CompassRose.SOUTHEAST;
				}
			}
			else
			{
				//target is facing down
				if(deltaX == deltaY && this.getX() > target.getX() && this.getY()< target.getY())
				{
					return CompassRose.SOUTHEAST;
				}
				if(this.getX() - this.getY() ==target.getX() - target.getY() && this.getX() > target.getX())
				{
					return CompassRose.SOUTHWEST;
				}
			}
		}
		if(this.getX() == target.getX() && this.getY() < target.getY())
		{
			return CompassRose.EAST;
		}
		if(this.getX() == target.getX() && this.getY() > target.getY())
		{
			return CompassRose.WEST;
		}
		
		return CompassRose.NONE;
	}
	/**
	 * This function uses the coordinate that calls it and a target
	 * and determines if the target is linear to the source.
	 * @param target
	 * @return false if not linear and true if it is linear
	 */
	public boolean isLinearTo(EscapeCoordinateImpl target) 
	{
		if(this.getDirectionTo(target) == CompassRose.NONE)
		{
			return false;
		}
		else
		{
			return true;
		}
	}
	/**
	 * This function uses the coordinate that calls it and a target
	 * and determines if the target is orthogonal to the source.
	 * @param target
	 * @return true if orthogonal and false if else
	 */
	public boolean isOrthagonalTo(EscapeCoordinateImpl target)
	{
		return false; 
	}
	/**
	 * This function uses the coordinate that calls it and a target
	 * and determines if the target is diagonal to the source.
	 * @param target
	 * @return true if diagonal and false if else
	 */
	public boolean isDiagonalTo(EscapeCoordinateImpl target)
	{
		return false; 
	}
	/**
	 * This function uses the coordinate that calls it and a target
	 * and determines if the target is omni to the source.
	 * @param target
	 * @return boolean if it is omni and false if not
	 */
	public boolean isOmniTo(EscapeCoordinateImpl target)
	{
		if(this.getDirectionTo(target) != CompassRose.NONE)
		{
			return true;
		}
		else
		{
			return false;
		}
	}

	/**
	 * This function is called upon by a coordinate and takes in a direction
	 * to see what neighbors are at that direction.
	 * @param direction
	 * @return coordinate
	 */
	@Override
	public EscapeCoordinateImpl getNeighborAt(CompassRose direction) 
	{
		for(EscapeCoordinateImpl c : this.getNeighbors())
		{
			//System.out.println("X Coord: " + c.getX() + " Y Coord: " + c.getY());
			//System.out.println(c.getDirectionTo(this));
			if(this.getDirectionTo(c) == direction)
			{
				return new TriangleCoord(c.getX(),c.getY());
			}
		}
		return null;
	}

}
