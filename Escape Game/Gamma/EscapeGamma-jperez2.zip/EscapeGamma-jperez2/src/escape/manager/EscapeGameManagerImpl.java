package escape.manager;

import java.util.Map;

import escape.board.EscapeBoard;
import escape.board.LocationType;
import escape.board.SquareBoard;
import escape.coordinate.Coordinate;
import escape.coordinate.CoordinateFactory;
import escape.coordinate.EscapeCoordinateImpl;
import escape.coordinate.Coordinate.CoordinateType;
import escape.exception.EscapeException;
import escape.initializers.LocationInitializer;
import escape.observer.GameObserver;
import escape.piece.EscapePiece;
import escape.piece.EscapePieceImpl;
import escape.piece.PieceTypeDescriptor;
import escape.piece.Player;
import escape.piece.EscapePiece.PieceName;
import escape.rule.RuleDescriptor;
import escape.rule.Rule.RuleID;

public class EscapeGameManagerImpl <C> implements EscapeGameManager<EscapeCoordinateImpl>
{
	private EscapeBoard board;
	private CoordinateType coordinateType;
	private CoordinateFactory factory;
	
	
	public EscapeGameManagerImpl(CoordinateType coordinateType)
	{
		this.coordinateType = coordinateType;
		this.factory = new CoordinateFactory();
	
	}
	
	/**
	 * this function populates the board with the information necessary
	 * @param board of type SquareBoard
	 */
	public void setBoard(EscapeBoard board) //We need to find a way to make this generic
	{
		this.board = board;
	}
	/**
	 * this function returns the board that we are using
	 * @return SquareBoard
	 */
	public EscapeBoard getBoard() //We need to find a way to make this generic
	{
		return this.board;
	}
	/**
	 * this function returns the coordinate factory
	 * @return Coordinate that is created by the coordinate factory
	 */
	public CoordinateFactory getFactory()
	{
		return this.factory;
	}
	/**
	 * This function sets global variables to have the values that are obtained from the builder
	 * @param map of rules with values
	 */
	public void setRules(Map<RuleID, Integer> rules)
	{
		board.setRules(rules);
	}

	/**
	 * This function puts the specified piece at the specified location.
	 * This will be helpful for all boards.
	 * @param piece
	 * @param coord
	 */
	
	@Override
	public EscapePiece getPieceAt(EscapeCoordinateImpl coordinate) 
	{
		
		return board.getPieceAt(coordinate);
	}

	/**
	 * Returns a coordinate of the appropriate type. If the coordinate cannot be
	 * created, then null is returned and the status message is set appropriately.
	 * @param x the x component
	 * @param y the y component
	 * @return the coordinate or null if the coordinate cannot be implemented
	 */
	
	@Override
	public EscapeCoordinateImpl makeCoordinate(int x, int y) 
	{
		return factory.makeCoordinate(coordinateType, x, y);
		
	}
	/**
	 * Make the move in the current game.
	 * @param from starting location
	 * @param to ending location
	 * @return true if the move was legal, false otherwise
	 */
	@Override
	public boolean move(EscapeCoordinateImpl from, EscapeCoordinateImpl to) 
	{
		return this.board.move(from, to);
	}
	/**
	 * Add an observer to this manager. Whever the move() method returns
	 * false, the observer will be notified with a message indication the
	 * problem.
	 * @param observer
	 * @return the observer
	 */
	public GameObserver addObserver(GameObserver o)
	{
		return this.board.addObserver(o);
	}
	/**
	 * Remove an observer from this manager. The observer will no longer
	 * receive notifications from this game manager.
	 * @param observer
	 * @return the observer that was removed or null if it had not previously
	 *     been registered
	 */
	public GameObserver removeObserver(GameObserver o)
	{
		return this.board.removeObserver(o);
	}

	
	


}
