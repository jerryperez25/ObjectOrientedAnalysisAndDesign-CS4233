/*******************************************************************************
 * This files was developed for CS4233: Object-Oriented Analysis & Design.
 * The course was taken at Worcester Polytechnic Institute.
 *
 * All rights reserved. This program and the accompanying materials
 * are made available under the terms of the Eclipse Public License v1.0
 * which accompanies this distribution, and is available at
 * http://www.eclipse.org/legal/epl-v10.html
 * 
 * Copyright ©2016 Gary F. Pollice
 *******************************************************************************/

package escape;

import static org.junit.Assert.assertEquals;
import static org.junit.Assert.assertFalse;
import static org.junit.Assert.assertNotNull;
import static org.junit.Assert.assertNull;
import static org.junit.Assert.assertTrue;
import static org.junit.jupiter.api.Assertions.assertThrows;

import org.junit.jupiter.api.BeforeAll;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import coordinate.Coordinate;
import coordinate.Coordinate.CoordinateType;
import coordinate.SquareCoordinate;
import escape.exception.EscapeException;
import manager.EscapeGameManager;
import piece.EscapePiece;
import piece.EscapePieceImpl;
import piece.Player;
import piece.EscapePiece.PieceName;

/**
 * This is a simple test, not really a unit test, to make sure tht the
 * EscapeGameBuilder, in the starting code, is actually working.
 * 
 * @version May 30, 2020
 */
class EscapeAlphaTest
{
	
	private static EscapeGameManager manager;
	
	@BeforeAll
	static void loadGame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest.egc");
		manager = egb.makeGameManager();
		assertNotNull(manager);
	}

	//1
	@Test
	void retrievingXValueFromBuilder() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		assertEquals(25,egb.getGameInitializer().getxMax());
	}
	//2	
	@Test 
	void retrievingYValueFromBuilder() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		assertEquals(20,egb.getGameInitializer().getyMax());
	}
	//3	
	@Test
	void checkMakeGameManagerContents() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		assertNotNull(egb.makeGameManager());
	}
	//4	
	@Test
	void checkGameWhenPlayerHasExitLocation() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/ExceptionBoard.egc");
		assertThrows(EscapeException.class, () -> egb.makeGameManager());
	}
	//5	
	@Test
	void checkSquareGameMakeCoordUsingSquareCoordinate() throws Exception
	{
	
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		EscapeGameManager egm = egb.makeGameManager();
		SquareCoordinate newOne = new SquareCoordinate(4,4);
		assertEquals(newOne, egm.makeCoordinate(4, 4));
	}
	//6
	@Test
	void checkSquareGameMakeCoordUsingManager() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		EscapeGameManager egm = egb.makeGameManager();
		assertNotNull(egm.makeCoordinate(8, 8));
	}
	//7
	@Test
	void getPlayer1SnailAt4_4() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate four_four = new SquareCoordinate(4,4);
		
		
		assertEquals(Player.PLAYER1, egm.getPieceAt(four_four).getPlayer());
		assertEquals(PieceName.SNAIL, egm.getPieceAt(four_four).getName());
	}
	//8
	@Test
	void getPlayer2HorseAt10_12() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		EscapeGameManager egm = egb.makeGameManager();
		
		Coordinate ten_twelve = new SquareCoordinate(10,12);
		
		assertEquals(Player.PLAYER2, egm.getPieceAt(ten_twelve).getPlayer());
		assertEquals(PieceName.HORSE, egm.getPieceAt(ten_twelve).getName());
	}
	//9
	@Test
	void getNullPiece() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/test1.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate one_one = new SquareCoordinate(1,1);
		
		assertNull(egm.getPieceAt(one_one));
	}
	//10
	//Professor Test Case
	@Test
	void horseAt6_2() 
	{
		EscapePiece piece = manager.getPieceAt(manager.makeCoordinate(6, 2));
		assertNotNull(piece);
		assertEquals(PieceName.HORSE, piece.getName());
		assertEquals(Player.PLAYER1, piece.getPlayer());
	}
	//11
	@Test
	void checkGetPieceAtBorderUpperLimit() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate border = egm.makeCoordinate(25,20);
		assertNotNull(egm.getPieceAt(border)); //gets the piece at the border
	}
	//12
	@Test
	void checkGetPieceAtNull() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate nuller = null;
		assertNull(egm.getPieceAt(nuller));
	}
	//13
	@Test
	void checkGetPieceAtNoPiece() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate noPiece = egm.makeCoordinate(3,4); //no piece here
		assertNull(egm.getPieceAt(noPiece));
	}
	//14
	@Test
	void checkGetPieceAtOutOfBoundsX() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(26,20);
		assertNull(egm.getPieceAt(outOfBounds));
	}
	//15
	@Test
	void checkGetPieceAtOutOfBoundsY() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(25,21);
		assertNull(egm.getPieceAt(outOfBounds));
	}
	//16
	@Test
	void checkGetPieceAtOutOfBoundsXAndY() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(26,21);
		assertNull(egm.getPieceAt(outOfBounds));
	}
	//17
	@Test
	void checkGetPieceAtOutOfBounds0_0() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(0,0);
		assertNull(egm.getPieceAt(outOfBounds));
	}
	//18
	@Test
	void checkGetPieceAtOutOfBounds0_1() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(0,1);
		assertNull(egm.getPieceAt(outOfBounds));
	}
	//19
	@Test
	void checkGetPieceAtOutOfBounds1_0() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(1,0);
		assertNull(egm.getPieceAt(outOfBounds));
	}
	//20
	@Test
	void checkGetPieceAtOutOfBoundsNegative() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(-8,-5);
		assertNull(egm.getPieceAt(outOfBounds));
	}
	//21
	@Test
	void distanceFrom0_0To0_1()
	{
		SquareCoordinate set1 = new SquareCoordinate(0,0);
		SquareCoordinate set2 = new SquareCoordinate(0,1);
		assertEquals(1, set1.DistanceTo(set2));	
	}
	//22
	@Test
	void distanceFrom0_0To1_2()
	{
		SquareCoordinate set1 = new SquareCoordinate(0,0);
		SquareCoordinate set2 = new SquareCoordinate(1,2);
		assertEquals(2, set1.DistanceTo(set2));
		
	}
	//23
	@Test
	void distanceFrom5_8To10_20()
	{
		SquareCoordinate set1 = new SquareCoordinate(5,8);
		SquareCoordinate set2 = new SquareCoordinate(10,20);
		assertEquals(12, set1.DistanceTo(set2));
	}
	//24
	@Test
	void distanceFrom10_8To5_2()
	{
		SquareCoordinate set1 = new SquareCoordinate(10,8);
		SquareCoordinate set2 = new SquareCoordinate(5,2);
		assertEquals(6, set1.DistanceTo(set2));
	}
	//25
	@Test
	void distanceFromNeg8_Neg5ToNeg3_Neg1()
	{
		SquareCoordinate set1 = new SquareCoordinate(-8,-5);
		SquareCoordinate set2 = new SquareCoordinate(-3,-1);
		assertEquals(5, set1.DistanceTo(set2));
	}
	//26
	@Test
	void distanceFromValidToNull()
	{
		SquareCoordinate set1 = new SquareCoordinate(10,8);
		SquareCoordinate set2 = null;
		assertThrows(EscapeException.class, ()->set1.DistanceTo(set2));
	}
	//27
	@Test
	void movePieceToBlockLocation() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate three_five = egm.makeCoordinate(3, 5);
		Coordinate six_two = egm.makeCoordinate(6, 2);
		EscapePiece piece = egm.getPieceAt(three_five);
		assertFalse(egm.move(six_two, three_five));
	}
	//28
	@Test
	void moveHorseFrom6_2To5_8() throws Exception
	{	
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate six_two = egm.makeCoordinate(6, 2);
		Coordinate five_eight = egm.makeCoordinate(5,8);
		EscapePiece piece = egm.getPieceAt(six_two);
		assertNotNull(egm);
		assertEquals(PieceName.HORSE,piece.getName());
		assertTrue(egm.move(six_two, five_eight));
		assertEquals(PieceName.HORSE, egm.getPieceAt(five_eight).getName());
	}
	//29
	@Test
	void moveHorseFrom6_2To5_8AndReset6_2() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		assertNotNull(egm);
		Coordinate six_two = egm.makeCoordinate(6, 2);
		Coordinate five_eight = egm.makeCoordinate(5, 8);
		assertEquals(PieceName.HORSE, egm.getPieceAt(six_two).getName());
		assertTrue(egm.move(six_two, five_eight));
		assertEquals(PieceName.HORSE, egm.getPieceAt(five_eight).getName());
		assertNull(egm.getPieceAt(six_two));
	}
	//30
	@Test
	void player2MovesPlayer1Piece() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		assertNotNull(egm);
		Coordinate six_two = egm.makeCoordinate(6, 2);
		Coordinate five_eight = egm.makeCoordinate(5, 8);
		assertEquals(PieceName.HORSE, egm.getPieceAt(six_two).getName());
		assertTrue(egm.move(six_two, five_eight));
		assertEquals(PieceName.HORSE, egm.getPieceAt(five_eight).getName());
		assertNull(egm.getPieceAt(six_two));
		assertFalse(egm.move(five_eight, six_two)); //returns false because Player 1 cannot go
	}
	//31
	@Test
	void player1MovesPlayer2Piece() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		assertNotNull(egm);
		Coordinate six_two = egm.makeCoordinate(6, 2);
		Coordinate five_eight = egm.makeCoordinate(5, 8);
		Coordinate ten_twelve = egm.makeCoordinate(10, 12);
		assertEquals(PieceName.HORSE, egm.getPieceAt(six_two).getName());
		assertFalse(egm.move(ten_twelve, five_eight)); //returns false bc its not player 2's move
	}
	//32
	@Test
	void player1MovesPlayer2ToExit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate ten_twelve = egm.makeCoordinate(10, 12);
		Coordinate five_twelve = egm.makeCoordinate(5, 12);
		assertFalse(egm.move(ten_twelve, five_twelve));
	}
	//33
	@Test
	void player2MovesPlayer1ToExit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate ten_twelve = egm.makeCoordinate(10, 12);
		Coordinate six_two = egm.makeCoordinate(6, 2);
		Coordinate eight_nine = egm.makeCoordinate(8, 9);
		Coordinate five_twelve = egm.makeCoordinate(5, 12);
		assertTrue(egm.move(six_two, eight_nine)); //from (6,2) to (8,9) 
		assertFalse(egm.move(eight_nine, five_twelve)); //try to move player 1 to exit
	}
	//34
	@Test
	void goesToPlayer1AfterPlayer2() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		assertNotNull(egm);
		Coordinate six_two = egm.makeCoordinate(6, 2);
		Coordinate five_eight = egm.makeCoordinate(5, 8);
		Coordinate ten_twelve = egm.makeCoordinate(10, 12);
		assertEquals(PieceName.HORSE, egm.getPieceAt(six_two).getName());
		assertTrue(egm.move(six_two, five_eight)); //player 1
		assertEquals(PieceName.HORSE, egm.getPieceAt(five_eight).getName());
		assertNull(egm.getPieceAt(six_two)); //erase piece from from
		assertFalse(egm.move(five_eight, six_two)); //move player 1s piece on player 2 move
		assertTrue(egm.move(ten_twelve, six_two)); //move player 2
		assertTrue(egm.move(five_eight, ten_twelve)); //then move to player 1
	}
	//35
	@Test
	void movesToAndFromAreTheSame() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate six_two = egm.makeCoordinate(6,2);
		assertTrue(egm.move(six_two, six_two));
	}
	//36
	@Test
	void player1LandsOnExit() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate six_two = egm.makeCoordinate(6,2);
		Coordinate exitLoc = egm.makeCoordinate(5,12);
		assertTrue(egm.move(six_two, exitLoc));
		assertNull(egm.getPieceAt(six_two)); //successfully removes and exits
	}
	//37
	@Test
	void nullPieceTryToMove() throws Exception //got it
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate ten_thirteen = egm.makeCoordinate(10, 13);
		Coordinate ten_nineteen = egm.makeCoordinate(10,19);
		assertFalse(egm.move(ten_thirteen, ten_nineteen)); //no piece to move
	}
	//38
	@Test
	void player1LandsOnCoordinateWithItsPiece() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate six_two = egm.makeCoordinate(6,2); // player 1 piece
		Coordinate exitLoc = egm.makeCoordinate(5,12); //exit 
		Coordinate nine_two = egm.makeCoordinate(9,2); // player one has another piece here
		assertEquals(PieceName.HORSE,egm.getPieceAt(six_two).getName());
		assertFalse(egm.move(six_two, nine_two));
	}
	//39
	@Test
	void checkMoveToBorderUpperLimit() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate border = egm.makeCoordinate(25,20);
		Coordinate six_two = egm.makeCoordinate(6, 2);
		assertTrue(egm.move(six_two, border));
	}
	//40
	@Test
	void checkMoveToOutOfBoundsX() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(26,20);
		Coordinate six_two = egm.makeCoordinate(6, 2);
		assertFalse(egm.move(six_two, outOfBounds));
	}
	//41
	@Test
	void checkMoveToOutOfBoundsY() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(25,21);
		Coordinate six_two = egm.makeCoordinate(6, 2);
		assertFalse(egm.move(six_two, outOfBounds));
	}
	//42
	@Test
	void checkMoveToOutOfBoundsXAndY() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(26,21);
		Coordinate six_two = egm.makeCoordinate(6, 2);
		assertFalse(egm.move(six_two, outOfBounds));
	}
	//43
	@Test
	void checkMoveToOutOfBounds0_0() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(0,0);
		Coordinate six_two = egm.makeCoordinate(6, 2);
		assertFalse(egm.move(six_two, outOfBounds));
	}
	//44
	@Test
	void checkMoveToOutOfBounds0_1() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(0,1);
		Coordinate six_two = egm.makeCoordinate(6, 2);
		assertFalse(egm.move(six_two, outOfBounds));
	}
	//45
	@Test
	void checkMoveToOutOfBounds1_0() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(1,0);
		Coordinate six_two = egm.makeCoordinate(6, 2);
		assertFalse(egm.move(six_two, outOfBounds));
	}
	//46
	@Test
	void checkMoveToOutOfBoundsNegative() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate outOfBounds = egm.makeCoordinate(-8,-5);
		Coordinate six_two = egm.makeCoordinate(6, 2);
		assertFalse(egm.move(six_two, outOfBounds));
	}
	//47
	@Test
	void checkMoveToBorderLowerLimit() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate border = egm.makeCoordinate(1,1);
		Coordinate six_two = egm.makeCoordinate(6, 2);
		assertTrue(egm.move(six_two, border));
	}
	//48
	@Test
	void player1MovesToPlayer2Loc() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest3.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate ten_twelve = egm.makeCoordinate(10, 12); //player 2
		Coordinate six_two = egm.makeCoordinate(6, 2); //player 1
		assertTrue(egm.move(six_two, ten_twelve));
		assertEquals(Player.PLAYER1, egm.getPieceAt(ten_twelve).getPlayer());
		assertEquals(PieceName.HORSE, egm.getPieceAt(ten_twelve).getName());
	}
	//49
	@Test
	void gamePlay() throws Exception
	{
		//1,10 exit, 5,12 exit -- 1,8 block 3,5 block
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GamePlayerBoard.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate one_one = egm.makeCoordinate(1, 1);
		Coordinate one_three = egm.makeCoordinate(1, 3);
		Coordinate one_five = egm.makeCoordinate(1, 5);
		Coordinate nine_two = egm.makeCoordinate(9, 2);
		Coordinate ten_twelve = egm.makeCoordinate(10, 12);
		Coordinate eighteen_twelve = egm.makeCoordinate(18, 12);
		Coordinate exitLoc1 = egm.makeCoordinate(1, 10);
		Coordinate exitLoc2 = egm.makeCoordinate(5, 12);
		//check to make sure that exit and block dont have pieces on them
		assertNull(egm.getPieceAt(exitLoc1)); // should get null because the piece is exit
		assertNull(egm.getPieceAt(one_five)); // there is no piece here
		//check that board pieces are populated
		assertEquals(PieceName.SNAIL, egm.getPieceAt(one_one).getName()); //player 1 snail
		assertEquals(Player.PLAYER1, egm.getPieceAt(one_one).getPlayer()); //player 1 snail
		//try to move player 2's piece first
		assertFalse(egm.move(ten_twelve, one_five)); //cannot move bc its player 1's turn
		//make a successful move with player 1
		assertTrue(egm.move(one_one, one_five)); //player 1 snail must be at 1,5 now
		//check that from location has no piece now
		assertNull(egm.getPieceAt(one_one)); //wipe old
		assertEquals(PieceName.SNAIL, egm.getPieceAt(one_five).getName()); //check new
		assertEquals(Player.PLAYER1, egm.getPieceAt(one_five).getPlayer());
		//try to move player 1's piece again
		assertFalse(egm.move(one_five, one_one)); //cannot bc its player 2s turn
		//try to move player 1 to exit
		assertFalse(egm.move(one_five, exitLoc1)); 
		//player 2 makes a valid move
		assertTrue(egm.move(ten_twelve, one_one)); //player 2 on one_one now
		//wipe player 2's from location
		assertNull(egm.getPieceAt(ten_twelve));
		//player 1 moves to player 2's spot
		assertTrue(egm.move(one_five, one_one)); 
		//player 1's piece is on the coordinate that player 2's piece was on
		assertEquals(Player.PLAYER1, egm.getPieceAt(one_one).getPlayer()); //we should be getting player 1's piece
		//player 2 moves its piece to exit
		assertTrue(egm.move(eighteen_twelve, exitLoc1));
		//player 1 moves to exit
		assertTrue(egm.move(one_one, exitLoc2));	
		
	}
	//50
	@Test
	void nonSquareCoordinateType() throws Exception
	{
		//25, 20
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/NonSquareCoord.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate nonSquareType = egm.makeCoordinate(10, 12);
		assertNull(egm.getPieceAt(nonSquareType));
	}
	
	//51
	@Test
	void moveToandFromNullLocation() throws Exception
	{
		EscapeGameBuilder egb = new EscapeGameBuilder("config/egc/GameBuilderTest2.egc");
		EscapeGameManager egm = egb.makeGameManager();
		Coordinate nuller = null;
		Coordinate six_two = egm.makeCoordinate(6, 2);
		assertFalse(egm.move(six_two, nuller));
		assertFalse(egm.move(nuller, six_two));
	}
	
	
	

}
