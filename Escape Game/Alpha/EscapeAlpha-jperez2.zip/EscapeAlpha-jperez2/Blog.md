#Jerry Perez CS4233 Blog - Hopefully escaping this project soon

#November 5th, 2020 @ 5PM: Finished at 8PM
	Read through the documentation of Escape - being careful to take notes on the important aspects and ask questions on what doesn't make the most sense.
	
#November 6th, 2020 @ 8PM: Finished at 12 AM
	
	Today I plan on getting started with the starter code and attempt to ease into the TDD approach. 
	
	At the moment I was able to write down some tests that extract the xMax and yMax values from the EscapeGameBuilder. Using this knowledge, I was able to create a new class that implements EscapeGameManager to create a new Game for makeGameBuilder(). makeGameBuilder is to my knowledge creating a game correctly at the moment. I feel much more familiar with the code-base now, and feel like I have a good representation as to where to go. The next time that I sit down to work on this, it is very likely going to be attempting to make getPiece, or makeCoordinate to work.
	
#November 8th, 2020 @5:30PM: Finished at 9 PM , came back at 11PM and finished at 12AM
	
	Today I plan on finding a way to get makeCoordinate work, and possibly getting getPiece to work as well.
	
	About an hour in, I was able to get makeCoordinate to work, and have some future plans on implementation. The way that I expect for it to work is to have many different classes for each type of game which will represent a certain board. Each of these boards will implement the board interface that was created and will have its designated coordinate type. The next step from here on out is to work on getPiece and to have that work.
	
	It is currently 9 PM and I still have not found a way to get getPieceAt to work correctly. In fact, my test keeps getting null for some reason.
	
	After revamping a few lines of code, getPiece is now fully functional and passes anticipated test cases.
	
#November 9th, 2020 @8:00PM: Finished at 2:30AM

	Professor Pollice released a getPieceAt() sample test case. I ran the test, and nervously awaited the green bar.. and it did!!! So now, the plan for the next few hours is to get distanceTo to work. I will be back!
	
	It is currently 8:30 and I was able to successfully implement the distanceTo function to work! The JUNIT5 video that inspired my structure for this project helped get me through this part of the program. Thanks Pollice.
	
	The next thing to do is very likely the hardest, and that is to get the move() function to work.
	
	Update, it is 10:38, and I have yet to figure out move fully. I have an implementation that works for a move that takes a player from a starting location to a "block" which should return false, and it does. However, I have yet to find out how to get the locationType correctly. That is, when I print out the locationType for each LocationInitializer, some of them are null, even though they should be clear.
	
	Update, it is 11:05, and after a bunch of print ln's later, I figured it out!! I was able to achieve my goal by setting a specification inside of my for loop which iterated through each LocationInitializer... if it wasnt exit, or block, then it must be clear, and that straightened it out. Now, the only problem that I have is that I need to find a way to reset the piece that WAS at the location.
	
	It is 12:42, and I still cant figure out why in the world resetting the board is not working. I might give my mind a break to see if that does well, but if I could figure this out then alpha should be a long gone memory... maybe. Ive tried printing out statements of my map state and its getting the state correctly but it doesnt seem to communicate well with the manager class. 
	
#November 10th, 2020 @7:45 PM: 9:15 PM

	The issue seems to be with the from coordinate communicating with the put function. For example, I can create a new coordinate and put a null piece there and it works fine, but I cannot put a null piece at the old location for some reason.
	
	Think of maybe creating a new coordinate with the same attributes, and assign it a null player, delete it from the map and then place the "new" coordinate in the map
	
	Update: still does not update the map.
	
#November 11th, 2020 @12:00PM: 5 PM

	I had a meeting with Professor Pollice today and he gave me some insight as to why my code could not be working. It seems that for some reason, my map was not getting populated on the first time around, and that I ought to populate the pieces when I use board! After making that change, the test that I was fiddling with passed! However, I'm running into another weird issue. Running the tests individually... they all pass, however, running them all together fails at one, and says that I get a null pointer exception.
	
	Im not going to stress too much on fixing that issue because I have some assurance that they pass individually. It could very well be an assertion error on behalf of the machine...Its weird because the test that passes is the one where I remove a coordinate from a specific location, and the test that fails is the test that checks which piece is at that location.
	
	Update: I was still worrying about it so what I did was I created a new egc file and linked it to local tests within my file and everything worked fine after that.
	
	The test that used getPieceAt ran after I moved a piece which swaps the previous space to null and the getPieceAt was looking for the piece that was in that location, which wasnt there....
	
	Now, I'm going to move on to some extreme testing to make sure that everything works the way it should.
	
	So far so good, the only thing that isnt working that I ought to figure out is whether or not we can assume that if there is no player on a tile, and the move function is called with that tile to move to the next, if our program should catch that.
	
	In addition, the professor recommneded that I use BeforeEach instead of BeforeAll for my test cases. See you soon!
	
#November 14th, 2020 @1:30 AM: 3:00 AM

	So, today is the first day that I am going to log in this blog AFTER I do something. I originally hopped onto this project to get started on javadocs, which I did do. But then I got to thinking what I could do to make my life a bit easier for the next implementation that we are going to have. At the moment, the way my game was configured, it was specifically for square games, with naming conventions to follow. However, I just recently watches the videos on factories and dependency injection, and I feel really good about what I just did. Instead of having a bunch of different Names for classes that were specific to square, I renamed accordingly and made it more specific to the game. In addition, I made a factory that once we begin to implement new coordinate types, we will be able to handle without an issue. The switch statement is already configured and the game seems fairly polished to me. 
	
#November 18th, 2020 @11 AM: 2PM

	Today I took an in depth look at my code in order to determine what was left and what edge cases I might have missed. There were only a few edge cases that werent written but worked in the sense of code. I am thoroughly impressed at the project at this point and I think I am in pretty good shape for Beta (hopefully). In addition to doing the last minute checks, I just made sure that all java doc comments were added, the files were organized, and the methods are proper and informational.