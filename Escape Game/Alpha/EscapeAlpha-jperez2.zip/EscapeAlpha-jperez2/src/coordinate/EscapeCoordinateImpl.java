package coordinate;

public interface EscapeCoordinateImpl extends Coordinate 
{
	public int getX();
	public int getY();
	public int hashCode();
	public boolean equals(Object o);
}
