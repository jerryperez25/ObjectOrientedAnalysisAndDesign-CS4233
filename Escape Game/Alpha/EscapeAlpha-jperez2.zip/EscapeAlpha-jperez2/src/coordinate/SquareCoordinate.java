package coordinate;

import java.util.Objects;

import escape.exception.EscapeException;

public class SquareCoordinate implements EscapeCoordinateImpl
{
	private int x;
	private int y;
	
	public SquareCoordinate(int x, int y)
	{
		this.x = x;
		this.y = y;
	}
	public int getX()
	{
		return this.x;
	}
	public int getY()
	{
		return this.y;
	}
	/**
	 * This function uses a coordinate to determines the distance to the
	 * location given to it as the argument.
	 * @param Coordinate
	 */
	public int DistanceTo(Coordinate c) 
	{
		//if a different type then 
		Throwable newThrow = new Throwable("Invalid Coordinate Type");
		
		if (!(c instanceof SquareCoordinate))
		{
			throw new EscapeException("Coordinate is not appropriate type", newThrow);
		}
		
		SquareCoordinate caster = (SquareCoordinate) c;
		int dist = 0;
		int xDist = Math.abs(caster.getX() - this.getX());
		int yDist = Math.abs(caster.getY() - this.getY());
		
		while(xDist != 0 && yDist != 0)
		{
			dist++;
			xDist--;
			yDist--;
		}
		
		dist = dist + xDist;
		dist = dist + yDist;
		return dist;
	}

	
	/**
	 * This function facilitates hashing in maps.
	 */
	@Override
	public int hashCode()
	{
		return Objects.hash(x,y);
	}
	/**
	 * this function is overridden and checks to make sure the give object
	 * matches the instance that we would like to check
	 */
	@Override
	public boolean equals(Object o)
	{
		if ((o instanceof SquareCoordinate))
		{
			SquareCoordinate newOne = (SquareCoordinate) o;
			return newOne.x == this.x && newOne.y == this.y;
		}
		return false;
		
	}
}
