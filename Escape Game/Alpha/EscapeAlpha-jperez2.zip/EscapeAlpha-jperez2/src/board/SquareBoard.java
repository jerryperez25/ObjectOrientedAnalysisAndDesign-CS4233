package board;

import java.util.HashMap;
import java.util.Map;

import coordinate.EscapeCoordinateImpl;
import coordinate.SquareCoordinate;
import escape.exception.EscapeException;
import escape.util.LocationInitializer;
import piece.EscapePiece;
import piece.EscapePieceImpl;
import piece.Player;
import piece.EscapePiece.PieceName;

public class SquareBoard implements EscapeBoard<EscapeCoordinateImpl>
{
	private int xMax;
	private int yMax;
	public Map<EscapeCoordinateImpl, LocationType> coordLoc;
	public Map<EscapeCoordinateImpl, EscapePiece> coordPiece;
	private boolean player1Turn = true;
	private boolean gameOver = false;
	
	public SquareBoard(int xMax, int yMax)
	{
		this.xMax = xMax;
		this.yMax = yMax;
		coordLoc = new HashMap<>();
		coordPiece = new HashMap<>();
		
	}
	
	public int getXMax()
	{
		return this.xMax;
	}
	public int getYMax()
	{
		return this.yMax;
	}

	/**
	 * This function takes in a desired coorindate set and returns the location
	 * type that is associated with it.
	 * @param coordinate
	 * @return LocationType
	 */
	public LocationType getLocationType(EscapeCoordinateImpl coordinate)
	{
		 return this.coordLoc.get(coordinate);
	}
	
	/**
	 * This function sets the specified coordinate to a specified type.
	 * @param coordinate
	 * @param type
	 */
	public void setLocationType(EscapeCoordinateImpl coordinate, LocationType type)
	{
		this.coordLoc.put(coordinate, type);
	}
	 

	/**
	 * This function gets the associated piece with the location that we are
	 * passing in. It is important to note that we can only get pieces for valid
	 * coordinates. Despite the fact that a manager can make whatever coordinate. 
	 * @param coordinate
	 * @return EscapePiece
	 */
	@Override
	public EscapePiece getPieceAt(EscapeCoordinateImpl coordinate) 
	{
		//we check if coordinates x and y is less than 1 because that is the first coordinate in the squareGame
		if (coordinate == null || coordinate.getX() > this.getXMax()|| coordinate.getY() > this.getYMax() || coordinate.getX() < 1 || coordinate.getY() < 1)
		{
			return null;
		}
		
		return coordPiece.get(coordinate);
	}

	/**
	 * This function puts the specified piece at the specified location.
	 * This will be helpful for all boards.
	 * @param piece
	 * @param coord
	 */
	@Override
	public void putPieceAt(EscapePiece piece, EscapeCoordinateImpl coord) 
	{
		this.coordPiece.put(coord, piece);	
	}
	
	/**
	 * Make the move in the current game.
	 * @param from starting location
	 * @param to ending location
	 * @return true if the move was legal, false otherwise
	 */
	
	public boolean move(EscapeCoordinateImpl from, EscapeCoordinateImpl to)
	{
		//we have to handle the false statements first
		//try clean up here by making a function that handles all false statements
		if(from == null || to == null)
		{
			return false;
		}
		
		if (this.coordPiece.get(from) == null)
		{
			//there is no piece on desired location
			return false;
		}
		
		EscapePiece whichPiece = this.getPieceAt(from);
		
		if ((whichPiece.getPlayer() == Player.PLAYER1) != player1Turn)
		{
			//player 1 tries to move on player 2's turn
			return false;
		}
		
		if (from.getX() == to.getX() && from.getY() == to.getY())
		{
			//to and from are the same
			player1Turn = !player1Turn;
			return true;
		}
		//max bounds
		if(from.getX() > this.xMax || from.getY() > this.yMax || to.getX() > this.xMax || to.getY() > this.yMax)
		{
			return false;
		}
		//min bounds
		if(from.getX() < 1 || from.getY() < 1 || to.getX() < 1 || to.getY() < 1)
		{
			return false;
		}
		if ((this.getPieceAt(to)!= null) && this.getPieceAt(to).getPlayer() == whichPiece.getPlayer())
		{
			//the moving player already has a piece on the target location
			//moving players piece on target coordinate
			return false;
		}
		if(this.getLocationType(to) != null && this.getLocationType(to) == LocationType.BLOCK)
		{
			//landing on block
			return false;
		}
		//if lands on opposite player return true and remove
		if ((this.getLocationType(to)== LocationType.EXIT)) 
		{
			this.coordPiece.remove(from);
			player1Turn = !player1Turn;
			return true;
		}
		else
		{
			this.putPieceAt(whichPiece, to); //puts the piece
			this.putPieceAt(null, from); //removes the piece
			player1Turn = !player1Turn; //its the opposite players turn now
			return true;
		}
	}
	

}
