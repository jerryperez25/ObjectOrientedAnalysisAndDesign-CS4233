package board;

import java.util.Map;

import coordinate.Coordinate;
import coordinate.EscapeCoordinateImpl;
import coordinate.SquareCoordinate;
import piece.EscapePiece;

public interface EscapeBoard<C extends Coordinate> 
{
	/**
	 * this function gets the associated piece with the location that we are
	 * passing in. This will be helpful for all boards.
	 * @param coordinate
	 * @return EscapePiece
	 */
	EscapePiece getPieceAt(C coordinate);
	/**
	 * This function puts the specified piece at the specified location.
	 * This will be helpful for all boards.
	 * @param piece
	 * @param coord
	 */
	void putPieceAt(EscapePiece piece, EscapeCoordinateImpl coord);
}
