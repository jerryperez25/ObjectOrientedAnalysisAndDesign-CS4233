package piece;

public class EscapePieceImpl implements EscapePiece 
{
	private PieceName name;
	private Player playerWho;
	
	public EscapePieceImpl(Player playerWho, PieceName name)
	{
		this.name = name;
		this.playerWho = playerWho; 
	}
	/**
	 * @return the name
	 */
	public PieceName getName()
	{
		return this.name;
	}
	/**
	 * @return the player
	 */
	public Player getPlayer()
	{
		return this.playerWho;
	}
}
